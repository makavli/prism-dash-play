"""Browser entry point for pygbag (copied next to prism_dash/ by tools/build_web.sh).

Copyright (c) 2026 Massinissa K. All rights reserved.
"""

import asyncio

# pygbag loads packages by scanning THIS file's imports, so pygame must appear here.
import pygame  # noqa: F401

from prism_dash.app import main_async

asyncio.run(main_async())
