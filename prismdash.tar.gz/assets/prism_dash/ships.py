"""Playable ships. Each one tweaks the player's handling; most are unlocked
by earning an achievement."""

from dataclasses import dataclass, field

from prism_dash import settings as S


@dataclass(frozen=True)
class Ship:
    id: str
    name: str
    color: tuple
    trait: str                       # one line shown on the select screen
    dash_time: float = 1.0           # multipliers on the base settings
    dash_speed: float = 1.0
    cooldown: float = 1.0
    move: float = 1.0
    charges: int = 1                 # dashes stored
    lives: int = 0                   # extra starting lives
    novas: int = 0                   # extra starting novas
    perks: dict = field(default_factory=dict)   # perks you start with
    unlock: str = None               # achievement id that unlocks it (None = always)


SHIPS = [
    Ship("prism", "PRISM", S.CYAN, "Balanced. The original."),
    Ship("comet", "COMET", S.ORANGE, "Long, fast dashes - but a slower recharge.",
         dash_time=1.4, dash_speed=1.12, cooldown=1.3, unlock="wave10"),
    Ship("shard", "SHARD", S.PINK, "Stores TWO dashes. Shorter dashes.",
         dash_time=0.75, cooldown=1.15, charges=2, unlock="hat_trick"),
    Ship("aegis", "AEGIS", S.WHITE, "Starts with a Barrier and +1 life. Moves slower.",
         move=0.88, lives=1, perks={"barrier": 1}, unlock="core1"),
    Ship("nova", "NOVA", S.PURPLE, "Starts with 3 novas and the Supernova upgrade.",
         cooldown=1.1, novas=2, perks={"supernova": 1, "novacache": 1}, unlock="supernova"),
]
BY_ID = {ship.id: ship for ship in SHIPS}


def get(ship_id):
    return BY_ID.get(ship_id, SHIPS[0])


def is_unlocked(ship, unlocked_achievements):
    return ship.unlock is None or ship.unlock in unlocked_achievements


def stat_bars(ship):
    """0..1 values for the select screen's bars (higher = better)."""
    return {
        "DASH LENGTH": min(1.0, ship.dash_time * ship.dash_speed / 1.6),
        "RECHARGE": min(1.0, 0.75 / ship.cooldown),
        "SPEED": min(1.0, ship.move),
        "DASH CHARGES": ship.charges / 2,
    }
