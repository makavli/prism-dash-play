"""Upgrades you draft during a run. Pure data + small helpers.

A perk has levels (most can be taken more than once). The player's perks
are a dict  {perk_id: level}. Game code asks  player.perk("longdash")
for the level and derives its numbers from that.
"""

from dataclasses import dataclass

from prism_dash import settings as S


@dataclass(frozen=True)
class Perk:
    name: str
    description: str          # {n} is replaced by the next level's number
    color: tuple
    max_level: int = 3


PERKS = {
    "longdash":   Perk("LONG DASH", "Dashes last {n}% longer.", S.CYAN),
    "quickdash":  Perk("QUICK RECHARGE", "Dash cooldown {n}% shorter.", S.CYAN),
    "shockwave":  Perk("SHOCKWAVE", "Enemies you dash through explode, destroying others within {n}px.", S.PINK),
    "momentum":   Perk("MOMENTUM", "Your combo lasts {n}s longer before breaking.", S.GOLD),
    "keeper":     Perk("STEADY HANDS", "Getting hit only halves your chain instead of breaking it.", S.GOLD, 1),
    "barrier":    Perk("BARRIER", "A shield absorbs one hit. Recharges every wave.", S.WHITE, 1),
    "vitality":   Perk("VITALITY", "+1 life now and +1 maximum lives.", S.RED),
    "novacache":  Perk("NOVA CACHE", "+1 nova now and +1 maximum novas.", S.PURPLE),
    "supernova":  Perk("SUPERNOVA", "Novas also recharge your dash and deal 2 damage to the Core.", S.PURPLE, 1),
    "magnet":     Perk("MAGNET", "Power-ups fly to you and drop {n}% more often.", S.GREEN),
    "overcharge": Perk("OVERCHARGE", "Overdrive lasts {n}% longer.", S.GOLD, 2),
    "bounty":     Perk("BULLET BOUNTY", "Dashing through bullets pays triple and keeps your combo alive.", S.ORANGE, 1),
}


def describe(perk_id, level):
    """Description for taking the perk at `level` (1-based)."""
    numbers = {
        "longdash": 25 * level,
        "quickdash": round((1 - 0.8 ** level) * 100),
        "momentum": level,
        "magnet": 60 * level,
        "shockwave": 55 + 30 * level,
        "overcharge": 50 * level,
    }
    return PERKS[perk_id].description.format(n=numbers.get(perk_id, ""))


def available(owned):
    return [pid for pid, perk in PERKS.items() if owned.get(pid, 0) < perk.max_level]


def offer(owned, rng, count=3):
    """Pick `count` different perks the player can still take."""
    choices = available(owned)
    rng.shuffle(choices)
    return choices[:count]


def is_draft_wave(wave):
    """Draft an upgrade after waves 2, 5, 8, 10, 13, 15, 18, 20 ...
    (every boss, plus one mid-way between bosses)."""
    return wave == 2 or wave % 5 in (0, 3)
