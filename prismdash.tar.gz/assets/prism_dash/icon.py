"""The game icon, drawn in code (used for the window and the .exe)."""

import pygame

from prism_dash import render
from prism_dash import settings as S


def make_icon(size=256):
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    pygame.draw.rect(surf, (*S.BG, 255), (0, 0, size, size), border_radius=size // 5)
    glow_layer = pygame.Surface((size, size))
    glow_layer.fill((0, 0, 0))
    c = (size / 2, size / 2)
    render.glow(glow_layer, c, size * 0.48, S.PINK, 0.8)
    render.glow(glow_layer, (size * 0.42, size * 0.55), size * 0.36, S.CYAN, 0.9)
    surf.blit(glow_layer, (0, 0), special_flags=pygame.BLEND_RGB_ADD)
    pts = render.ship_points((size * 0.46, size * 0.54), size * 0.26, -0.75)
    pygame.draw.polygon(surf, (*S.WHITE, 255), pts)
    pygame.draw.polygon(surf, (*S.CYAN, 255), pts, max(2, size // 40))
    # a little dash trail
    for i in range(4):
        off = size * (0.12 + i * 0.07)
        r = max(1, int(size * (0.035 - i * 0.007)))
        pygame.draw.circle(surf, (*S.CYAN, 255), (size * 0.40 - off * 0.68, size * 0.62 + off * 0.62), r)
    return surf
