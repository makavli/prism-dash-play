"""A simple AI that plays the game. It powers the menu's attract-mode demo
and the headless playtests. It's decent but beatable, like a new player."""

import math
import random

from pygame import Vector2

from prism_dash import settings as S
from prism_dash.entities import Boss, Warden, angle_diff
from prism_dash.world import Controls


class Autopilot:
    def __init__(self, seed=None, skill=1.0):
        self.rng = random.Random(seed)
        self.skill = skill
        self.orbit = 1

    def _dash_target(self, world):
        p = world.player
        best, best_d = None, 430 * self.skill
        for e in world.enemies:
            d = p.pos.distance_to(e.pos)
            if d > best_d:
                continue
            if isinstance(e, Warden):
                to_p = p.pos - e.pos
                if abs(angle_diff(math.atan2(to_p.y, to_p.x), e.facing)) < e.SHIELD_HALF_ARC + 0.2:
                    continue          # shield is facing us: don't dash into it
            if isinstance(e, Boss) and (e.invuln > 0 or e.dash_hit(world) == "bounce"):
                continue          # shielded or just hit: dashing in would bounce off
            best, best_d = e, d
        return best

    def controls(self, world):
        p = world.player
        c = Controls()
        if world.draft:
            c.pick = self.rng.randrange(len(world.draft))
            return c
        if not world.enemies:
            c.move = (Vector2(S.WIDTH / 2, S.HEIGHT / 2) - p.pos) * 0.01
            return c

        target = self._dash_target(world)
        if target and p.dash_ready and self.rng.random() < 0.25 + 0.5 * self.skill:
            c.dash = True
            c.dash_target = target.pos + target.vel * 0.09
            return c

        nearest = min(world.enemies, key=lambda e: p.pos.distance_squared_to(e.pos))
        to_e = nearest.pos - p.pos
        d = max(1.0, to_e.length())
        direction = to_e / d
        move = Vector2()
        ideal = 230 if p.dash_ready else 300
        move += direction * (1 if d > ideal + 40 else -1 if d < ideal - 40 else 0)
        if self.rng.random() < 0.01:
            self.orbit *= -1
        move += Vector2(-direction.y, direction.x) * self.orbit * 0.8

        for b in world.bullets:                  # dodge bullets
            away = p.pos - b.pos
            dist = away.length()
            if 0 < dist < 150:
                move += away / dist * (1 - dist / 150) * 3.0
        for e in world.enemies:                  # and crowds
            away = p.pos - e.pos
            dist = away.length()
            if 0 < dist < 120 and not p.dashing:
                move += away / dist * (1 - dist / 120) * 2.0
        centre = Vector2(S.WIDTH / 2, S.HEIGHT / 2) - p.pos
        if abs(centre.x) > S.WIDTH * 0.36 or abs(centre.y) > S.HEIGHT * 0.34:
            move += centre.normalize() * 1.2     # keep off the walls
        c.move = move

        close = sum(1 for e in world.enemies if p.pos.distance_to(e.pos) < 130)
        if p.novas and (len(world.bullets) > 40 or (p.lives == 1 and close >= 3)):
            c.nova = True
        return c
