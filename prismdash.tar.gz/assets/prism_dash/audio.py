"""Sound effects are synthesized at startup; the music is three free (CC0) tracks.

If there's no audio device (or mixer init fails), the game runs silently.
"""

import math
import os
import random
import threading
from array import array

import pygame

from prism_dash import web

RATE = 22050


# --------------------------------------------------------------------------
# Tiny synthesizer: returns lists of floats in -1..1
# --------------------------------------------------------------------------
def _osc(kind, phase, rng):
    if kind == "sine":
        return math.sin(phase)
    if kind == "square":
        return 1.0 if math.sin(phase) >= 0 else -1.0
    if kind == "saw":
        return (phase / math.pi) % 2.0 - 1.0
    if kind == "tri":
        return 2.0 * abs((phase / math.pi) % 2.0 - 1.0) - 1.0
    return rng.uniform(-1.0, 1.0)  # noise


def tone(f0, f1, dur, kind="sine", vol=0.5, attack=0.005, curve=4.0, seed=1):
    """A sound sweeping from f0 to f1 Hz with a sharp attack and exponential decay."""
    rng = random.Random(seed)
    n = int(RATE * dur)
    out = [0.0] * n
    phase = 0.0
    for i in range(n):
        t = i / n
        freq = f0 + (f1 - f0) * t
        phase += 2 * math.pi * freq / RATE
        env = min(1.0, i / (attack * RATE + 1)) * math.exp(-curve * t)
        out[i] = _osc(kind, phase, rng) * env * vol
    return out


def mix(*parts, offset=None):
    """Add sounds together; offset[i] delays part i by that many seconds."""
    offset = offset or [0] * len(parts)
    length = max(len(p) + int(o * RATE) for p, o in zip(parts, offset))
    out = [0.0] * length
    for part, off in zip(parts, offset):
        start = int(off * RATE)
        for i, v in enumerate(part):
            out[start + i] += v
    return out


def to_sound(samples, channels, factor=1):
    """Synthesized samples (at RATE) -> a Sound. `factor` = mixer rate / RATE: the samples
    are linearly interpolated up to the mixer's rate (44.1 kHz on desktop)."""
    data = array("h")
    prev = 0.0
    for v in samples:
        v = max(-1.0, min(1.0, v))
        for k in range(1, factor + 1):
            s = int((prev + (v - prev) * k / factor) * 32000)
            data.extend([s] * channels)
        prev = v
    return pygame.mixer.Sound(buffer=data.tobytes())


# --------------------------------------------------------------------------
# The game's sound effects
# --------------------------------------------------------------------------
PENTATONIC = [0, 3, 5, 7, 10]


def _note(base, step):
    octave, degree = divmod(step, len(PENTATONIC))
    return base * 2 ** ((PENTATONIC[degree] + 12 * octave) / 12)


def build_effects():
    fx = {
        "dash": mix(tone(1400, 300, 0.20, "noise", 0.35, curve=6),
                    tone(700, 200, 0.16, "sine", 0.25, curve=5)),
        "hit": mix(tone(160, 40, 0.45, "saw", 0.55, curve=4),
                   tone(0, 0, 0.30, "noise", 0.45, curve=7, seed=3)),
        "clang": mix(tone(920, 900, 0.30, "square", 0.18, curve=9),
                     tone(1310, 1290, 0.30, "square", 0.12, curve=9)),
        "power": mix(*(tone(_note(523, s), _note(523, s), 0.12, "tri", 0.35, curve=3)
                       for s in (0, 2, 4, 5)),
                     offset=[0, 0.06, 0.12, 0.18]),
        "nova": mix(tone(80, 30, 1.1, "saw", 0.5, curve=2.5),
                    tone(0, 0, 1.0, "noise", 0.5, curve=3, seed=7),
                    tone(2000, 200, 0.6, "sine", 0.25, curve=3)),
        "wave": mix(tone(659, 659, 0.35, "tri", 0.35, curve=3),
                    tone(988, 988, 0.5, "tri", 0.3, curve=3), offset=[0, 0.12]),
        "shoot": tone(900, 500, 0.07, "square", 0.08, curve=6),
        "spawn": tone(200, 600, 0.25, "sine", 0.10, attack=0.1, curve=2),
        "boss_hit": mix(tone(300, 90, 0.35, "square", 0.3, curve=5),
                        tone(0, 0, 0.25, "noise", 0.35, curve=6, seed=11)),
        "boss_die": mix(tone(120, 20, 2.2, "saw", 0.55, curve=2),
                        tone(0, 0, 2.0, "noise", 0.55, curve=2.2, seed=13),
                        tone(1500, 100, 1.2, "sine", 0.3, curve=2)),
        "select": tone(660, 880, 0.08, "tri", 0.3, curve=4),
        "ready": tone(1320, 1320, 0.06, "sine", 0.12, curve=7),
        "milestone": mix(*(tone(_note(523, s), _note(523, s), 0.18, "square", 0.14, curve=4)
                           for s in (0, 2, 4, 7)),
                         offset=[0, 0.05, 0.10, 0.15]),
        "achievement": mix(*(tone(_note(659, s), _note(659, s), 0.3, "tri", 0.3, curve=3)
                             for s in (0, 4, 7)),
                           offset=[0, 0.09, 0.18]),
        "gameover": mix(*(tone(_note(220, s), _note(220, s) * 0.98, 0.4, "tri", 0.35, curve=3)
                          for s in (4, 2, 1, 0)),
                        offset=[0, 0.2, 0.4, 0.6]),
    }
    # Kill "pops" climb a pentatonic scale as the chain grows: chains sound like music.
    for i in range(12):
        f = _note(392, i)
        fx[f"kill{i}"] = mix(tone(f, f * 1.02, 0.14, "square", 0.16, curve=6),
                             tone(f * 2, f * 2, 0.10, "sine", 0.12, curve=8),
                             tone(0, 0, 0.06, "noise", 0.12, curve=10, seed=i))
    return fx


def build_music():
    """An 8-second loop: kick, offbeat hats, a bass line and a soft arpeggio
    over Am - F - C - G at 120 bpm."""
    beat = 0.5
    chords = [(110.0, 0), (87.31, 8), (130.81, 3), (98.0, 10)]   # bass root, arp offset
    n = int(RATE * beat * 16)
    out = [0.0] * n
    rng = random.Random(5)

    def add(start, samples):
        s = int(start * RATE)
        for i, v in enumerate(samples):
            if s + i < n:
                out[s + i] += v

    kick = tone(150, 45, 0.18, "sine", 0.55, curve=7)
    hat = tone(0, 0, 0.04, "noise", 0.10, curve=12, seed=9)
    for b in range(16):
        add(b * beat, kick)
        add(b * beat + beat / 2, hat)
    for bar, (root, arp) in enumerate(chords):
        for eighth in range(8):
            start = (bar * 4 + eighth / 2) * beat
            f = root if eighth % 4 != 3 else root * 1.5
            add(start, tone(f, f, beat / 2, "saw", 0.13, attack=0.01, curve=3))
        for sixteenth in range(16):
            start = (bar * 4 + sixteenth / 4) * beat
            step = [0, 2, 4, 2, 5, 4, 2, 4][sixteenth % 8] + (arp % 5)
            f = _note(440, step)
            add(start, tone(f, f, beat / 4, "tri", 0.05 + 0.02 * rng.random(), curve=5))
    return out


# Free (CC0) music from OpenGameArt.org, one track per mood; see prism_dash/music/CREDITS.txt.
MUSIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "music")
TRACKS = {"menu": ("menu.ogg", 0.50), "play": ("play.ogg", 0.50), "boss": ("boss.ogg", 0.42)}
FADE_MS = 2500          # moods cross-fade: the new track rises while the old one fades out


class Audio:
    def __init__(self, muted=False):
        self.enabled = False
        self.muted = muted
        self.sounds = {}
        self.tracks = {}            # mood -> Sound, filled while the menu is up
        self.synth = None           # the old synthesized loop, if the music files are missing
        self.mood = "menu"
        self.playing = None         # (mood, Sound) on the music channel
        self.music_channels = []
        self._to_load = list(TRACKS)
        self._lock = threading.RLock()
        self.browser = web.browser_music()      # browser: the page plays every sound
        if self.browser is not None:
            # The game's own mixer stays off: it runs on the game's thread, and a slow
            # frame would starve it and tick. The page has the effects pre-rendered.
            self._to_load = []
            self.enabled = True
            self._apply()
            return
        try:
            if not pygame.mixer.get_init():
                # Desktop mixes at CD quality (44.1 kHz). A browser without the page's
                # player (a local test) mixes here, with a bigger buffer for slow frames.
                pygame.mixer.init(RATE if web.IS_WEB else 44100, -16, 2, 1024)
            rate, _, self.channels = pygame.mixer.get_init()
            self.factor = max(1, round(rate / RATE))
            pygame.mixer.set_num_channels(24)
            pygame.mixer.set_reserved(2)            # two music channels effects never take
            self.music_channels = [pygame.mixer.Channel(0), pygame.mixer.Channel(1)]
            self.sounds = {k: to_sound(v, self.channels, self.factor) for k, v in build_effects().items()}
            self.enabled = True
        except (pygame.error, OSError):
            return
        try:
            threading.Thread(target=self._load_all, daemon=True).start()
        except RuntimeError:            # no threads (browser): the menu track now, the rest
            self.load_next()            # one per frame from update()

    # ------------------------------------------------------------ music
    def _load_all(self):
        while self.load_next():
            pass

    def load_next(self):
        """Loads one more track; False when there is nothing left to load."""
        with self._lock:
            if not self._to_load:
                return False
            mood = self._to_load.pop(0)
        name, volume = TRACKS[mood]
        try:
            sound = pygame.mixer.Sound(os.path.join(MUSIC_DIR, name))
            sound.set_volume(volume)
            self.tracks[mood] = sound
        except (pygame.error, OSError, FileNotFoundError):
            if self.synth is None:
                try:
                    self.synth = to_sound(build_music(), self.channels, self.factor)
                    self.synth.set_volume(0.45)
                except (pygame.error, OSError):
                    pass
        self._apply()
        return True

    def update(self):
        """Once a frame. Browser: loads the next track, one per frame, while it's quiet."""
        if self.enabled and self._to_load and web.IS_WEB and self.mood == "menu":
            self.load_next()

    def set_mood(self, mood):
        """'menu', 'play' or 'boss': the music cross-fades to that mood's track."""
        if mood != self.mood:
            self.mood = mood
            self._apply()

    def start_music(self):
        self._apply()

    def _apply(self):
        with self._lock:
            self._switch()

    def _switch(self):
        if self.browser is not None:
            try:
                self.browser.mute(bool(self.muted))
                name, volume = TRACKS[self.mood]
                self.browser.mood(self.mood, volume, FADE_MS)
                self.playing = None if self.muted else (self.mood, None)
            except Exception:              # noqa: BLE001 - a broken bridge must not stop the game
                self.browser = None
            return
        if not self.enabled or self.muted:
            return
        sound = self.tracks.get(self.mood) or self.tracks.get("play") or self.tracks.get("menu") or self.synth
        if sound is None:
            return                                  # still loading: it starts when it's in
        if self.playing and self.playing[1] is sound and self._music_busy():
            return
        old = self.playing
        # The free channel gets the new track; the other one fades the old track out.
        channel = self.music_channels[0]
        if old and self.music_channels[0].get_sound() is old[1]:
            channel = self.music_channels[1]
        for other in self.music_channels:
            if other is not channel:
                other.fadeout(FADE_MS)
        channel.play(sound, loops=-1, fade_ms=FADE_MS if old else 800)
        self.playing = (self.mood, sound)

    def _music_busy(self):
        return any(c.get_busy() for c in self.music_channels)

    def set_muted(self, muted):
        self.muted = muted
        if not self.enabled:
            return
        if muted:
            if pygame.mixer.get_init():
                pygame.mixer.stop()
            self.playing = None
        self._apply()

    def play(self, name, volume=1.0):
        if self.browser is not None:
            if self.enabled and not self.muted:
                try:
                    self.browser.sfx(name, volume)
                except Exception:          # noqa: BLE001 - a broken bridge must not stop the game
                    pass
            return
        if self.enabled and not self.muted and name in self.sounds:
            sound = self.sounds[name]
            sound.set_volume(volume)
            sound.play()

    def kill(self, chain):
        self.play(f"kill{min(chain, 11)}")
