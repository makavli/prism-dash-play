"""Neon drawing helpers. Glow is faked with pre-rendered radial gradients
blitted using additive blending, which looks great on a dark background."""

import math
import random

import pygame

from prism_dash import settings as S

_glow_cache = {}


def _scaled(color, k):
    return tuple(min(255, int(c * k)) for c in color)


def glow_sprite(radius, color, strength=1.0):
    """A soft radial gradient, cached by (radius, color, strength)."""
    radius = max(2, int(radius))
    key = (radius, color, round(strength, 2))
    sprite = _glow_cache.get(key)
    if sprite is None:
        size = radius * 2
        sprite = pygame.Surface((size, size))
        sprite.fill((0, 0, 0))
        steps = min(radius, 28)
        for i in range(steps, 0, -1):
            r = radius * i / steps
            k = strength * (1 - i / steps) ** 1.4 * 1.15
            pygame.draw.circle(sprite, _scaled(color, k), (radius, radius), r)
        _glow_cache[key] = sprite
    return sprite


def glow(surface, pos, radius, color, strength=1.0):
    sprite = glow_sprite(radius, color, strength)
    r = sprite.get_width() // 2
    surface.blit(sprite, (pos[0] - r, pos[1] - r), special_flags=pygame.BLEND_RGB_ADD)


def neon_circle(surface, pos, radius, color, width=3, glow_scale=2.6, strength=0.9):
    glow(surface, pos, radius * glow_scale, color, strength)
    pygame.draw.circle(surface, color, pos, radius, width)
    if width:
        pygame.draw.circle(surface, _scaled(color, 0.35), pos, max(1, radius - width))


def neon_polygon(surface, points, color, width=3, glow_radius=None, strength=1.0):
    if glow_radius:
        cx = sum(p[0] for p in points) / len(points)
        cy = sum(p[1] for p in points) / len(points)
        glow(surface, (cx, cy), glow_radius, color, strength)
    pygame.draw.polygon(surface, _scaled(color, 0.25), points)
    pygame.draw.polygon(surface, color, points, width)


def regular_polygon(center, radius, sides, angle):
    return [(center[0] + math.cos(angle + i * 2 * math.pi / sides) * radius,
             center[1] + math.sin(angle + i * 2 * math.pi / sides) * radius)
            for i in range(sides)]


def ship_points(center, radius, angle):
    """An arrowhead pointing along angle."""
    cx, cy = center
    pts = [(1.45, 0), (-0.95, 0.85), (-0.45, 0), (-0.95, -0.85)]
    ca, sa = math.cos(angle), math.sin(angle)
    return [(cx + (x * ca - y * sa) * radius, cy + (x * sa + y * ca) * radius) for x, y in pts]


class Background:
    """A dark grid that pulses when things happen, plus slowly drifting stars."""

    def __init__(self):
        rng = random.Random(42)
        self.stars = [(rng.uniform(0, S.WIDTH), rng.uniform(0, S.HEIGHT),
                       rng.uniform(4, 22), rng.randint(40, 120)) for _ in range(120)]
        self.pulse = 0.0
        self.pulse_color = S.PURPLE

    def kick(self, amount=1.0, color=S.PURPLE):
        self.pulse = min(1.2, self.pulse + amount * 0.6)
        self.pulse_color = color

    def update(self, dt):
        self.pulse = max(0.0, self.pulse - dt * 2.2)

    def draw(self, surface, t, origin=(0, 0)):
        """Draw the background over the whole surface. `origin` is where the
        1280x720 arena's top-left sits on this surface: stars and grid lines are
        laid out relative to it, so the arena canvas and the wider screen around
        it (ultrawide sides, 16:10 / 4:3 bands) line up seamlessly."""
        w, h = surface.get_size()
        ox, oy = round(origin[0]), round(origin[1])     # screen shake gives fractional offsets
        surface.fill(S.BG)

        # stars tile every 1280x720 around the arena
        tiles_x = range(-((ox + S.WIDTH - 1) // S.WIDTH), (w - ox) // S.WIDTH + 1)
        tiles_y = range(-((oy + S.HEIGHT - 1) // S.HEIGHT), (h - oy) // S.HEIGHT + 1)
        for x, y, speed, b in self.stars:
            sy = (y + t * speed) % S.HEIGHT
            for tx in tiles_x:
                for ty in tiles_y:
                    surface.fill((b // 2, b // 2, b),
                                 (ox + x + tx * S.WIDTH, oy + sy + ty * S.HEIGHT, 2, 2))

        pulse = min(self.pulse, 1.0)
        color = tuple(min(255, int(g * (1 + pulse * 0.5) + p * pulse * 0.09))
                      for g, p in zip(S.GRID, self.pulse_color))
        step = 64
        drift = (t * 12) % step
        for x in range(int((ox - drift) % step) - step, w + step, step):
            pygame.draw.line(surface, color, (x, 0), (x, h))
        for y in range(int((oy - drift) % step) - step, h + step, step):
            pygame.draw.line(surface, color, (0, y), (w, y))

        arena = pygame.Rect(ox, oy, S.WIDTH, S.HEIGHT)
        if (w, h) != (S.WIDTH, S.HEIGHT):
            # dim everything outside the arena so the eye stays on the action
            for rect in (pygame.Rect(0, 0, arena.left, h), pygame.Rect(arena.right, 0, w - arena.right, h),
                         pygame.Rect(arena.left, 0, S.WIDTH, arena.top),
                         pygame.Rect(arena.left, arena.bottom, S.WIDTH, h - arena.bottom)):
                if rect.width > 0 and rect.height > 0:
                    surface.fill((120, 120, 150), rect, special_flags=pygame.BLEND_RGB_MULT)

        m = S.ARENA_MARGIN
        edge = _scaled(S.PURPLE, 0.55 + self.pulse * 0.4)
        pygame.draw.rect(surface, edge, arena.inflate(-2 * m, -2 * m), 2, border_radius=6)


class Shake:
    def __init__(self):
        self.trauma = 0.0
        self.enabled = True

    def add(self, amount):
        self.trauma = min(1.0, self.trauma + amount)

    def update(self, dt):
        self.trauma = max(0.0, self.trauma - dt * 1.8)

    def offset(self, t):
        if not self.enabled or self.trauma <= 0:
            return 0, 0
        power = self.trauma ** 2 * 18
        return (math.sin(t * 73.1) * power, math.cos(t * 61.7) * power)


def text(surface, font, message, pos, color=S.WHITE, anchor="topleft", glow_color=None):
    img = font.render(message, True, color)
    rect = img.get_rect(**{anchor: pos})
    if glow_color:
        glow(surface, rect.center, max(rect.width, rect.height) * 0.75, glow_color, 0.35)
    surface.blit(img, rect)
    return rect
