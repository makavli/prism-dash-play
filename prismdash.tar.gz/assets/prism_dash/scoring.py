"""Combo and multiplier logic. Pure Python, no pygame, so it's easy to test."""

from prism_dash import settings as S


class Combo:
    """Kills in quick succession build a chain. Every KILLS_PER_LEVEL kills in
    the chain raise the multiplier by one, up to MAX_MULTIPLIER. The chain
    breaks if COMBO_WINDOW passes without a kill, or when the player is hit."""

    def __init__(self, window=S.COMBO_WINDOW):
        self.window = window          # the MOMENTUM perk makes this longer
        self.chain = 0
        self.timer = 0.0
        self.best_chain = 0

    @property
    def multiplier(self):
        return min(1 + self.chain // S.KILLS_PER_LEVEL, S.MAX_MULTIPLIER)

    @property
    def progress(self):
        """0..1 progress towards the next multiplier level (1 when maxed)."""
        if self.multiplier >= S.MAX_MULTIPLIER:
            return 1.0
        return (self.chain % S.KILLS_PER_LEVEL) / S.KILLS_PER_LEVEL

    def register_kill(self, base_points):
        """Record a kill and return the points it's worth."""
        self.chain += 1
        self.best_chain = max(self.best_chain, self.chain)
        self.timer = self.window
        return base_points * self.multiplier

    def update(self, dt):
        if self.chain:
            self.timer -= dt
            if self.timer <= 0:
                self.reset()

    def reset(self):
        self.chain = 0
        self.timer = 0.0
