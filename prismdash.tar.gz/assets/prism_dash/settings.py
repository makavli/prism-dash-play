"""Tuning constants. Most of the game's "feel" lives here."""

TITLE = "PRISM DASH"
WIDTH, HEIGHT = 1280, 720          # logical resolution; the window scales it
FPS = 360                          # upper cap only: vsync paces frames to the monitor (e.g. 164 Hz)
MAX_DT = 1 / 30                    # never simulate more than this per frame
ARENA_MARGIN = 24

# ---- Player ----
PLAYER_RADIUS = 13
PLAYER_ACCEL = 4200
PLAYER_MAX_SPEED = 430
PLAYER_FRICTION = 9.0              # higher = stops faster
DASH_SPEED = 1500
DASH_TIME = 0.17
DASH_COOLDOWN = 0.85
OVERDRIVE_COOLDOWN = 0.12
START_LIVES = 3
MAX_LIVES = 5
HIT_INVULN = 1.6
START_NOVAS = 1
MAX_NOVAS = 3

# ---- Combo ----
COMBO_WINDOW = 2.4                 # seconds before the chain breaks
KILLS_PER_LEVEL = 3                # kills needed to raise the multiplier
MAX_MULTIPLIER = 8

# ---- Drops ----
DROP_CHANCE = 0.07
POWERUP_LIFETIME = 9.0
OVERDRIVE_TIME = 7.0

# ---- Palette (neon on near-black) ----
BG = (7, 6, 16)
GRID = (22, 18, 48)
WHITE = (240, 240, 255)
CYAN = (60, 230, 255)
PINK = (255, 60, 170)
YELLOW = (255, 220, 60)
GREEN = (90, 255, 140)
ORANGE = (255, 140, 40)
PURPLE = (170, 90, 255)
RED = (255, 70, 70)
GOLD = (255, 200, 90)
LIME = (190, 255, 60)
EMERALD = (40, 255, 170)
