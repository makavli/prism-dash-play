"""PRISM DASH — a neon arena game where your dash is your only weapon.

Copyright (c) 2026 Massinissa K. All rights reserved.
See the LICENSE file for what you may and may not do with this code.
"""

__version__ = "2.1.5"
__author__ = "Massinissa K."
__copyright__ = "© 2026 Massinissa K. All rights reserved."
