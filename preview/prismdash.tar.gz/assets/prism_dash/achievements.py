"""Achievements: long-term goals across runs. Pure logic, checked against the
current run's stats; unlocked ids are saved by storage.py."""

ACHIEVEMENTS = {
    "first_blood":  ("FIRST BLOOD", "Destroy an enemy."),
    "hat_trick":    ("HAT TRICK", "Destroy 3 enemies in a single dash."),
    "chain6":       ("CHAIN REACTION", "Destroy 6 enemies in a single dash."),
    "maxed":        ("MAXED OUT", "Reach the x8 multiplier."),
    "core1":        ("BOSS BREAKER", "Defeat a boss."),
    "core3":        ("BOSS HUNTER", "Defeat 3 bosses in one run."),
    "flawless_core": ("FLAWLESS BOSS", "Beat a boss without getting hit."),
    "wave10":       ("SURVIVOR", "Reach wave 10."),
    "wave20":       ("VETERAN", "Reach wave 20."),
    "untouchable":  ("UNTOUCHABLE", "Clear 3 waves in a row unhit."),
    "bullet_eater": ("BULLET EATER", "Dash through 100 bullets in a run."),
    "supernova":    ("SUPERNOVA", "Destroy 10 enemies with one nova."),
    "backstab":     ("BACKSTABBER", "Destroy 15 Wardens in one run."),
    "builder":      ("BUILD CRAFTER", "Own 5 upgrades in one run."),
    "six_figures":  ("SIX FIGURES", "Score 100,000 points in one run."),
    "serpent":      ("SERPENT SLAYER", "Defeat the Serpent."),
    "blitzkrieg":   ("BLITZKRIEG", "Score 50,000 in a Blitz run."),
    "daily":        ("DAILY DEVOTEE", "Reach wave 5 in a Daily Run."),
}

# id -> test on the run's stats dict
_RULES = {
    "first_blood":   lambda s: s["kills"] >= 1,
    "hat_trick":     lambda s: s["best_dash_kills"] >= 3,
    "chain6":        lambda s: s["best_dash_kills"] >= 6,
    "maxed":         lambda s: s["max_multiplier"] >= 8,
    "core1":         lambda s: s["bosses"] >= 1,
    "core3":         lambda s: s["bosses"] >= 3,
    "flawless_core": lambda s: s["flawless_bosses"] >= 1,
    "wave10":        lambda s: s["wave"] >= 10,
    "wave20":        lambda s: s["wave"] >= 20,
    "untouchable":   lambda s: s["best_flawless_streak"] >= 3,
    "bullet_eater":  lambda s: s["bullets_destroyed"] >= 100,
    "supernova":     lambda s: s["best_nova_kills"] >= 10,
    "backstab":      lambda s: s["wardens"] >= 15,
    "builder":       lambda s: s["perks"] >= 5,
    "six_figures":   lambda s: s["score"] >= 100_000,
    "serpent":       lambda s: s.get("serpents", 0) >= 1,
    "blitzkrieg":    lambda s: s.get("mode") == "blitz" and s["score"] >= 50_000,
    "daily":         lambda s: s.get("mode") == "daily" and s["wave"] >= 5,
}


def newly_unlocked(stats, already):
    """Return the ids that the stats now satisfy and weren't unlocked before."""
    return [aid for aid, rule in _RULES.items() if aid not in already and rule(stats)]
