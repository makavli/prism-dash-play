"""Browser support. In the browser, PRISM DASH runs on pygbag (pygame-ce compiled to
WebAssembly). This module holds the few places where the browser differs from a
desktop: no threads, no quitting, saves go to localStorage, and fullscreen is the
browser's own.

Copyright (c) 2026 Massinissa K. All rights reserved.
"""

import json
import sys

IS_WEB = sys.platform == "emscripten"
STORAGE_PREFIX = "prism-dash/"


def _window():
    """The browser's JS `window` (pygbag exposes it as platform.window), or None."""
    if not IS_WEB:
        return None
    try:
        import platform
        return platform.window
    except (ImportError, AttributeError):
        return None


def browser_music():
    """The page's Web Audio music player (tools/web/theme.py adds it), or None.
    The browser plays the music itself: full quality, gapless, and it never ticks when
    a game frame runs late, because it doesn't depend on the game loop."""
    if not IS_WEB:
        return None
    try:
        player = _window().prismMusic
        return player if player else None
    except Exception:                  # noqa: BLE001 - no page / no player: SDL plays it
        return None


def sound_allowed(seen_input=False):
    """Browsers keep a page silent until it is clicked or a key is pressed (a pad button
    doesn't count). True once that happened; always True on desktop."""
    if not IS_WEB:
        return True
    window = _window()
    try:
        return bool(window.navigator.userActivation.hasBeenActive)
    except AttributeError:
        return seen_input
    except Exception:                  # noqa: BLE001 - any JS bridge error: fall back
        return seen_input


def local_storage():
    window = _window()
    try:
        return window.localStorage if window is not None else None
    except AttributeError:
        return None


def read_json(name, default, storage=None):
    """Read a JSON value saved in the browser. Never raises."""
    storage = storage if storage is not None else local_storage()
    if storage is None:
        return default
    try:
        raw = storage.getItem(STORAGE_PREFIX + name)
        return default if raw is None else json.loads(str(raw))
    except Exception:  # JS proxies raise their own error types
        return default


def write_json(name, data, storage=None):
    """Save a JSON value in the browser (survives reloads and new visits). Never raises."""
    storage = storage if storage is not None else local_storage()
    if storage is None:
        return
    try:
        storage.setItem(STORAGE_PREFIX + name, json.dumps(data))
    except Exception:
        pass  # private browsing or quota full: never crash over a save


def toggle_browser_fullscreen():
    """Fullscreen the page. Must run from a key or click handler (browser rule)."""
    window = _window()
    if window is None:
        return
    try:
        document = window.document
        if document.fullscreenElement:
            document.exitFullscreen()
        else:
            document.documentElement.requestFullscreen()
    except Exception:
        pass
