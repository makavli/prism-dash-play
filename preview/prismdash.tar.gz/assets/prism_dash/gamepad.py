"""Controllers: every pad works the same, and keyboard <-> controller is seamless.

- Desktop: SDL's game-controller layer, so Xbox, DualShock 4, DualSense, Switch Pro and
  most other pads all report the same buttons. Hot-plug works.
- Browser: the page's standard gamepad mapping (same buttons, read through the joystick API).
- The game sees PADBUTTON events with a name ("a", "b", "x", "y", "lb", "rb", "lt", "rt",
  "start", "back", "up", "down", "left", "right"). The left stick also sends up/down/left/
  right with key-repeat, so every menu works with the stick, the d-pad or the keyboard.
- Whatever you touched last decides the button prompts (keyboard, Xbox or PlayStation names)
  and whether the mouse cursor is shown: touch the pad and the cursor disappears.
- DualSense (desktop): light bar in your ship's colour, rumble, and adaptive triggers
  (R2 has a dash "trigger break", L2 a firm nova resistance). DualShock 4: light bar and rumble.

Copyright (c) 2026 Massinissa K. All rights reserved.
"""

import glob
import os
import re
import time

import pygame
from pygame.math import Vector2

from prism_dash import web

# Rumble and trigger effects over Bluetooth need SDL's "enhanced" PlayStation reports.
os.environ.setdefault("SDL_JOYSTICK_HIDAPI_PS4_RUMBLE", "1")
os.environ.setdefault("SDL_JOYSTICK_HIDAPI_PS5_RUMBLE", "1")
# A scaled window (bigger than 1280x720) is filtered smoothly, not blown up into blocky pixels.
os.environ.setdefault("SDL_RENDER_SCALE_QUALITY", "linear")

PADBUTTON = pygame.event.custom_type()

KEYBOARD, XBOX, PLAYSTATION = "keyboard", "xbox", "playstation"

STICK_DEADZONE = 0.2          # movement
NAV_THRESHOLD = 0.6           # stick as a d-pad in menus
NAV_DELAY, NAV_REPEAT = 0.38, 0.13
TRIGGER_PRESS = 0.5

# Browser "standard gamepad" button order, and the usual XInput order for a plain joystick.
WEB_BUTTONS = {0: "a", 1: "b", 2: "x", 3: "y", 4: "lb", 5: "rb", 6: "lt", 7: "rt", 8: "back", 9: "start",
               12: "up", 13: "down", 14: "left", 15: "right"}
XINPUT_BUTTONS = {0: "a", 1: "b", 2: "x", 3: "y", 4: "lb", 5: "rb", 6: "back", 7: "start"}

PLAYSTATION_WORDS = ("dualsense", "dualshock", "playstation", "ps4", "ps5", "wireless controller", "054c")

PROMPTS = {
    #            keyboard / mouse              Xbox              PlayStation
    "dash":    ("SPACE / LEFT CLICK",          "A / RT",         "CROSS / R2"),
    "nova":    ("E / RIGHT CLICK",             "B / LT",         "CIRCLE / L2"),
    "move":    ("WASD / ARROWS",               "LEFT STICK",     "LEFT STICK"),
    "confirm": ("ENTER",                       "A",              "CROSS"),
    "back":    ("ESC",                         "B",              "CIRCLE"),
    "pause":   ("ESC",                         "MENU",           "OPTIONS"),
    "restart": ("R",                           "Y",              "TRIANGLE"),
    "quit":    ("Q",                           "VIEW",           "CREATE"),
    "pick":    ("1 / 2 / 3, ARROWS + ENTER",   "D-PAD + A",      "D-PAD + CROSS"),
    "nova1":   ("E",                           "LT",             "L2"),
    "navigate": ("ARROWS / WASD",              "D-PAD / STICK",  "D-PAD / STICK"),
}

# The pad buttons behind each action, drawn as icons (render.draw_button).
PAD_BUTTONS = {
    "dash": ["a", "rt"], "nova": ["b", "lt"], "nova1": ["lt"], "move": ["lstick"],
    "confirm": ["a"], "back": ["b"], "pause": ["start"], "restart": ["y"], "quit": ["back"],
    "pick": ["dpad", "a"], "navigate": ["dpad", "lstick"],
}


def hint_parts(markup, device):
    """'{pause} resume  {quit} menu' -> parts for render.rich_text: keyboard gets the key
    names as text, a pad gets its button icons (a ':' right after an icon is dropped)."""
    parts = []
    pieces = re.split(r"\{(\w+)\}", markup)
    for i, piece in enumerate(pieces):
        if i % 2 == 0:
            if device != KEYBOARD and i > 0 and piece.startswith(":"):
                piece = piece[1:]
            if piece:
                parts.append(piece)
        elif device == KEYBOARD:
            parts.append(prompt(piece, device))
        else:
            for j, button in enumerate(PAD_BUTTONS[piece]):
                if j:
                    parts.append("/")
                parts.append(("button", button))
    return parts


# Rumble (low, high, milliseconds) for game moments.
FEEL = {
    "dash": (0.12, 0.30, 70),
    "kill": (0.20, 0.45, 60),
    "clang": (0.45, 0.15, 90),
    "hit": (0.85, 0.70, 380),         # you got hurt
    "nova": (1.00, 0.90, 520),
    "boss_hit": (0.50, 0.55, 120),
    "boss_die": (1.00, 1.00, 800),
    "gameover": (0.80, 0.40, 600),
    "power": (0.10, 0.35, 90),
    "wave": (0.15, 0.25, 140),
}


def is_playstation(name):
    name = (name or "").lower()
    return any(word in name for word in PLAYSTATION_WORDS)


def prompt(action, device):
    """The words for an action's button on the device in use."""
    keyboard, xbox, playstation = PROMPTS[action]
    return {KEYBOARD: keyboard, XBOX: xbox, PLAYSTATION: playstation}.get(device, keyboard)


class _SDLEffects:
    """DualSense extras SDL has but pygame doesn't expose (adaptive triggers). Talks to the
    very SDL library pygame already loaded. Any failure just turns the extras off."""

    PS4, PS5 = 4, 7

    def __init__(self):
        self.sdl = None
        if web.IS_WEB:
            return
        try:
            import ctypes              # desktop only: the browser's Python may not have it
        except ImportError:
            return
        self.ctypes = ctypes
        base = os.path.dirname(pygame.__file__)
        names = glob.glob(os.path.join(base, "SDL2.dll")) + glob.glob(os.path.join(base, ".dylibs", "libSDL2*")) \
            + glob.glob(os.path.join(os.path.dirname(base), "pygame_ce.libs", "libSDL2-*")) \
            + glob.glob(os.path.join(base, "libSDL2*"))
        for name in names:
            try:
                sdl = ctypes.CDLL(name)
                sdl.SDL_GameControllerOpen.restype = ctypes.c_void_p
                sdl.SDL_GameControllerOpen.argtypes = [ctypes.c_int]
                sdl.SDL_GameControllerGetType.argtypes = [ctypes.c_void_p]
                sdl.SDL_GameControllerSendEffect.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
                sdl.SDL_GameControllerClose.argtypes = [ctypes.c_void_p]
                self.sdl = sdl
                return
            except (OSError, AttributeError):
                continue

    def open(self, device_index):
        """(handle, type) for a pad, or (None, 0)."""
        if not self.sdl:
            return None, 0
        try:
            handle = self.sdl.SDL_GameControllerOpen(device_index)
            return (handle, self.sdl.SDL_GameControllerGetType(handle)) if handle else (None, 0)
        except (OSError, AttributeError):
            return None, 0

    def close(self, handle):
        if self.sdl and handle:
            try:
                self.sdl.SDL_GameControllerClose(handle)
            except OSError:
                pass

    def triggers(self, handle, right, left):
        """Sets both DualSense trigger effects (11-byte SDL / DualSense effect blocks)."""
        if not self.sdl or not handle:
            return
        ctypes = self.ctypes
        data = (ctypes.c_ubyte * 47)()
        data[0] = 0x04 | 0x08                    # right and left trigger effects present
        for i, v in enumerate(right[:11]):
            data[10 + i] = v
        for i, v in enumerate(left[:11]):
            data[21 + i] = v
        try:
            self.sdl.SDL_GameControllerSendEffect(handle, ctypes.byref(data), 47)
        except OSError:
            pass


TRIGGER_OFF = (0x05,)
TRIGGER_BREAK = (0x02, 0x40, 0x90, 0xC0)     # resistance that gives way: the "click" of a dash
TRIGGER_FIRM = (0x01, 0x10, 0x90)            # steady resistance from 6% of the pull
TRIGGER_STIFF = (0x01, 0x00, 0xFF)           # no novas left: heavy


class _Pad:
    def __init__(self, device_index, use_controller):
        self.controller = None
        self.joystick = None
        self.effects_handle = None
        self.sdl_type = 0
        if use_controller:
            from pygame._sdl2 import controller
            self.controller = controller.Controller(device_index)
            self.name = self.controller.name
            self.instance_id = self.controller.as_joystick().get_instance_id()
        else:
            self.joystick = pygame.joystick.Joystick(device_index)
            self.name = self.joystick.get_name()
            self.instance_id = self.joystick.get_instance_id()
        self.playstation = is_playstation(self.name)
        self.trigger_held = {"lt": False, "rt": False}

    def axis(self, which):
        """-1..1 sticks, 0..1 triggers. which: 'lx', 'ly', 'lt', 'rt'."""
        if self.controller:
            from pygame._sdl2 import controller as _c  # noqa: F401
            index = {"lx": pygame.CONTROLLER_AXIS_LEFTX, "ly": pygame.CONTROLLER_AXIS_LEFTY,
                     "lt": pygame.CONTROLLER_AXIS_TRIGGERLEFT, "rt": pygame.CONTROLLER_AXIS_TRIGGERRIGHT}[which]
            return max(-1.0, self.controller.get_axis(index) / 32767)
        if which in ("lx", "ly") and self.joystick.get_numaxes() >= 2:
            return self.joystick.get_axis(0 if which == "lx" else 1)
        return 0.0


class Pads:
    def __init__(self):
        self.device = KEYBOARD
        self.pads = {}                 # instance id -> _Pad
        self.use_controller = False
        if not web.IS_WEB:
            try:
                from pygame._sdl2 import controller
                controller.init()
                self.use_controller = True
            except (ImportError, pygame.error):
                self.use_controller = False
        pygame.joystick.init()
        self.effects = _SDLEffects()
        self.nav = {}                  # direction -> next repeat time
        self.light_colour = None
        self.trigger_state = None
        self._open_all()

    # ------------------------------------------------------------ connection
    def _open(self, device_index):
        try:
            if self.use_controller:
                from pygame._sdl2 import controller
                if not controller.is_controller(device_index):
                    return
            pad = _Pad(device_index, self.use_controller)
        except (pygame.error, IndexError):
            return
        if pad.instance_id in self.pads:
            return
        if self.use_controller:
            pad.effects_handle, pad.sdl_type = self.effects.open(device_index)
        self.pads[pad.instance_id] = pad
        self.trigger_state = None      # re-send to the new pad
        if self.light_colour:
            self.light(self.light_colour, force=True)

    def _open_all(self):
        for i in range(pygame.joystick.get_count()):
            self._open(i)

    def _remove(self, instance_id):
        pad = self.pads.pop(instance_id, None)
        if pad:
            self.effects.close(pad.effects_handle)
        if not self.pads and self.device != KEYBOARD:
            self._set_device(KEYBOARD)

    @property
    def connected(self):
        return bool(self.pads)

    # ------------------------------------------------------------ device in use
    def _set_device(self, device):
        if device != self.device:
            self.device = device
        # The cursor only belongs to the mouse: hidden as soon as a pad is used.
        try:
            pygame.mouse.set_visible(device == KEYBOARD)
        except pygame.error:
            pass

    def _pad_used(self, pad):
        self._set_device(PLAYSTATION if pad and pad.playstation else XBOX)

    def prompt(self, action):
        return prompt(action, self.device)

    # ------------------------------------------------------------ events
    def translate(self, events):
        """Raw pygame events -> the game's events: pad buttons become PADBUTTON events,
        joystick/controller noise is removed, and the device in use is tracked."""
        out = []
        now = time.monotonic()

        def press(name, pad):
            out.append(pygame.event.Event(PADBUTTON, button=name))
            self._pad_used(pad)

        for e in events:
            t = e.type
            if t in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, pygame.MOUSEWHEEL):
                self._set_device(KEYBOARD)
                out.append(e)
            elif t == pygame.MOUSEMOTION:
                rel = getattr(e, "rel", (0, 0))
                if abs(rel[0]) + abs(rel[1]) > 3:      # a desk bump doesn't take the pad away
                    self._set_device(KEYBOARD)
                out.append(e)
            elif t in (pygame.JOYDEVICEADDED, getattr(pygame, "CONTROLLERDEVICEADDED", -1)):
                self._open(e.device_index)
            elif t in (pygame.JOYDEVICEREMOVED, getattr(pygame, "CONTROLLERDEVICEREMOVED", -1)):
                self._remove(e.instance_id)
            elif self.use_controller and t == pygame.CONTROLLERBUTTONDOWN:
                name = CONTROLLER_BUTTONS.get(e.button)
                if name:
                    press(name, self.pads.get(e.instance_id))
            elif self.use_controller and t == pygame.CONTROLLERAXISMOTION:
                pad = self.pads.get(e.instance_id)
                axis = {pygame.CONTROLLER_AXIS_TRIGGERLEFT: "lt", pygame.CONTROLLER_AXIS_TRIGGERRIGHT: "rt"}.get(e.axis)
                if pad and axis:
                    held = e.value / 32767 > TRIGGER_PRESS
                    if held and not pad.trigger_held[axis]:
                        press(axis, pad)
                    pad.trigger_held[axis] = held
            elif not self.use_controller and t == pygame.JOYBUTTONDOWN:
                pad = self.pads.get(e.instance_id)
                name = (WEB_BUTTONS if web.IS_WEB else XINPUT_BUTTONS).get(e.button)
                if name:
                    press(name, pad)
            elif not self.use_controller and t == pygame.JOYHATMOTION:
                x, y = e.value
                for cond, name in ((y > 0, "up"), (y < 0, "down"), (x < 0, "left"), (x > 0, "right")):
                    if cond:
                        press(name, self.pads.get(e.instance_id))
            elif t in (pygame.JOYBUTTONDOWN, pygame.JOYBUTTONUP, pygame.JOYAXISMOTION, pygame.JOYHATMOTION,
                       pygame.JOYBALLMOTION) or t in _CONTROLLER_NOISE:
                continue               # handled through the controller layer
            else:
                out.append(e)

        # Left stick as a d-pad (menus), with key repeat.
        stick = self.stick(deadzone=0.0)
        if stick.length() > 0.35:
            self._pad_used(next(iter(self.pads.values()), None))
        wanted = set()
        if stick.y < -NAV_THRESHOLD: wanted.add("up")          # noqa: E701
        if stick.y > NAV_THRESHOLD: wanted.add("down")         # noqa: E701
        if stick.x < -NAV_THRESHOLD: wanted.add("left")        # noqa: E701
        if stick.x > NAV_THRESHOLD: wanted.add("right")        # noqa: E701
        for name in list(self.nav):
            if name not in wanted:
                del self.nav[name]
        for name in wanted:
            if name not in self.nav:
                self.nav[name] = now + NAV_DELAY
                out.append(pygame.event.Event(PADBUTTON, button=name, stick=True))
            elif now >= self.nav[name]:
                self.nav[name] = now + NAV_REPEAT
                out.append(pygame.event.Event(PADBUTTON, button=name, stick=True))
        return out

    def stick(self, deadzone=STICK_DEADZONE):
        """The left stick of the pad with the biggest push (radial dead zone, rescaled)."""
        best = Vector2()
        for pad in self.pads.values():
            try:
                v = Vector2(pad.axis("lx"), pad.axis("ly"))
            except pygame.error:
                continue
            if v.length() > best.length():
                best = v
        length = best.length()
        if length <= deadzone or length == 0:
            return Vector2()
        if deadzone <= 0:
            return best
        return best / length * min(1.0, (length - deadzone) / (1 - deadzone))

    # ------------------------------------------------------------ feedback
    def feel(self, moment):
        """Rumble for a game moment (see FEEL)."""
        spec = FEEL.get(moment)
        if not spec:
            return
        low, high, ms = spec
        for pad in self.pads.values():
            if pad.controller:
                try:
                    pad.controller.rumble(low, high, ms)
                except pygame.error:
                    pass
            elif hasattr(pad.joystick, "rumble"):
                try:
                    pad.joystick.rumble(low, high, ms)
                except pygame.error:
                    pass

    def light(self, colour, force=False):
        """PlayStation light bar colour."""
        colour = tuple(int(c) for c in colour[:3])
        if colour == self.light_colour and not force:
            return
        self.light_colour = colour
        for pad in self.pads.values():
            if pad.controller and pad.playstation:
                try:
                    pad.controller.set_led(colour)
                except pygame.error:
                    pass

    def triggers(self, state):
        """DualSense adaptive triggers: 'off', 'play' (dash break + firm nova) or 'play_no_nova'."""
        if state == self.trigger_state:
            return
        self.trigger_state = state
        right, left = {"play": (TRIGGER_BREAK, TRIGGER_FIRM),
                       "play_no_nova": (TRIGGER_BREAK, TRIGGER_STIFF)}.get(state, (TRIGGER_OFF, TRIGGER_OFF))
        for pad in self.pads.values():
            if pad.sdl_type == _SDLEffects.PS5:
                self.effects.triggers(pad.effects_handle, right, left)

    def close(self):
        """Leave the pad as we found it: no trigger resistance, no rumble."""
        self.triggers("off")
        for pad in self.pads.values():
            try:
                if pad.controller:
                    pad.controller.stop_rumble()
            except pygame.error:
                pass


CONTROLLER_BUTTONS = {
    getattr(pygame, "CONTROLLER_BUTTON_A", -1): "a",
    getattr(pygame, "CONTROLLER_BUTTON_B", -1): "b",
    getattr(pygame, "CONTROLLER_BUTTON_X", -1): "x",
    getattr(pygame, "CONTROLLER_BUTTON_Y", -1): "y",
    getattr(pygame, "CONTROLLER_BUTTON_LEFTSHOULDER", -1): "lb",
    getattr(pygame, "CONTROLLER_BUTTON_RIGHTSHOULDER", -1): "rb",
    getattr(pygame, "CONTROLLER_BUTTON_START", -1): "start",
    getattr(pygame, "CONTROLLER_BUTTON_BACK", -1): "back",
    getattr(pygame, "CONTROLLER_BUTTON_DPAD_UP", -1): "up",
    getattr(pygame, "CONTROLLER_BUTTON_DPAD_DOWN", -1): "down",
    getattr(pygame, "CONTROLLER_BUTTON_DPAD_LEFT", -1): "left",
    getattr(pygame, "CONTROLLER_BUTTON_DPAD_RIGHT", -1): "right",
}
_CONTROLLER_NOISE = {getattr(pygame, n) for n in ("CONTROLLERBUTTONUP", "CONTROLLERAXISMOTION", "CONTROLLERBUTTONDOWN",
                                                   "CONTROLLERDEVICEREMAPPED", "CONTROLLERSENSORUPDATE",
                                                   "CONTROLLERTOUCHPADDOWN", "CONTROLLERTOUCHPADMOTION",
                                                   "CONTROLLERTOUCHPADUP") if hasattr(pygame, n)}
