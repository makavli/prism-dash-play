"""Which enemies appear in each wave. Pure Python, no pygame.

Each enemy type has a cost and the wave it first appears in. A wave gets a
budget that grows with its number and buys a random mix of unlocked types.
Every BOSS_EVERY-th wave is a boss wave with a small escort instead.
"""

import random

BOSS_EVERY = 5

# type -> (cost, first wave, weight)
ENEMY_TYPES = {
    "drifter":  (1, 1, 5),
    "dart":     (2, 2, 3),
    "splitter": (3, 3, 2),
    "spinner":  (3, 4, 2),
    "warden":   (4, 6, 2),
    "weaver":   (4, 8, 2),
}


BOSSES = ("boss", "serpent")


def is_boss_wave(n):
    return n % BOSS_EVERY == 0


def boss_for(n):
    """The Core on waves 5, 15, 25... and the Serpent on 10, 20, 30..."""
    return "serpent" if n % (2 * BOSS_EVERY) == 0 else "boss"


def budget_for(n):
    return int(4 + n * 2.3 + (n // BOSS_EVERY) * 2)


def unlocked(n):
    return [name for name, (_, first, _) in ENEMY_TYPES.items() if first <= n]


def wave_plan(n, rng=None):
    """Return the list of enemy type names for wave n (1-based)."""
    rng = rng or random.Random()
    if is_boss_wave(n):
        escort = ["drifter"] * (2 + n // BOSS_EVERY)
        return [boss_for(n)] + escort

    names = unlocked(n)
    weights = [ENEMY_TYPES[name][2] for name in names]
    budget = budget_for(n)
    plan = []
    # Always show off the newest enemy type in the wave it unlocks.
    newest = [name for name in names if ENEMY_TYPES[name][1] == n]
    for name in newest:
        plan.append(name)
        budget -= ENEMY_TYPES[name][0]
    while budget > 0:
        affordable = [(nm, w) for nm, w in zip(names, weights) if ENEMY_TYPES[nm][0] <= budget]
        if not affordable:
            break
        choice = rng.choices([nm for nm, _ in affordable], [w for _, w in affordable])[0]
        plan.append(choice)
        budget -= ENEMY_TYPES[choice][0]
    rng.shuffle(plan)
    return plan


def scale_plan(plan, factor, rng=None):
    """More or fewer enemies (difficulty). The boss and at least one enemy always stay;
    extra enemies are copies of the wave's own types, so the wave keeps its character."""
    rng = rng or random.Random()
    if factor == 1.0 or not plan:
        return list(plan)
    boss = [plan[0]] if plan[0] in BOSSES else []
    rest = plan[len(boss):]
    if not rest:
        return list(plan)
    target = max(1, round(len(rest) * factor))
    if target < len(rest):
        rest = rng.sample(rest, target)
    else:
        rest = rest + [rng.choice(rest) for _ in range(target - len(rest))]
    return boss + rest


def spawn_groups(plan, group_size=4):
    """Split a plan into groups that spawn a couple of seconds apart, so a wave
    builds up instead of appearing all at once. The boss always comes first."""
    if plan and plan[0] in BOSSES:
        return [[plan[0]]] + spawn_groups(plan[1:], group_size)
    return [plan[i:i + group_size] for i in range(0, len(plan), group_size)]


def enemy_speed_scale(n):
    """Enemies get a little faster each wave, capped so it stays fair."""
    return min(1.0 + (n - 1) * 0.035, 1.6)
