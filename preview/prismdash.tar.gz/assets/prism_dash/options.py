"""OPTIONS: every setting on four pages - DISPLAY, GRAPHICS, AUDIO, CONTROLS.

Keyboard, mouse and controller all work: up/down picks a row, left/right changes it,
Q/E (L1/R1) or clicking a tab flips the page, ESC (CIRCLE/B) goes back.
Settings are saved as soon as they change.

Copyright (c) 2026 Massinissa K. All rights reserved.
"""

import pygame

from prism_dash import gpu, hires, render, storage, web
from prism_dash import settings as S
from prism_dash.gamepad import PADBUTTON, STICK_DEADZONE

PAGES = ("DISPLAY", "GRAPHICS", "AUDIO", "CONTROLS")
DEADZONES = (0.1, 0.15, 0.2, 0.25, 0.3, 0.35)
TAB_Y, ROW_Y, ROW_STEP = 150, 232, 58
LABEL_X, VALUE_X = 250, 1030


class Row:
    """One line: a choice (values cycle), a 0..10 slider, or an action."""

    def __init__(self, label, kind, get=None, put=None, values=None, run=None, note=None):
        self.label, self.kind = label, kind
        self.get, self.put, self.values, self.run, self.note = get, put, values, run, note

    def value(self):
        return self.get() if self.get else None

    def step(self, direction):
        """Change the value one notch (direction -1 / +1). True if anything changed."""
        if self.kind == "action":
            if direction > 0 and self.run:
                self.run()
                return True
            return False
        current = self.value()
        if self.kind == "slider":
            new = max(0, min(10, current + direction))
        else:
            new = self.values[(self.values.index(current) + direction) % len(self.values)]
        if new == current:
            return False
        self.put(new)
        return True

    def text(self):
        if self.kind == "slider":
            return f"{self.value() * 10}%"
        if self.kind == "choice":
            return str(self.value())
        return ""


def apply_settings(app):
    """Push the saved settings into the parts of the game they control (at start-up too)."""
    s = app.settings
    app.audio.set_volumes(s.get("volume", 10) / 10, s.get("music_volume", 10) / 10, s.get("sfx_volume", 10) / 10)
    pads = app.pads
    pads.rumble_on = s.get("rumble", True)
    pads.light_on = s.get("light_bar", True)
    pads.triggers_on = s.get("adaptive_triggers", True)
    pads.deadzone = s.get("deadzone", STICK_DEADZONE)
    app.show_fps = s.get("show_fps", False)
    app.shake.enabled = s.get("shake", True)


class OptionsMenu:
    def __init__(self, app):
        self.app = app
        self.page = 0
        self.index = 0

    # ---------------------------------------------------------------- the rows
    def rows(self):
        app, s = self.app, self.app.settings
        on_off = ("ON", "OFF")

        def flag(key, default=True):
            return (lambda: "ON" if s.get(key, default) else "OFF",
                    lambda v: self._set(key, v == "ON"))

        page = PAGES[self.page]
        if page == "DISPLAY":
            rows = []
            if web.IS_WEB:
                rows.append(Row("FULLSCREEN", "action", run=app.toggle_fullscreen, note="the browser page fills the screen"))
            else:
                rows.append(Row("DISPLAY MODE", "choice", values=("BORDERLESS", "FULLSCREEN", "WINDOWED"),
                                get=lambda: app.display_mode.upper(),
                                put=lambda v: app.set_display(v.lower()),
                                note="borderless = instant alt-tab   fullscreen = exclusive   F11 toggles"))
            get, put = flag("show_fps", False)
            rows.append(Row("SHOW FPS", "choice", values=on_off, get=get, put=lambda v, put=put: (put(v), self._apply()),
                            note="frames per second in the corner (F3)"))
            get, put = flag("shake")
            rows.append(Row("SCREEN SHAKE", "choice", values=on_off, get=get, put=lambda v, put=put: (put(v), self._apply())))
            return rows

        if page == "GRAPHICS":
            rows = []
            if gpu.available():
                rows.append(Row("GRAPHICS", "choice", values=("ULTRA", "STANDARD"),
                                get=lambda: s.get("graphics", "ultra").upper(),
                                put=lambda v: self._set("graphics", v.lower()),
                                note=self._graphics_note()))
            if app.gpu is not None:
                rows.append(Row("RESOLUTION", "choice", values=("NATIVE", "FAST"),
                                get=lambda: "NATIVE" if hires.active() else "FAST",
                                put=self._set_resolution,
                                note="native = drawn at your screen's pixels   fast = more frames"))
            rows.append(Row("EFFECTS", "choice", values=("FULL", "LIGHT"),
                            get=lambda: "LIGHT" if s.get("effects", "high") == "low" else "FULL",
                            put=self._set_effects, note="light skips the glow and the busy background"))
            if not web.IS_WEB:
                rows.append(Row("BENCHMARK", "action", run=app.start_benchmark, note="a 10 s fight that measures this PC"))
            return rows

        if page == "AUDIO":
            get, put = (lambda: "OFF" if s["muted"] else "ON"), self._set_sound
            rows = [Row("SOUND", "choice", values=on_off, get=get, put=put, note="M mutes at any time")]
            for label, key in (("MASTER VOLUME", "volume"), ("MUSIC", "music_volume"), ("SOUND EFFECTS", "sfx_volume")):
                rows.append(Row(label, "slider", get=lambda key=key: s.get(key, 10),
                                put=lambda v, key=key: (self._set(key, v), self._apply(), app.audio.play("select"))))
            return rows

        # CONTROLS
        rows = []
        for label, key, note in (("VIBRATION", "rumble", "rumble on dashes, hits and kills"),
                                 ("ADAPTIVE TRIGGERS", "adaptive_triggers", "DualSense: R2 clicks on a dash, L2 firm with a nova"),
                                 ("LIGHT BAR", "light_bar", "PlayStation pads glow in your ship's colour")):
            get, put = flag(key)
            rows.append(Row(label, "choice", values=on_off, get=get, put=lambda v, put=put: (put(v), self._apply()), note=note))
        rows.append(Row("STICK DEAD ZONE", "choice", values=tuple(f"{round(d * 100)}%" for d in DEADZONES),
                        get=lambda: f"{round(s.get('deadzone', STICK_DEADZONE) * 100)}%",
                        put=lambda v: (self._set("deadzone", int(v[:-1]) / 100), self._apply()),
                        note="raise it if your ship drifts on its own"))
        rows.append(Row("KEYS AND BUTTONS", "action", run=self._show_controls, note="every control, keyboard and pad"))
        return rows

    # ---------------------------------------------------------------- changes
    def _set(self, key, value):
        self.app.settings[key] = value
        storage.save_settings(self.app.settings)

    def _apply(self):
        apply_settings(self.app)

    def _graphics_note(self):
        wanted = self.app.settings.get("graphics", "ultra")
        active = "ultra" if self.app.gpu is not None else "standard"
        if wanted != active:
            return "takes effect when the game restarts"
        return "ultra = the graphics card paints the sky, light and bloom"

    def _set_resolution(self, value):
        self._set("resolution", value.lower())
        self.app.rebuild_gpu_display()

    def _set_effects(self, value):
        effects = "low" if value == "LIGHT" else "high"
        self._set("effects", effects)
        self.app.background.effects = effects
        self.app.demo.bg.effects = effects

    def _set_sound(self, value):
        self._set("muted", value == "OFF")
        self.app.audio.set_muted(self.app.settings["muted"])

    def _show_controls(self):
        self.app.state = "howto"
        self.app.howto_back = "options"

    # ---------------------------------------------------------------- input
    def open(self):
        self.page, self.index = 0, 0

    def back(self):
        self.app.audio.play("select")
        self.app.state = "menu"

    def flip(self, direction):
        self.page = (self.page + direction) % len(PAGES)
        self.index = 0
        self.app.audio.play("select", 0.5)

    def move(self, direction):
        count = len(self.rows())
        self.index = (self.index + direction) % count
        self.app.audio.play("select", 0.4)

    def change(self, direction):
        rows = self.rows()
        self.index = min(self.index, len(rows) - 1)
        if rows[self.index].step(direction) and rows[self.index].kind != "slider":
            self.app.audio.play("select")

    def handle(self, events):
        for e in events:
            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_UP, pygame.K_w):
                    self.move(-1)
                elif e.key in (pygame.K_DOWN, pygame.K_s):
                    self.move(1)
                elif e.key in (pygame.K_LEFT, pygame.K_a):
                    self.change(-1)
                elif e.key in (pygame.K_RIGHT, pygame.K_d, pygame.K_RETURN, pygame.K_SPACE):
                    self.change(1)
                elif e.key in (pygame.K_q, pygame.K_e):
                    self.flip(-1 if e.key == pygame.K_q else 1)
                elif e.key == pygame.K_TAB:
                    self.flip(-1 if e.mod & pygame.KMOD_SHIFT else 1)
                elif e.key in (pygame.K_ESCAPE, pygame.K_BACKSPACE):
                    self.back()
            elif e.type == pygame.MOUSEMOTION:
                hit = self.row_at(e.pos)
                if hit is not None:
                    self.index = hit
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button in (1, 3):
                for i, rect in enumerate(self.tab_rects()):
                    if rect.collidepoint(e.pos) and i != self.page:
                        self.page, self.index = i, 0
                        self.app.audio.play("select", 0.5)
                        break
                else:
                    hit = self.row_at(e.pos)
                    if hit is not None:
                        self.index = hit
                        self.click(e.pos, -1 if e.button == 3 else 1)
            elif e.type == pygame.MOUSEWHEEL:
                self.change(1 if e.y > 0 else -1)
            elif e.type == PADBUTTON:
                b = e.button
                if b in ("up", "down"):
                    self.move(-1 if b == "up" else 1)
                elif b in ("left", "right"):
                    self.change(-1 if b == "left" else 1)
                elif b == "a":
                    self.change(1)
                elif b in ("lb", "rb"):
                    self.flip(-1 if b == "lb" else 1)
                elif b in ("b", "back", "start"):
                    self.back()

    def click(self, pos, direction):
        """A click on a row: a slider jumps to the clicked segment, anything else steps."""
        row = self.rows()[self.index]
        if row.kind == "slider" and direction > 0:
            left, w, gap = self._slider_geometry()
            if left <= pos[0] <= left + 10 * (w + gap):
                value = max(0, min(10, int((pos[0] - left) // (w + gap)) + 1))
                if value != row.value():
                    row.put(value)
                return
        self.change(direction)

    @staticmethod
    def _slider_geometry():
        segments, w, gap = 10, 26, 5
        right = VALUE_X - 70
        return right - segments * w - (segments - 1) * gap, w, gap

    def tab_rects(self):
        width, gap = 210, 16
        left = S.WIDTH / 2 - (len(PAGES) * width + (len(PAGES) - 1) * gap) / 2
        return [pygame.Rect(left + i * (width + gap), TAB_Y - 24, width, 48) for i in range(len(PAGES))]

    def row_rect(self, i):
        return pygame.Rect(LABEL_X - 30, ROW_Y + i * ROW_STEP - 24, VALUE_X - LABEL_X + 60, 48)

    def row_at(self, pos):
        for i in range(len(self.rows())):
            if self.row_rect(i).collidepoint(pos):
                return i
        return None

    # ---------------------------------------------------------------- drawing
    def draw(self, screen, fonts, hint):
        render.text(screen, fonts["big"], "OPTIONS", (S.WIDTH / 2, 48), S.WHITE, anchor="midtop", glow_color=S.CYAN)
        for i, (name, rect) in enumerate(zip(PAGES, self.tab_rects())):
            on = i == self.page
            if on:
                pygame.draw.rect(screen, (30, 24, 60), rect, border_radius=10)
                pygame.draw.rect(screen, S.CYAN, rect, 2, border_radius=10)
                render.glow(screen, rect.center, rect.width * 0.45, S.CYAN, 0.25)
            render.text(screen, fonts["small"], name, rect.center, S.WHITE if on else (130, 130, 170), anchor="center")

        rows = self.rows()
        self.index = min(self.index, len(rows) - 1)
        for i, row in enumerate(rows):
            rect = self.row_rect(i)
            selected = i == self.index
            y = rect.centery
            if selected:
                pygame.draw.rect(screen, (24, 20, 48), rect, border_radius=10)
                pygame.draw.rect(screen, (90, 80, 160), rect, 1, border_radius=10)
                pygame.draw.polygon(screen, S.CYAN, render.ship_points((LABEL_X - 14, y), 8, 0))
            colour = S.WHITE if selected else (160, 160, 195)
            render.text(screen, fonts["medium"], row.label, (LABEL_X, y), colour, anchor="midleft")
            if row.kind == "slider":
                self._slider(screen, fonts, row.value(), y, selected)
            elif row.kind == "choice":
                value = row.text()
                tint = S.GOLD if selected else (200, 200, 230)
                vr = render.text(screen, fonts["medium"], value, (VALUE_X - 26, y), tint, anchor="midright")
                if selected:
                    for x, d in ((vr.left - 18, -1), (VALUE_X - 8, 1)):
                        pts = [(x + 6 * d, y), (x - 4 * d, y - 8), (x - 4 * d, y + 8)]
                        pygame.draw.polygon(screen, S.CYAN, pts)
            else:
                render.text(screen, fonts["small"], "OPEN" if selected else "", (VALUE_X - 10, y), S.GOLD, anchor="midright")
        note = rows[self.index].note
        if note:
            render.text(screen, fonts["small"], note, (S.WIDTH / 2, ROW_Y + len(rows) * ROW_STEP + 14),
                        (150, 150, 200), anchor="midtop")
        hint("{navigate}  move     {change}  change     {page}  page     {back}  back",
             (S.WIDTH / 2, S.HEIGHT - 34), "tiny", (130, 130, 170))

    def _slider(self, screen, fonts, value, y, selected):
        left, w, gap = self._slider_geometry()
        for i in range(10):
            rect = pygame.Rect(left + i * (w + gap), y - 9, w, 18)
            if i < value:
                pygame.draw.rect(screen, S.CYAN if selected else (90, 170, 210), rect, border_radius=4)
            else:
                pygame.draw.rect(screen, (60, 56, 96), rect, 1, border_radius=4)
        render.text(screen, fonts["small"], f"{value * 10}%", (VALUE_X - 8, y), S.GOLD if selected else (200, 200, 230),
                    anchor="midright")
