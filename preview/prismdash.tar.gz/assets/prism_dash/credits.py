"""The end credits that roll after a won run (and the music credits, kept in one place).

Copyright (c) 2026 Massinissa K. All rights reserved.
"""

# Every track the game plays: (what it's for, title, artist, licence, where it's from).
MUSIC = [
    ("menu", "A start to space", "Centurion_of_war", "CC0", "opengameart.org"),
    ("run", "Space City", "MintoDog", "CC0", "opengameart.org"),
    ("boss", "Synthwave House Loop", "Fupi", "CC0", "opengameart.org"),
]


def roll():
    """The credits, top to bottom: (kind, text) with kind = title / heading / line / gap."""
    lines = [("title", "PRISM DASH"), ("gap", ""),
             ("heading", "A GAME BY"), ("line", "Massinissa K."), ("gap", ""),
             ("heading", "IDEA, DESIGN AND DIRECTION"), ("line", "Massinissa K."), ("gap", ""),
             ("heading", "MADE WITH"), ("line", "Claude, by Anthropic"), ("gap", ""),
             ("heading", "MUSIC")]
    for _use, title, artist, licence, source in MUSIC:
        lines.append(("line", f"\"{title}\"  -  {artist}"))
        lines.append(("small", f"{licence}, {source}"))
    lines += [("gap", ""),
              ("heading", "BUILT WITH"), ("line", "pygame-ce  -  moderngl  -  pygbag"), ("gap", ""),
              ("heading", "PLAY-TESTED BY"), ("line", "you"), ("gap", ""), ("gap", ""),
              ("title", "THANK YOU FOR PLAYING"),
              ("small", "© 2026 Massinissa K. All rights reserved.")]
    return lines
