"""One run of the game: waves, collisions, scoring, upgrades. No input or
window code here — the app passes in a Controls object each frame, which is
what lets the autopilot and the headless tests drive the exact same game."""

import math
import random
from dataclasses import dataclass, field

import pygame
from pygame import Vector2

from prism_dash import modes, perks, render, waves
from prism_dash import settings as S
from prism_dash.entities import ENEMY_CLASSES, Boss, Bullet, Player, PowerUp
from prism_dash.scoring import Combo


@dataclass
class Controls:
    move: Vector2 = field(default_factory=Vector2)
    dash: bool = False                 # pressed this frame
    dash_target: Vector2 = None        # aim the dash at this point (mouse), else move direction
    nova: bool = False                 # pressed this frame
    pick: int = None                   # choose upgrade card 0/1/2 during a draft


TIPS = {
    "dart": "darts charge along their laser line",
    "splitter": "splitters break apart",
    "spinner": "dash THROUGH bullets to destroy them",
    "warden": "hit wardens from behind - their shield bounces you",
    "weaver": "weavers lay mines - dash through them before they burst",
}


class World:
    INTERMISSION = 2.0
    GROUP_DELAY = 2.6
    MARKER_TIME = 0.9
    DASH_BUFFER = 0.12

    def __init__(self, audio, particles, shake, background, seed=None, mode="classic", ship=None):
        self.audio, self.particles, self.shake, self.bg = audio, particles, shake, background
        self.rng = random.Random(seed)
        self.mode = mode
        self.player = Player(ship)
        self.blitz = mode == "blitz"
        self.time_left = modes.BLITZ_TIME if self.blitz else None
        if self.blitz:                    # Blitz: no waiting around
            self.INTERMISSION, self.GROUP_DELAY = 0.8, 1.7
        self.enemies, self.bullets, self.powerups = [], [], []
        self.markers = []                 # [kind, pos, time_left]
        self.combo = Combo()
        self.score = 0
        self.wave = 0
        self.t = 0.0
        self.state = "intermission"
        self.timer = 1.2
        self.groups = []
        self.group_timer = 0.0
        self.hitstop = 0.0
        self.slowmo = 0.0
        self.flash = 0.0                  # red screen flash after a hit
        self.banner = None                # (text, subtitle, time_left, color)
        self.draft = None                 # list of perk ids on offer, or None
        self.over = False
        self.hits_this_wave = 0
        self.buffered_dash = None         # (seconds left, target) of a dash waiting to happen
        self.buffered_nova = False
        self.stats = {
            "kills": 0, "dashes": 0, "best_dash_kills": 0, "max_multiplier": 1,
            "bosses": 0, "flawless_bosses": 0, "flawless_streak": 0, "best_flawless_streak": 0,
            "bullets_destroyed": 0, "best_nova_kills": 0, "wardens": 0, "serpents": 0,
        }

    # ---------------- helpers used by entities and the app ----------------
    @property
    def speed_scale(self):
        return waves.enemy_speed_scale(max(1, self.wave))

    @property
    def boss(self):
        return next((e for e in self.enemies if isinstance(e, Boss)), None)

    def run_stats(self):
        """Everything achievements are judged on."""
        return {**self.stats, "wave": self.wave, "score": self.score, "mode": self.mode,
                "perks": sum(self.player.perks.values()) - sum(self.player.ship.perks.values())}

    def add_enemy(self, enemy):
        self.enemies.append(enemy)

    def spawn_bullet(self, pos, vel, color, radius=5):
        if len(self.bullets) < 600:
            self.bullets.append(Bullet(pos, vel, color, radius))

    def spawn_marker(self, kind, pos=None):
        if pos is None:
            pos = self._spawn_point(boss=(kind in waves.BOSSES))
        pos = Vector2(max(S.ARENA_MARGIN + 30, min(S.WIDTH - S.ARENA_MARGIN - 30, pos.x)),
                      max(S.ARENA_MARGIN + 30, min(S.HEIGHT - S.ARENA_MARGIN - 30, pos.y)))
        self.markers.append([kind, pos, self.MARKER_TIME * (1.6 if kind in waves.BOSSES else 1)])

    def _spawn_point(self, boss=False):
        if boss:
            return Vector2(S.WIDTH / 2, S.HEIGHT / 2 - 120) if self.player.pos.y > S.HEIGHT / 2 \
                else Vector2(S.WIDTH / 2, S.HEIGHT / 2 + 120)
        for _ in range(30):
            p = Vector2(self.rng.uniform(80, S.WIDTH - 80), self.rng.uniform(80, S.HEIGHT - 80))
            if p.distance_to(self.player.pos) > 260:
                return p
        return Vector2(80, 80)

    def show_banner(self, text, subtitle="", color=S.WHITE, duration=1.8):
        self.banner = (text, subtitle, duration, color)

    # ---------------- upgrades ----------------
    def choose_perk(self, index):
        if not self.draft or not 0 <= index < len(self.draft):
            return False
        pid = self.draft[index]
        p = self.player
        p.perks[pid] = p.perks.get(pid, 0) + 1
        if pid == "vitality":
            p.lives += 1
        elif pid == "novacache":
            p.novas += 1
        elif pid == "barrier":
            p.barrier = True
        elif pid == "momentum":
            self.combo.window = S.COMBO_WINDOW + p.perk("momentum")
        self.draft = None
        self.buffered_dash = None           # the click that picked a card isn't a dash
        self.audio.play("power")
        self.particles.ring(p.pos, perks.PERKS[pid].color, speed=500, life=0.5, width=4)
        self.particles.popup(p.pos - Vector2(0, 34), perks.PERKS[pid].name, perks.PERKS[pid].color, "medium")
        return True

    # ---------------- waves ----------------
    def _start_wave(self):
        self.wave += 1
        self.hits_this_wave = 0
        if self.player.perk("barrier"):
            self.player.barrier = True
        plan = waves.wave_plan(self.wave, self.rng)
        self.groups = waves.spawn_groups(plan)
        self.group_timer = 0.0
        self.state = "fighting"
        if waves.boss_for(self.wave) == "serpent" and waves.is_boss_wave(self.wave):
            self.show_banner("THE SERPENT", f"wave {self.wave}  -  shred its body, then strike the head",
                             S.EMERALD, 2.6)
        elif waves.is_boss_wave(self.wave):
            self.show_banner("THE CORE", f"wave {self.wave}  -  dash into it to break it", S.PINK, 2.4)
        else:
            new = [n for n, (_, first, _) in waves.ENEMY_TYPES.items() if first == self.wave]
            subtitle = f"new: {TIPS[new[0]]}" if new and new[0] in TIPS else ""
            self.show_banner(f"WAVE {self.wave}", subtitle, S.CYAN)
        self.audio.play("wave", 0.8)

    def _wave_cleared(self):
        bonus = 250 * self.wave
        flawless = self.hits_this_wave == 0
        if flawless:
            bonus *= 2
            self.stats["flawless_streak"] += 1
            self.stats["best_flawless_streak"] = max(self.stats["best_flawless_streak"],
                                                     self.stats["flawless_streak"])
        else:
            self.stats["flawless_streak"] = 0
        self.score += bonus
        title = "FLAWLESS!" if flawless else "WAVE CLEARED"
        subtitle = f"+{bonus} bonus"
        if self.blitz:
            self.time_left += modes.BLITZ_CLEAR_BONUS
            subtitle += f"   +{modes.BLITZ_CLEAR_BONUS:.0f}s"
        self.show_banner(title, subtitle, S.GOLD if flawless else S.GREEN, 1.6)
        self.state, self.timer = "intermission", self.INTERMISSION
        if perks.is_draft_wave(self.wave):
            offer = perks.offer(self.player.perks, self.rng)
            if offer:
                self.draft = offer

    def _update_waves(self, dt):
        if self.state == "intermission":
            self.timer -= dt
            if self.timer <= 0:
                self._start_wave()
            return
        self.group_timer -= dt
        idle = not self.enemies and not self.markers
        if self.groups and (self.group_timer <= 0 or idle):
            for kind in self.groups.pop(0):
                self.spawn_marker(kind)
            self.group_timer = self.GROUP_DELAY
        elif not self.groups and idle:
            self._wave_cleared()

    # ---------------- the frame ----------------
    def update(self, dt, controls):
        if self.draft:                    # the game waits while you pick an upgrade
            if controls.pick is not None:
                self.choose_perk(controls.pick)
            return
        # Input buffering: a dash/nova pressed slightly early (or during a
        # freeze-frame) still happens as soon as it can, so no press is lost.
        if controls.dash:
            self.buffered_dash = (self.DASH_BUFFER, controls.dash_target)
        if controls.nova:
            self.buffered_nova = True
        self.flash = max(0.0, self.flash - dt)
        if self.hitstop > 0:              # freeze-frame for impact
            self.hitstop -= dt
            return
        if self.slowmo > 0:
            self.slowmo -= dt
            dt *= 0.3
        self.t += dt
        if self.blitz and not self.over:
            self.time_left -= dt
            if self.time_left <= 0:
                self.time_left = 0.0
                self._time_up()
        if self.banner:
            text, sub, left, color = self.banner
            self.banner = (text, sub, left - dt, color) if left > dt else None

        p = self.player
        if self.buffered_dash:
            left, target = self.buffered_dash
            direction = (target - p.pos) if target is not None else Vector2(controls.move)
            if p.try_dash(direction, self):
                self.stats["dashes"] += 1
                self.bg.ripple(p.pos, 0.35)
                self.buffered_dash = None
            else:
                self.buffered_dash = (left - dt, target) if left > dt else None
        if self.buffered_nova:
            self.buffered_nova = False
            self.use_nova()
        was_dashing = p.dashing
        p.update(self, dt, controls.move)
        self.bg.focus = (p.pos.x, p.pos.y)

        for marker in self.markers:
            marker[2] -= dt
            if marker[2] <= 0:
                cls = ENEMY_CLASSES[marker[0]]
                self.add_enemy(cls(marker[1], self))
                self.particles.ring(marker[1], cls.color, speed=260, life=0.3, width=2)
        self.markers = [m for m in self.markers if m[2] > 0]

        for e in self.enemies:
            e.update(self, dt)
        for b in self.bullets:
            b.update(dt)
        magnet = p.perk("magnet")
        for pu in self.powerups:
            pu.update(dt)
            if magnet and pu.pos.distance_to(p.pos) < 260 + 80 * magnet:
                pu.pos += (p.pos - pu.pos).normalize() * 520 * dt if pu.pos != p.pos else Vector2()

        self._collide()
        self.enemies = [e for e in self.enemies if e.alive]
        self.bullets = [b for b in self.bullets if b.alive]
        self.powerups = [pu for pu in self.powerups if pu.alive]

        if was_dashing and not p.dashing and p.kills_this_dash:
            self._dash_finished()

        self.combo.update(dt)
        if not self.over:
            self._update_waves(dt)

    def _dash_finished(self):
        p = self.player
        n = p.kills_this_dash
        self.stats["best_dash_kills"] = max(self.stats["best_dash_kills"], n)
        if n >= 3:
            self.particles.popup(p.pos - Vector2(0, 30), f"{n} IN ONE DASH!", S.GOLD, "medium")
        p.kills_this_dash = 0

    def _shockwave(self, pos):
        """SHOCKWAVE perk: an enemy killed by a dash explodes, taking neighbours with it.
        Blast kills don't explode themselves, so it can't chain forever."""
        radius = 55 + 30 * self.player.perk("shockwave")
        self.particles.ring(pos, S.PINK, speed=radius * 3.2, life=0.3, width=4)
        self.shake.add(0.15)
        for e in self.enemies:
            if e.alive and not isinstance(e, Boss) and e.age >= e.spawn_grace \
                    and e.pos.distance_to(pos) < radius + e.radius:
                self.kill(e, by_dash=False)

    # ---------------- collisions ----------------
    def _collide(self):
        p = self.player
        if self.over:
            return
        for e in self.enemies:
            if not e.alive or e.age < e.spawn_grace or p.pos.distance_to(e.pos) > p.radius + e.radius:
                continue
            if p.dashing:
                result = e.dash_hit(self)
                if result == "kill":
                    self.kill(e, by_dash=True)
                elif result == "bounce":
                    self._bounce_off(e, strength=650)
                    e.flash = 0.15
                    self.audio.play("clang")
                    self.particles.burst(p.pos, S.GOLD, count=14, speed=260, life=0.3)
                elif result == "damage" and e.take_hit(self):
                    self._bounce_off(e, strength=750)
                    p.refill()
                    self.audio.play("boss_hit")
                    self.shake.add(0.35)
                    self.hitstop = 0.07
                    self.bg.kick(0.8, S.PINK, pos=e.pos)
                    if not e.alive:
                        self.kill(e, by_dash=False)
            elif not p.safe and e.hurts:
                self.hurt_player()
                return

        bounty = p.perk("bounty")
        for b in self.bullets:
            d = p.pos.distance_to(b.pos)
            if p.dashing and d < p.radius + b.radius + 8:
                b.alive = False
                self.stats["bullets_destroyed"] += 1
                self.score += (15 if bounty else 5) * self.combo.multiplier
                if bounty and self.combo.chain:
                    self.combo.timer = self.combo.window
                self.particles.burst(b.pos, b.color, count=5, speed=160, life=0.25, size=2)
            elif not p.safe and d < p.radius * 0.7 + b.radius:
                b.alive = False
                self.hurt_player()
                return

        for pu in self.powerups:
            if p.pos.distance_to(pu.pos) < p.radius + pu.radius + 6:
                pu.alive = False
                self._collect(pu)

    def _bounce_off(self, enemy, strength):
        p = self.player
        away = p.pos - enemy.pos
        away = away.normalize() if away.length_squared() > 0 else Vector2(1, 0)
        p.end_dash()
        p.vel = away * strength
        p.pos = enemy.pos + away * (enemy.radius + p.radius + 2)
        p.invuln = max(p.invuln, 0.25)

    def kill(self, enemy, by_dash):
        enemy.alive = False
        enemy.on_death(self)
        old_mult = self.combo.multiplier
        points = self.combo.register_kill(enemy.points)
        self.score += points
        self.stats["kills"] += 1
        if enemy.kind == "warden":
            self.stats["wardens"] += 1
        mult = self.combo.multiplier
        self.stats["max_multiplier"] = max(self.stats["max_multiplier"], mult)
        self.particles.popup(enemy.pos, f"{points}" + (f" x{mult}" if mult > 1 else ""),
                             S.GOLD if mult >= 4 else S.WHITE, "small")
        self.audio.kill(self.combo.chain - 1)
        self.shake.add(0.12)
        self.bg.kick(0.35, enemy.color, pos=enemy.pos)
        if mult > old_mult and mult in (4, 6, 8):
            callout = {4: "x4  NICE!", 6: "x6  ON FIRE!", 8: "x8  UNSTOPPABLE!"}[mult]
            self.particles.popup(self.player.pos - Vector2(0, 60), callout, S.GOLD, "big")
            self.audio.play("milestone")
            self.bg.kick(1.0, S.GOLD)
        if by_dash:
            self.player.refund_dash()
            self.hitstop = max(self.hitstop, 0.018)
            if self.player.perk("shockwave"):
                self._shockwave(enemy.pos)
        if isinstance(enemy, Boss):
            self.stats["bosses"] += 1
            if enemy.kind == "serpent":
                self.stats["serpents"] += 1
            if self.hits_this_wave == 0:
                self.stats["flawless_bosses"] += 1
            self.audio.play("boss_die")
            self.slowmo = 1.4
            self.shake.add(1.0)
            self.bg.kick(1.5, S.PINK, pos=enemy.pos)
            self.bullets.clear()
            self.show_banner(f"{enemy.title} DESTROYED", f"+{points}", S.GOLD, 2.4)
            p = self.player
            self.powerups.append(PowerUp(enemy.pos, "life" if p.lives < p.max_lives else "nova"))
        elif enemy.drops and self.rng.random() < S.DROP_CHANCE * (1 + 0.6 * self.player.perk("magnet")):
            self._drop(enemy.pos)

    def _drop(self, pos):
        p = self.player
        options = ["overdrive", "overdrive"]
        if p.lives < p.max_lives:
            options += ["life"]
        if p.novas < p.max_novas:
            options += ["nova"]
        self.powerups.append(PowerUp(pos, self.rng.choice(options)))

    def _collect(self, pu):
        p = self.player
        if pu.kind == "life":
            p.lives = min(p.max_lives, p.lives + 1)
        elif pu.kind == "nova":
            p.novas = min(p.max_novas, p.novas + 1)
        else:
            p.overdrive = p.overdrive_duration
        self.audio.play("power")
        self.particles.popup(pu.pos - Vector2(0, 20), pu.label, pu.color, "medium")
        self.particles.ring(pu.pos, pu.color, speed=300, life=0.4)

    def hurt_player(self):
        p = self.player
        if p.barrier:                     # the BARRIER perk soaks the hit
            p.barrier = False
            p.invuln = 1.0
            p.end_dash()
            self.audio.play("clang")
            self.shake.add(0.4)
            self.particles.ring(p.pos, S.WHITE, speed=600, life=0.4, width=5)
            self.particles.popup(p.pos - Vector2(0, 30), "BARRIER BROKEN", S.WHITE, "small")
            for b in self.bullets:
                if b.pos.distance_to(p.pos) < 200:
                    b.alive = False
            return
        if self.blitz:                    # Blitz: a hit costs time, not a life
            self.time_left = max(0.0, self.time_left - modes.BLITZ_HIT_PENALTY)
            self.particles.popup(p.pos - Vector2(0, 40), f"-{modes.BLITZ_HIT_PENALTY:.0f}s", S.RED, "big")
        else:
            p.lives -= 1
        p.invuln = S.HIT_INVULN
        p.end_dash()
        self.hits_this_wave += 1
        if p.perk("keeper") and self.combo.chain:
            self.combo.chain //= 2
            self.combo.timer = self.combo.window
        else:
            self.combo.reset()
        self.audio.play("hit")
        self.shake.add(0.75)
        self.hitstop = 0.12
        self.flash = 0.35
        self.bg.kick(1.2, S.RED, pos=p.pos)
        self.particles.burst(p.pos, S.RED, count=40, speed=450, life=0.7)
        self.particles.ring(p.pos, S.RED, speed=700, life=0.5, width=5)
        # clear nearby bullets so you don't get hit twice in a row
        for b in self.bullets:
            if b.pos.distance_to(p.pos) < 240:
                b.alive = False
        if p.lives <= 0 or (self.blitz and self.time_left <= 0):
            self._end_run()

    def _time_up(self):
        self.show_banner("TIME!", f"{self.score:,} points", S.GOLD, 3.0)
        self._end_run()

    def _end_run(self):
        p = self.player
        self.over = True
        self.particles.burst(p.pos, p.ship.color, count=120, speed=700, life=1.4, size=4)
        self.audio.play("gameover")
        self.slowmo = 1.0

    def use_nova(self):
        p = self.player
        if p.novas <= 0 or self.over:
            return
        p.novas -= 1
        self.audio.play("nova")
        self.shake.add(0.9)
        self.bg.kick(1.5, S.PURPLE, pos=p.pos)
        for i, color in enumerate((S.WHITE, S.PURPLE, S.PINK)):
            self.particles.ring(p.pos, color, speed=1400 - i * 300, life=0.8, width=8 - i * 2)
        for b in self.bullets:
            b.alive = False
        supernova = p.perk("supernova")
        if supernova:
            p.refill()
        kills = 0
        for e in list(self.enemies):
            if isinstance(e, Boss):
                for _ in range(2 if supernova else 1):
                    e.invuln = 0
                    e.take_hit(self)
                if not e.alive:
                    self.kill(e, by_dash=False)
            elif e.alive:
                self.kill(e, by_dash=False)
                kills += 1
        self.stats["best_nova_kills"] = max(self.stats["best_nova_kills"], kills)

    # ---------------- drawing ----------------
    def draw(self, surface):
        for kind, pos, left in self.markers:
            cls = ENEMY_CLASSES[kind]
            k = 1 - left / (self.MARKER_TIME * (1.6 if kind in waves.BOSSES else 1))
            r = cls.radius * (2.4 - 1.4 * k)
            color = tuple(int(c * (0.3 + 0.7 * k)) for c in cls.color)
            pygame.draw.aacircle(surface, color, pos, r, 2)
            render.glow(surface, pos, cls.radius * 1.5, cls.color, 0.25 + 0.5 * k * (math.sin(self.t * 30) > 0))
        for pu in self.powerups:
            pu.draw(surface, self.t)
        for e in self.enemies:
            e.draw(surface, self.t)
        for b in self.bullets:
            b.draw(surface)
        if not self.over:
            self.player.draw(surface, self.t)
        self.particles.draw(surface)
