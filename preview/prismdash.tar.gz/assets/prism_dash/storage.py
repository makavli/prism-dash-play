"""High scores and settings, saved per user (not next to the .exe, which may be read-only)."""

import json
import os
from datetime import date
from pathlib import Path

from prism_dash import web

MAX_SCORES = 5


def data_dir():
    override = os.environ.get("PRISM_DASH_DATA")
    if override:
        return Path(override)
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "PrismDash"


def _path(name):
    return data_dir() / name


def _read(name, default):
    if web.IS_WEB:
        return web.read_json(name, default)
    try:
        return json.loads(_path(name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(name, data):
    if web.IS_WEB:
        web.write_json(name, data)
        return
    try:
        path = _path(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError:
        pass  # never crash the game over a save file


def _scores_file(board):
    # Classic keeps the original file name so v1 high scores carry over.
    return "scores.json" if board == "classic" else f"scores-{board}.json"


def load_scores(board="classic"):
    scores = _read(_scores_file(board), [])
    if not isinstance(scores, list):
        return []
    valid = [s for s in scores if isinstance(s, dict) and isinstance(s.get("score"), int)]
    return sorted(valid, key=lambda s: s["score"], reverse=True)[:MAX_SCORES]


def qualifies(score, scores=None, board="classic"):
    scores = load_scores(board) if scores is None else scores
    return score > 0 and (len(scores) < MAX_SCORES or score > scores[-1]["score"])


def add_score(score, wave, best_chain, board="classic", ship="prism"):
    """Save a score. Returns its rank (1-based) or None if it didn't make the table."""
    scores = load_scores(board)
    if not qualifies(score, scores):
        return None
    entry = {"score": score, "wave": wave, "chain": best_chain, "ship": ship,
             "date": date.today().isoformat()}
    scores.append(entry)
    scores.sort(key=lambda s: s["score"], reverse=True)
    scores = scores[:MAX_SCORES]
    _write(_scores_file(board), scores)
    return scores.index(entry) + 1


def load_achievements():
    data = _read("achievements.json", {})
    return data if isinstance(data, dict) else {}


def unlock_achievements(ids):
    """Record achievement ids (with today's date). Returns the full dict."""
    data = load_achievements()
    for aid in ids:
        data.setdefault(aid, date.today().isoformat())
    _write("achievements.json", data)
    return data


LIFETIME_KEYS = ("games", "kills", "bosses", "waves", "dashes", "seconds")


def load_lifetime():
    data = _read("lifetime.json", {})
    data = data if isinstance(data, dict) else {}
    return {k: int(data.get(k, 0)) for k in LIFETIME_KEYS}


def add_lifetime(**amounts):
    data = load_lifetime()
    for key, value in amounts.items():
        if key in data:
            data[key] += int(value)
    _write("lifetime.json", data)
    return data


def load_settings():
    defaults = {"muted": False, "fullscreen": True, "display": "borderless", "shake": True, "mode": "classic", "ship": "prism", "effects": "high", "graphics": "ultra", "resolution": "native"}
    data = _read("settings.json", {})
    return {**defaults, **(data if isinstance(data, dict) else {})}


def save_settings(settings):
    _write("settings.json", settings)
