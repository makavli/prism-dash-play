"""Game modes."""

from dataclasses import dataclass
from datetime import date

from prism_dash import ships


@dataclass(frozen=True)
class Mode:
    id: str
    name: str
    description: str


MODES = [
    Mode("classic", "CLASSIC", "Endless waves. Upgrades, bosses, three lives. How far can you go?"),
    Mode("daily", "DAILY RUN", "Same waves, same upgrades on offer and same ship for everyone today."),
    Mode("blitz", "BLITZ", "3 minutes. Faster waves. Getting hit costs 10 seconds instead of a life."),
    Mode("bossrush", "BOSS RUSH", "The five sector bosses, back to back, an upgrade after each. Win it all."),
]
BY_ID = {m.id: m for m in MODES}

BLITZ_TIME = 180.0
BLITZ_HIT_PENALTY = 10.0
BLITZ_CLEAR_BONUS = 8.0


def daily_seed(day=None):
    day = day or date.today()
    return int(day.strftime("%Y%m%d"))


def daily_ship(day=None):
    """Today's ship. Daily runs can use ships you haven't unlocked yet."""
    seed = daily_seed(day)
    return ships.SHIPS[(seed * 7919) % len(ships.SHIPS)]


def score_key(mode_id, day=None):
    """Which leaderboard a run goes on."""
    if mode_id == "daily":
        return f"daily-{(day or date.today()).isoformat()}"
    return mode_id
