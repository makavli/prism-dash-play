"""V3: a run crosses five sectors of space, five waves each, the fifth one a boss.

Each sector has its own look (the sky's tint, the grid's colour, the ULTRA nebula's
colours), its own music and its own boss. Beat the fifth sector's boss and the run is won.
Pure data, no pygame: the world and the backgrounds read it.

Copyright (c) 2026 Massinissa K. All rights reserved.
"""

from dataclasses import dataclass

from prism_dash import waves

WAVES_PER_SECTOR = waves.BOSS_EVERY          # waves 1-5 = sector 1, 6-10 = sector 2, ...


@dataclass(frozen=True)
class Sector:
    name: str
    tagline: str
    accent: tuple            # banners, HUD
    grid: tuple              # the arena grid's resting colour
    sky_tint: tuple          # multiplies the painted sky (STANDARD graphics), 1.0 = as painted
    nebula: tuple            # three colours (0..1 floats) for the ULTRA nebula
    boss: str                # which boss guards the sector's last wave
    music: str               # the run's music for this sector (audio.TRACKS key)


SECTORS = (
    Sector("OUTER RIM", "where every pilot starts", (60, 230, 255), (22, 18, 48), (1.0, 1.0, 1.0),
           ((0.42, 0.12, 0.78), (0.04, 0.48, 0.72), (0.92, 0.16, 0.52)), "boss", "play"),
    Sector("ION STORM", "the air crackles: stay moving", (110, 170, 255), (14, 24, 58), (0.72, 0.92, 1.35),
           ((0.10, 0.20, 0.85), (0.05, 0.62, 0.95), (0.55, 0.85, 1.00)), "serpent", "play"),
    Sector("EMBER BELT", "burning rock and hotter tempers", (255, 140, 60), (48, 20, 16), (1.35, 0.82, 0.58),
           ((0.75, 0.18, 0.05), (0.95, 0.45, 0.08), (0.55, 0.05, 0.25)), "boss", "play"),
    Sector("GLASS NEBULA", "nothing here is what it seems", (150, 255, 240), (14, 38, 44), (0.88, 1.18, 1.25),
           ((0.15, 0.62, 0.72), (0.70, 0.92, 1.00), (0.35, 0.45, 0.90)), "serpent", "play"),
    Sector("THE RIFT", "the edge of everything", (210, 90, 255), (30, 10, 44), (0.85, 0.55, 1.12),
           ((0.30, 0.03, 0.48), (0.60, 0.02, 0.36), (0.10, 0.02, 0.22)), "boss", "play"),
)

FINAL_WAVE = WAVES_PER_SECTOR * len(SECTORS)      # 25: its boss falls -> the run is won


def index_for_wave(n):
    """0-based sector of wave n (1-based); waves past the last sector stay in it."""
    return min(max(n - 1, 0) // WAVES_PER_SECTOR, len(SECTORS) - 1)


def for_wave(n):
    return SECTORS[index_for_wave(n)]


def starts_sector(n):
    """True on the first wave of every sector (1, 6, 11, ...)."""
    return n >= 1 and (n - 1) % WAVES_PER_SECTOR == 0 and n <= FINAL_WAVE


def is_final_wave(n):
    return n == FINAL_WAVE


def lerp_colour(a, b, k):
    return tuple(x + (y - x) * k for x, y in zip(a, b))


class Palette:
    """The look between sectors: eases from one sector's colours to the next over a few
    seconds, so a new sector washes in instead of popping."""

    FADE = 3.5

    def __init__(self, index=0):
        self.src = self.dst = index
        self.k = 1.0

    def go(self, index, instant=False):
        """Ease to sector `index` (instant=True: jump there, e.g. a new run)."""
        if instant:
            self.src = self.dst = index
            self.k = 1.0
        elif index != self.dst:
            self.src, self.dst, self.k = self.dst, index, 0.0

    def update(self, dt):
        if self.k < 1.0:
            self.k = min(1.0, self.k + dt / self.FADE)

    def _mix(self, field):
        a, b = getattr(SECTORS[self.src], field), getattr(SECTORS[self.dst], field)
        k = self.k * self.k * (3 - 2 * self.k)                # smoothstep
        return lerp_colour(a, b, k)

    @property
    def fading(self):
        return self.k < 1.0

    def grid(self):
        return tuple(int(v) for v in self._mix("grid"))

    def sky_tint(self):
        return self._mix("sky_tint")

    def nebula(self):
        a, b = SECTORS[self.src].nebula, SECTORS[self.dst].nebula
        k = self.k * self.k * (3 - 2 * self.k)
        return tuple(lerp_colour(x, y, k) for x, y in zip(a, b))
