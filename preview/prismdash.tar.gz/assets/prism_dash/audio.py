"""All sound is synthesized at startup — no audio files to ship.

If there's no audio device (or mixer init fails), the game runs silently.
"""

import math
import random
import threading
from array import array

import pygame

from prism_dash import web

RATE = 22050


# --------------------------------------------------------------------------
# Tiny synthesizer: returns lists of floats in -1..1
# --------------------------------------------------------------------------
def _osc(kind, phase, rng):
    if kind == "sine":
        return math.sin(phase)
    if kind == "square":
        return 1.0 if math.sin(phase) >= 0 else -1.0
    if kind == "saw":
        return (phase / math.pi) % 2.0 - 1.0
    if kind == "tri":
        return 2.0 * abs((phase / math.pi) % 2.0 - 1.0) - 1.0
    return rng.uniform(-1.0, 1.0)  # noise


def tone(f0, f1, dur, kind="sine", vol=0.5, attack=0.005, curve=4.0, seed=1):
    """A sound sweeping from f0 to f1 Hz with a sharp attack and exponential decay."""
    rng = random.Random(seed)
    n = int(RATE * dur)
    out = [0.0] * n
    phase = 0.0
    for i in range(n):
        t = i / n
        freq = f0 + (f1 - f0) * t
        phase += 2 * math.pi * freq / RATE
        env = min(1.0, i / (attack * RATE + 1)) * math.exp(-curve * t)
        out[i] = _osc(kind, phase, rng) * env * vol
    return out


def mix(*parts, offset=None):
    """Add sounds together; offset[i] delays part i by that many seconds."""
    offset = offset or [0] * len(parts)
    length = max(len(p) + int(o * RATE) for p, o in zip(parts, offset))
    out = [0.0] * length
    for part, off in zip(parts, offset):
        start = int(off * RATE)
        for i, v in enumerate(part):
            out[start + i] += v
    return out


def to_sound(samples, channels):
    data = array("h")
    for v in samples:
        s = int(max(-1.0, min(1.0, v)) * 32000)
        data.extend([s] * channels)
    return pygame.mixer.Sound(buffer=data.tobytes())


# --------------------------------------------------------------------------
# The game's sound effects
# --------------------------------------------------------------------------
PENTATONIC = [0, 3, 5, 7, 10]


def _note(base, step):
    octave, degree = divmod(step, len(PENTATONIC))
    return base * 2 ** ((PENTATONIC[degree] + 12 * octave) / 12)


def build_effects():
    fx = {
        "dash": mix(tone(1400, 300, 0.20, "noise", 0.35, curve=6),
                    tone(700, 200, 0.16, "sine", 0.25, curve=5)),
        "hit": mix(tone(160, 40, 0.45, "saw", 0.55, curve=4),
                   tone(0, 0, 0.30, "noise", 0.45, curve=7, seed=3)),
        "clang": mix(tone(920, 900, 0.30, "square", 0.18, curve=9),
                     tone(1310, 1290, 0.30, "square", 0.12, curve=9)),
        "power": mix(*(tone(_note(523, s), _note(523, s), 0.12, "tri", 0.35, curve=3)
                       for s in (0, 2, 4, 5)),
                     offset=[0, 0.06, 0.12, 0.18]),
        "nova": mix(tone(80, 30, 1.1, "saw", 0.5, curve=2.5),
                    tone(0, 0, 1.0, "noise", 0.5, curve=3, seed=7),
                    tone(2000, 200, 0.6, "sine", 0.25, curve=3)),
        "wave": mix(tone(659, 659, 0.35, "tri", 0.35, curve=3),
                    tone(988, 988, 0.5, "tri", 0.3, curve=3), offset=[0, 0.12]),
        "shoot": tone(900, 500, 0.07, "square", 0.08, curve=6),
        "spawn": tone(200, 600, 0.25, "sine", 0.10, attack=0.1, curve=2),
        "boss_hit": mix(tone(300, 90, 0.35, "square", 0.3, curve=5),
                        tone(0, 0, 0.25, "noise", 0.35, curve=6, seed=11)),
        "boss_die": mix(tone(120, 20, 2.2, "saw", 0.55, curve=2),
                        tone(0, 0, 2.0, "noise", 0.55, curve=2.2, seed=13),
                        tone(1500, 100, 1.2, "sine", 0.3, curve=2)),
        "select": tone(660, 880, 0.08, "tri", 0.3, curve=4),
        "ready": tone(1320, 1320, 0.06, "sine", 0.12, curve=7),
        "milestone": mix(*(tone(_note(523, s), _note(523, s), 0.18, "square", 0.14, curve=4)
                           for s in (0, 2, 4, 7)),
                         offset=[0, 0.05, 0.10, 0.15]),
        "achievement": mix(*(tone(_note(659, s), _note(659, s), 0.3, "tri", 0.3, curve=3)
                             for s in (0, 4, 7)),
                           offset=[0, 0.09, 0.18]),
        "gameover": mix(*(tone(_note(220, s), _note(220, s) * 0.98, 0.4, "tri", 0.35, curve=3)
                          for s in (4, 2, 1, 0)),
                        offset=[0, 0.2, 0.4, 0.6]),
    }
    # Kill "pops" climb a pentatonic scale as the chain grows: chains sound like music.
    for i in range(12):
        f = _note(392, i)
        fx[f"kill{i}"] = mix(tone(f, f * 1.02, 0.14, "square", 0.16, curve=6),
                             tone(f * 2, f * 2, 0.10, "sine", 0.12, curve=8),
                             tone(0, 0, 0.06, "noise", 0.12, curve=10, seed=i))
    return fx


def build_music():
    """An 8-second loop: kick, offbeat hats, a bass line and a soft arpeggio
    over Am - F - C - G at 120 bpm."""
    beat = 0.5
    chords = [(110.0, 0), (87.31, 8), (130.81, 3), (98.0, 10)]   # bass root, arp offset
    n = int(RATE * beat * 16)
    out = [0.0] * n
    rng = random.Random(5)

    def add(start, samples):
        s = int(start * RATE)
        for i, v in enumerate(samples):
            if s + i < n:
                out[s + i] += v

    kick = tone(150, 45, 0.18, "sine", 0.55, curve=7)
    hat = tone(0, 0, 0.04, "noise", 0.10, curve=12, seed=9)
    for b in range(16):
        add(b * beat, kick)
        add(b * beat + beat / 2, hat)
    for bar, (root, arp) in enumerate(chords):
        for eighth in range(8):
            start = (bar * 4 + eighth / 2) * beat
            f = root if eighth % 4 != 3 else root * 1.5
            add(start, tone(f, f, beat / 2, "saw", 0.13, attack=0.01, curve=3))
        for sixteenth in range(16):
            start = (bar * 4 + sixteenth / 4) * beat
            step = [0, 2, 4, 2, 5, 4, 2, 4][sixteenth % 8] + (arp % 5)
            f = _note(440, step)
            add(start, tone(f, f, beat / 4, "tri", 0.05 + 0.02 * rng.random(), curve=5))
    return out


class Audio:
    def __init__(self, muted=False):
        self.enabled = False
        self.muted = muted
        self.sounds = {}
        self.music = None
        self.music_channel = None
        try:
            if not pygame.mixer.get_init():
                # The browser feeds sound from the same thread as the game: a bigger buffer
                # rides over slow frames instead of crackling (46 ms instead of 23 ms).
                pygame.mixer.init(RATE, -16, 2, 1024 if web.IS_WEB else 512)
            self.channels = pygame.mixer.get_init()[2]
            pygame.mixer.set_num_channels(24)
            self.sounds = {k: to_sound(v, self.channels) for k, v in build_effects().items()}
            self.enabled = True
        except (pygame.error, OSError):
            return
        try:
            threading.Thread(target=self._prepare_music, daemon=True).start()
        except RuntimeError:            # no threads (browser): ~1 s at load instead
            self._prepare_music()

    def _prepare_music(self):
        try:
            self.music = to_sound(build_music(), self.channels)
            self.music.set_volume(0.45)
            if not self.muted:
                self.start_music()
        except (pygame.error, OSError):
            self.music = None

    def start_music(self):
        if self.enabled and self.music and not self.muted:
            if self.music_channel is None or not self.music_channel.get_busy():
                self.music_channel = self.music.play(loops=-1)

    def set_muted(self, muted):
        self.muted = muted
        if not self.enabled:
            return
        if muted:
            pygame.mixer.stop()
            self.music_channel = None
        else:
            self.start_music()

    def play(self, name, volume=1.0):
        if self.enabled and not self.muted and name in self.sounds:
            sound = self.sounds[name]
            sound.set_volume(volume)
            sound.play()

    def kill(self, chain):
        self.play(f"kill{min(chain, 11)}")
