"""ULTRA graphics (Windows): the graphics card finishes every frame.

The game still draws itself as always (pygame, at its logical size). This module takes
that picture and builds the final image on the GPU (OpenGL 3.3 through moderngl), at the
window's full resolution:

  1. a live sky: a domain-warped nebula, three depths of twinkling stars and 3D-lit
     planets with atmospheres and rings, scrolling as the ship cruises through space;
  2. the game layer on top, upscaled with a sharp bicubic filter, its neon pushed into
     HDR so it glows like real light;
  3. shockwaves that bend everything around kills, novas and boss hits;
  4. post: wide multi-level bloom, horizontal lens streaks, colour fringing on impacts,
     filmic tone mapping (saturation kept), vignette, film grain and dithering.

Anything going wrong (no OpenGL 3.3, no moderngl) means App falls back to the classic
renderer. Copyright (c) 2026 Massinissa K. All rights reserved.
"""

import struct

from prism_dash import sectors

MAX_WAVES = 8
BLOOM_LEVELS = 6

VERTEX = """
#version 330
in vec2 in_pos;
out vec2 uv;
void main() {
    uv = in_pos * 0.5 + 0.5;
    gl_Position = vec4(in_pos, 0.0, 1.0);
}
"""

NOISE = """
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    return mix(mix(hash12(i), hash12(i + vec2(1, 0)), u.x),
               mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
    float v = 0.0, a = 0.5;
    mat2 r = mat2(0.8, 0.6, -0.6, 0.8);
    for (int i = 0; i < 6; i++) { v += a * vnoise(p); p = r * p * 2.03 + 17.0; a *= 0.5; }
    return v;
}
float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}
float vnoise3(vec3 p) {
    vec3 i = floor(p), f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float a = mix(mix(hash13(i), hash13(i + vec3(1,0,0)), u.x), mix(hash13(i + vec3(0,1,0)), hash13(i + vec3(1,1,0)), u.x), u.y);
    float b = mix(mix(hash13(i + vec3(0,0,1)), hash13(i + vec3(1,0,1)), u.x), mix(hash13(i + vec3(0,1,1)), hash13(i + vec3(1,1,1)), u.x), u.y);
    return mix(a, b, u.z);
}
float fbm3(vec3 p) {
    float v = 0.0, a = 0.5;
    for (int i = 0; i < 5; i++) { v += a * vnoise3(p); p = p * 2.02 + 11.0; a *= 0.5; }
    return v;
}
"""

# 1. Nebula, at half resolution (it is soft anyway).
NEBULA = """
#version 330
uniform vec2 u_logical;
uniform vec2 u_pan;
uniform float u_time;
uniform vec3 u_c1, u_c2, u_c3;   // the sector's three nebula colours
in vec2 uv;
out vec4 color;
""" + NOISE + """
void main() {
    vec2 p = vec2(uv.x, 1.0 - uv.y) * u_logical + u_pan;
    vec2 q = p * 0.0021;
    vec2 w = vec2(fbm(q + vec2(1.7, 9.2) + u_time * 0.006), fbm(q + vec2(8.3, 2.8) - u_time * 0.005));
    float n = fbm(q + 1.9 * w);
    float m = fbm(q * 1.7 + 3.1 * w + 4.0);
    vec3 col = mix(u_c1, u_c2, smoothstep(0.25, 0.75, w.x));
    col = mix(col, u_c3, smoothstep(0.45, 0.85, w.y) * 0.8);
    float density = smoothstep(0.38, 0.95, n) * 1.15 + pow(1.0 - abs(2.0 * m - 1.0), 8.0) * 0.35 * n;
    float dust = smoothstep(0.52, 0.78, fbm(q * 2.3 + 40.0));
    density *= 1.0 - 0.8 * dust;
    color = vec4(col * density * 0.55, 1.0);
}
"""

# 2. Sky + game layer + shockwaves, at full resolution, in HDR.
SCENE = """
#version 330
uniform sampler2D u_nebula;
uniform sampler2D u_game;
uniform vec2 u_logical;      // logical size of the game picture (arena + sides)
uniform vec2 u_game_size;
uniform vec4 u_arena;        // arena rect in logical pixels (x, y, w, h)
uniform vec2 u_pan;          // how far the ship has cruised (logical pixels)
uniform float u_scale;       // window pixels per logical pixel
uniform float u_time;
uniform float u_dim;         // 0..1: menus dim the sky
uniform vec4 u_waves[8];     // x, y, radius, strength
uniform vec4 u_planets[3];   // x, y, radius, kind
uniform float u_spin;
in vec2 uv;
out vec4 color;
""" + NOISE + """
vec4 cubic(float v) {
    vec4 n = vec4(1.0, 2.0, 3.0, 4.0) - v;
    vec4 s = n * n * n;
    float x = s.x, y = s.y - 4.0 * s.x, z = s.z - 4.0 * s.y + 6.0 * s.x;
    return vec4(x, y, z, 6.0 - x - y - z) * (1.0 / 6.0);
}
vec3 bicubic(sampler2D t, vec2 p) {          // p in texels, image top-down
    p -= 0.5;
    vec2 f = fract(p); p -= f;
    vec4 xc = cubic(f.x), yc = cubic(f.y);
    vec4 c = p.xxyy + vec2(-0.5, 1.5).xyxy;
    vec4 s = vec4(xc.xz + xc.yw, yc.xz + yc.yw);
    vec4 o = c + vec4(xc.yw, yc.yw) / s;
    o /= u_game_size.xxyy;
    vec3 s0 = texture(t, o.xz).rgb, s1 = texture(t, o.yz).rgb, s2 = texture(t, o.xw).rgb, s3 = texture(t, o.yw).rgb;
    float sx = s.x / (s.x + s.y), sy = s.z / (s.z + s.w);
    return mix(mix(s3, s2, sx), mix(s1, s0, sx), sy);
}
vec3 stars(vec2 p) {
    vec3 acc = vec3(0.0);
    for (int layer = 0; layer < 3; layer++) {
        float cell = layer == 0 ? 34.0 : (layer == 1 ? 58.0 : 96.0);
        float depth = layer == 0 ? 0.35 : (layer == 1 ? 0.6 : 1.0);
        vec2 q = (p + u_pan * depth) / cell;
        vec2 id = floor(q), f = fract(q);
        vec2 h = hash22(id + float(layer) * 31.0);
        float pick = hash12(id * 1.7 + float(layer) * 13.0);
        if (pick < (layer == 2 ? 0.55 : 0.75)) continue;
        vec2 d = (f - (0.15 + 0.7 * h)) * cell * u_scale;       // distance in window pixels
        float size = mix(0.55, 1.35, hash12(id + 7.0)) * (0.7 + 0.3 * depth) * max(1.0, u_scale * 0.6);
        float tw = 0.75 + 0.25 * sin(u_time * (1.5 + 3.0 * h.x) + h.y * 40.0);
        float b = exp(-dot(d, d) / (size * size)) * (0.35 + 1.6 * pow(pick, 6.0)) * tw;
        vec3 tint = mix(vec3(0.75, 0.85, 1.0), vec3(1.0, 0.85, 0.75), hash12(id + 3.0));
        acc += tint * b * (0.5 + 0.5 * depth);
        if (layer == 2 && pick > 0.985) {                          // a few bright ones get a cross flare
            float flare = exp(-abs(d.x) / (1.5 * u_scale)) * exp(-d.y * d.y / (90.0 * u_scale)) +
                          exp(-abs(d.y) / (1.5 * u_scale)) * exp(-d.x * d.x / (90.0 * u_scale));
            acc += tint * flare * 0.35 * tw;
        }
    }
    return acc;
}
vec3 planet(vec2 p, vec4 pl, inout float cover) {
    vec2 l = (p - pl.xy) / pl.z;
    float r2 = dot(l, l);
    float px = 1.5 / (pl.z * u_scale);                          // one window pixel, in planet radii
    vec3 L = normalize(vec3(-0.62, -0.48, 0.62));
    vec3 col = vec3(0.0);
    int kind = int(pl.w + 0.5);
    vec3 atmo = kind == 0 ? vec3(1.0, 0.55, 0.7) : (kind == 1 ? vec3(0.35, 0.85, 1.0) : vec3(1.0, 0.5, 0.55));
    float a_disc = 1.0 - smoothstep(1.0 - px, 1.0 + px, sqrt(r2));
    // rings (the giant): the far half is hidden by the planet, the near half crosses it
    float ring_front = 0.0; vec3 ring_col = vec3(0.0);
    if (kind == 0) {
        float ca = cos(-0.32), sa = sin(-0.32);
        vec2 rl = vec2(l.x * ca + l.y * sa, -l.x * sa + l.y * ca);
        float rr = length(vec2(rl.x, rl.y / 0.26));
        float band = smoothstep(1.32, 1.36, rr) * (1.0 - smoothstep(2.05, 2.1, rr));
        float stripes = 0.55 + 0.45 * sin(rr * 46.0) * sin(rr * 13.0 + 1.0);
        float shadow = (rl.y < 0.0) ? 1.0 : smoothstep(0.0, 0.25, abs(rl.x) - 1.0 + 0.25);
        ring_col = vec3(0.95, 0.8, 0.88) * stripes * band * 0.75 * (0.35 + 0.65 * shadow);
        ring_front = rl.y > 0.0 ? band * stripes * 0.85 : 0.0;
        col += ring_col * (1.0 - a_disc) * (rl.y > 0.0 ? 1.0 : 1.0);
    }
    if (r2 < 1.0 + 4.0 * px) {
        vec3 n = vec3(l, sqrt(max(0.0, 1.0 - r2)));
        float spin = u_spin * (kind == 0 ? 1.0 : 0.6);
        float c = cos(spin), s = sin(spin);
        vec3 tn = vec3(n.x * c - n.z * s, n.y, n.x * s + n.z * c);
        vec3 surf;
        if (kind == 0) {
            float t = fbm3(tn * 2.5);
            float b = sin(n.y * 9.0 + t * 2.2) * 0.35 + sin(n.y * 31.0 + t * 3.0) * 0.15 + 0.5;
            surf = mix(mix(vec3(0.3, 0.1, 0.2), vec3(0.75, 0.35, 0.35), b), vec3(0.98, 0.78, 0.55), smoothstep(0.6, 0.95, b));
        } else if (kind == 1) {
            float t = fbm3(tn * 3.2 + 5.0);
            surf = mix(vec3(0.03, 0.15, 0.35), vec3(0.15, 0.45, 0.7), smoothstep(0.35, 0.6, t));
            surf = mix(surf, vec3(0.9, 0.97, 1.0), smoothstep(0.62, 0.72, t) + smoothstep(0.82, 0.95, abs(n.y)));
        } else {
            float t = fbm3(tn * 4.0 + 9.0);
            surf = mix(vec3(0.2, 0.12, 0.16), vec3(0.62, 0.42, 0.4), t);
            surf *= 0.75 + 0.25 * smoothstep(0.45, 0.5, fbm3(tn * 9.0));
        }
        float diff = max(dot(n, L), 0.0);
        float lit = 0.035 + 0.965 * pow(diff, 0.85);
        vec3 h = normalize(L + vec3(0.0, 0.0, 1.0));
        float spec = kind == 1 ? pow(max(dot(n, h), 0.0), 40.0) * 0.5 : 0.0;
        float fres = pow(1.0 - n.z, 2.5) * (0.25 + 0.75 * diff);
        vec3 disc = surf * lit + atmo * fres * 0.9 + vec3(spec);
        col = mix(col, disc, a_disc);
    }
    float d = sqrt(r2);
    float halo_side = clamp(dot(normalize(l + 1e-5), -L.xy) * 0.5 + 0.5, 0.0, 1.0);
    col += atmo * exp(-max(d - 1.0, 0.0) * 18.0) * (1.0 - a_disc) * (0.2 + 0.6 * halo_side) * step(1.0, d);
    col = mix(col, ring_col, ring_front * a_disc);
    cover = max(cover, max(a_disc, ring_front));
    return col;
}
void main() {
    vec2 p = vec2(uv.x, 1.0 - uv.y) * u_logical;               // logical pixels, y down
    vec2 off = vec2(0.0);
    float edge = 0.0;
    for (int i = 0; i < 8; i++) {                               // shockwaves bend the picture
        vec4 w = u_waves[i];
        if (w.w <= 0.0) continue;
        vec2 d = p - w.xy;
        float dist = length(d) + 1e-4;
        float k = (dist - w.z) / 26.0;
        float ring = exp(-k * k);
        off += d / dist * ring * w.w * 16.0;
        edge += ring * w.w;
    }
    vec2 q = p - off;
    vec3 sky = texture(u_nebula, vec2(q.x / u_logical.x, 1.0 - q.y / u_logical.y)).rgb;
    sky += stars(q);
    float cover = 0.0;
    vec3 planets = vec3(0.0);
    for (int i = 0; i < 3; i++) {
        float c = 0.0;
        vec3 pc = planet(q, u_planets[i], c);
        planets = mix(planets + pc * (1.0 - c), pc, c);
        cover = max(cover, c);
    }
    sky = sky * (1.0 - cover) + planets;
    vec2 inside = step(u_arena.xy, q) * step(q, u_arena.xy + u_arena.zw);
    sky *= mix(0.55, 1.0, inside.x * inside.y);                 // the sides stay quieter
    sky *= 1.0 - u_dim * 0.8;
    vec3 game = bicubic(u_game, q / u_logical * u_game_size);
    game = max(game, vec3(0.0));
    float peak = max(game.r, max(game.g, game.b));
    game *= 1.0 + 1.3 * pow(peak, 4.0);                         // neon cores go past white: HDR
    vec3 col = sky + game + vec3(0.25, 0.35, 0.6) * edge * 0.15;
    color = vec4(col, 1.0);
}
"""

# 3. Bloom: soft-knee threshold + 13-tap downsample (Karis average on the first level),
#    then a 9-tap tent upsample added back level by level.
DOWN = """
#version 330
uniform sampler2D u_src;
uniform vec2 u_texel;
uniform int u_first;
uniform float u_threshold;
in vec2 uv;
out vec4 color;
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 prefilter(vec3 c) {
    float br = max(c.r, max(c.g, c.b));
    float knee = u_threshold * 0.5;
    float soft = clamp(br - u_threshold + knee, 0.0, 2.0 * knee);
    soft = soft * soft / (4.0 * knee + 1e-4);
    return c * max(soft, br - u_threshold) / max(br, 1e-4);
}
void main() {
    vec2 t = u_texel;
    vec3 a = texture(u_src, uv + t * vec2(-2, 2)).rgb, b = texture(u_src, uv + t * vec2(0, 2)).rgb, c = texture(u_src, uv + t * vec2(2, 2)).rgb;
    vec3 d = texture(u_src, uv + t * vec2(-2, 0)).rgb, e = texture(u_src, uv).rgb, f = texture(u_src, uv + t * vec2(2, 0)).rgb;
    vec3 g = texture(u_src, uv + t * vec2(-2, -2)).rgb, h = texture(u_src, uv + t * vec2(0, -2)).rgb, i = texture(u_src, uv + t * vec2(2, -2)).rgb;
    vec3 j = texture(u_src, uv + t * vec2(-1, 1)).rgb, k = texture(u_src, uv + t * vec2(1, 1)).rgb;
    vec3 l = texture(u_src, uv + t * vec2(-1, -1)).rgb, m = texture(u_src, uv + t * vec2(1, -1)).rgb;
    vec3 res;
    if (u_first == 1) {
        vec3 g0 = (a + b + d + e) * 0.25, g1 = (b + c + e + f) * 0.25, g2 = (d + e + g + h) * 0.25, g3 = (e + f + h + i) * 0.25, g4 = (j + k + l + m) * 0.25;
        float w0 = 1.0 / (1.0 + luma(g0)), w1 = 1.0 / (1.0 + luma(g1)), w2 = 1.0 / (1.0 + luma(g2)), w3 = 1.0 / (1.0 + luma(g3)), w4 = 1.0 / (1.0 + luma(g4));
        res = (g0 * w0 * 0.125 + g1 * w1 * 0.125 + g2 * w2 * 0.125 + g3 * w3 * 0.125 + g4 * w4 * 0.5) /
              (w0 * 0.125 + w1 * 0.125 + w2 * 0.125 + w3 * 0.125 + w4 * 0.5);
        res = prefilter(res);
    } else {
        res = e * 0.125 + (a + c + g + i) * 0.03125 + (b + d + f + h) * 0.0625 + (j + k + l + m) * 0.125;
    }
    color = vec4(res, 1.0);
}
"""

UP = """
#version 330
uniform sampler2D u_src;
uniform vec2 u_texel;
uniform float u_radius;
in vec2 uv;
out vec4 color;
void main() {
    vec2 t = u_texel * u_radius;
    vec3 s = texture(u_src, uv).rgb * 4.0;
    s += (texture(u_src, uv + vec2(-t.x, 0)).rgb + texture(u_src, uv + vec2(t.x, 0)).rgb +
          texture(u_src, uv + vec2(0, -t.y)).rgb + texture(u_src, uv + vec2(0, t.y)).rgb) * 2.0;
    s += texture(u_src, uv + vec2(-t.x, -t.y)).rgb + texture(u_src, uv + vec2(t.x, -t.y)).rgb +
         texture(u_src, uv + vec2(-t.x, t.y)).rgb + texture(u_src, uv + vec2(t.x, t.y)).rgb;
    color = vec4(s / 16.0, 1.0);
}
"""

# 4. Final: bloom + streaks, colour fringing, tone mapping, vignette, grain.
FINAL = """
#version 330
uniform sampler2D u_scene;
uniform sampler2D u_bloom;
uniform sampler2D u_streak;
uniform float u_time;
uniform float u_ca;
uniform float u_bloom_strength;
uniform vec2 u_res;
in vec2 uv;
out vec4 color;
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
void main() {
    vec2 dir = uv - 0.5;
    float r2 = dot(dir, dir);
    vec2 ca = dir * u_ca * (0.4 + 2.0 * r2);
    vec3 scene = vec3(texture(u_scene, uv + ca).r, texture(u_scene, uv).g, texture(u_scene, uv - ca).b);
    vec3 bloom = texture(u_bloom, uv).rgb;
    vec3 streak = vec3(0.0);
    float wsum = 0.0;
    for (int k = -10; k <= 10; k++) {                          // anamorphic lens streak
        float w = exp(-abs(float(k)) * 0.28);
        streak += texture(u_streak, uv + vec2(float(k) * 0.016, 0.0)).rgb * w;
        wsum += w;
    }
    streak = streak / wsum * vec3(0.45, 0.65, 1.0);
    vec3 hdr = scene + bloom * u_bloom_strength + streak * 0.55;
    float L = dot(hdr, vec3(0.2126, 0.7152, 0.0722));
    float Lw = 5.0;
    float Ld = L * (1.0 + L / (Lw * Lw)) / (1.0 + L);          // tone map the light, keep the hue
    vec3 col = hdr * (Ld / max(L, 1e-4));
    col = mix(col, vec3(Ld), clamp((Ld - 0.85) * 1.5, 0.0, 0.6));   // hottest cores whiten
    col *= mix(1.0, 0.72, smoothstep(0.12, 0.62, r2 * 1.6));         // vignette
    float grain = hash12(uv * u_res + fract(u_time * 7.13) * 400.0) - 0.5;
    col += grain * 0.022 + (hash12(uv * u_res * 1.37) - 0.5) / 255.0;
    color = vec4(clamp(col, 0.0, 1.0), 1.0);
}
"""


def viewport(window, logical):
    """The letterboxed rectangle (x, y, w, h, scale) the logical picture fills in the window.
    x, y are measured from the window's top-left corner."""
    ww, wh = window
    lw, lh = logical
    scale = min(ww / lw, wh / lh)
    w, h = round(lw * scale), round(lh * scale)
    return (ww - w) // 2, (wh - h) // 2, w, h, scale


def window_to_logical(pos, window, logical):
    x, y, _, _, scale = viewport(window, logical)
    return ((pos[0] - x) / scale, (pos[1] - y) / scale)


class Planets:
    """Where the three planets are: they cruise past slowly at their own depths (the far
    ones slower), wrapping around a wide loop so a new one drifts in now and then."""

    # (start x, y, radius, kind 0 giant / 1 ice / 2 moon, depth)
    BODIES = [(1150, 560, 92, 0, 0.55), (260, 300, 64, 1, 0.75), (1500, 140, 24, 2, 0.4)]
    LOOP = 2600.0

    def positions(self, pan, focus_offset):
        out = []
        for x, y, r, kind, depth in self.BODIES:
            px = (x - pan[0] * depth - focus_offset[0] * 0.03 * depth) % self.LOOP - 400
            py = y - pan[1] * depth * 0.25 - focus_offset[1] * 0.03 * depth
            out.append((px, py, r, kind))
        return out


class Renderer:
    """Owns the GL context and every GPU resource; rebuilt when the window changes."""

    def __init__(self, logical, arena, window, game_size=None):
        import moderngl
        self.mgl = moderngl
        self.ctx = moderngl.create_context(require=330)
        self.output = self.ctx.screen      # where the final picture goes (the window)
        self.logical = logical
        self.arena = arena
        self.nebula_colours = sectors.SECTORS[0].nebula   # the app sets the current sector's
        self.planets = Planets()
        self.waves = []            # [x, y, age, life, strength, max radius]
        quad = self.ctx.buffer(struct.pack("6f", -1, -1, 3, -1, -1, 3))

        def program(fragment):
            prog = self.ctx.program(vertex_shader=VERTEX, fragment_shader=fragment)
            return prog, self.ctx.vertex_array(prog, [(quad, "2f", "in_pos")])

        self.nebula_prog, self.nebula_vao = program(NEBULA)
        self.scene_prog, self.scene_vao = program(SCENE)
        self.down_prog, self.down_vao = program(DOWN)
        self.up_prog, self.up_vao = program(UP)
        self.final_prog, self.final_vao = program(FINAL)
        self.game_size = tuple(game_size or logical)      # the game picture's real pixels
        self.game_tex = self.ctx.texture(self.game_size, 4)
        self.game_tex.swizzle = "BGRA"
        self.game_tex.filter = (moderngl.LINEAR, moderngl.LINEAR)
        self.game_tex.repeat_x = self.game_tex.repeat_y = False
        self.window = None
        self.resize(window)

    def _target(self, size):
        tex = self.ctx.texture(size, 4, dtype="f2")
        tex.filter = (self.mgl.LINEAR, self.mgl.LINEAR)
        tex.repeat_x = tex.repeat_y = False
        return tex, self.ctx.framebuffer(color_attachments=[tex])

    def resize(self, window):
        if window == self.window:
            return
        self.window = window
        x, y, w, h, self.scale = viewport(window, self.logical)
        self.view = (x, window[1] - y - h, w, h)                # GL counts y from the bottom
        self.size = (max(1, w), max(1, h))
        self.nebula_tex, self.nebula_fbo = self._target((max(1, w // 2), max(1, h // 2)))
        self.scene_tex, self.scene_fbo = self._target(self.size)
        self.mips = []
        mw, mh = self.size
        for _ in range(BLOOM_LEVELS):
            mw, mh = max(1, mw // 2), max(1, mh // 2)
            self.mips.append(self._target((mw, mh)))

    def kick(self, pos, strength):
        """A shockwave from a game moment (pos in arena pixels)."""
        if strength <= 0:
            return
        ax, ay = self.arena[0], self.arena[1]
        self.waves.append([pos[0] + ax, pos[1] + ay, 0.0, 0.55 + 0.25 * strength, min(1.0, strength), 0.0])
        self.waves = self.waves[-8:]

    def update(self, dt):
        for w in self.waves:
            w[2] += dt
        self.waves = [w for w in self.waves if w[2] < w[3]]

    def render(self, surface, t, pan, focus_offset, dim=0.0, flash=0.0):
        ctx = self.ctx
        if surface.get_pitch() == surface.get_width() * 4:
            self.game_tex.write(surface.get_buffer())
        else:                                                  # unusual pitch: slower but safe
            import pygame
            self.game_tex.write(pygame.image.tobytes(surface, "BGRA"))
        lw, lh = self.logical

        self.nebula_fbo.use()
        self.nebula_prog["u_logical"].value = self.logical
        self.nebula_prog["u_pan"].value = pan
        self.nebula_prog["u_time"].value = t
        for name, colour in zip(("u_c1", "u_c2", "u_c3"), self.nebula_colours):
            self.nebula_prog[name].value = tuple(colour)
        self.nebula_vao.render()

        self.scene_fbo.use()
        sp = self.scene_prog
        self.nebula_tex.use(0)
        self.game_tex.use(1)
        sp["u_nebula"].value, sp["u_game"].value = 0, 1
        sp["u_logical"].value = (float(lw), float(lh))
        sp["u_game_size"].value = (float(self.game_size[0]), float(self.game_size[1]))
        sp["u_arena"].value = self.arena
        sp["u_pan"].value = pan
        sp["u_scale"].value = self.scale
        sp["u_time"].value = t
        sp["u_dim"].value = dim
        sp["u_spin"].value = t * 0.02
        waves = []
        for x, y, age, life, strength, _ in self.waves:
            k = age / life
            waves += [x, y, 40 + 900 * age, strength * (1 - k) ** 2]
        waves += [0.0] * (4 * MAX_WAVES - len(waves))
        sp["u_waves"].write(struct.pack(f"{4 * MAX_WAVES}f", *waves))
        planets = []
        for px, py, r, kind in self.planets.positions(pan, focus_offset):
            planets += [px, py, r, kind]
        sp["u_planets"].write(struct.pack("12f", *planets))
        self.scene_vao.render()

        # bloom down the chain...
        src = self.scene_tex
        for i, (tex, fbo) in enumerate(self.mips):
            fbo.use()
            src.use(0)
            self.down_prog["u_src"].value = 0
            self.down_prog["u_texel"].value = (1 / src.width, 1 / src.height)
            self.down_prog["u_first"].value = 1 if i == 0 else 0
            self.down_prog["u_threshold"].value = 0.85
            self.down_vao.render()
            src = tex
        # ...and back up, each level added onto the bigger one
        ctx.enable(self.mgl.BLEND)
        ctx.blend_func = self.mgl.ONE, self.mgl.ONE
        for i in range(len(self.mips) - 1, 0, -1):
            tex, _ = self.mips[i]
            _, fbo = self.mips[i - 1]
            fbo.use()
            tex.use(0)
            self.up_prog["u_src"].value = 0
            self.up_prog["u_texel"].value = (1 / tex.width, 1 / tex.height)
            self.up_prog["u_radius"].value = 1.0
            self.up_vao.render()
        ctx.disable(self.mgl.BLEND)

        self.output.use()
        ctx.viewport = (0, 0) + tuple(self.window)
        ctx.clear(0.0, 0.0, 0.0)
        ctx.viewport = self.view
        self.scene_tex.use(0)
        self.mips[0][0].use(1)
        self.mips[2][0].use(2)
        fp = self.final_prog
        fp["u_scene"].value, fp["u_bloom"].value, fp["u_streak"].value = 0, 1, 2
        fp["u_time"].value = t
        fp["u_ca"].value = 0.0018 + 0.02 * min(1.0, flash)      # fringing: faint, strong on a hit
        fp["u_bloom_strength"].value = 0.6
        fp["u_res"].value = (float(self.size[0]), float(self.size[1]))
        self.final_vao.render()

    def release(self):
        try:
            self.ctx.release()
        except Exception:                 # noqa: BLE001 - shutting down anyway
            pass


def available():
    """True if this PC can run ULTRA: Windows, moderngl installed."""
    import sys
    if sys.platform != "win32":
        return False
    try:
        import moderngl  # noqa: F401
        return True
    except ImportError:
        return False
