"""BENCHMARK (menu): a scripted 10-second fight drawn exactly like a real run, with its
frame times measured, and a plain verdict on the graphics settings.

Only the work of a frame counts (update + draw + the graphics card finishing the picture),
not the wait for the monitor, so the numbers say how fast this PC could go.

The same measure runs quietly on the very first launch (`FirstLaunchCheck`): if ULTRA is
too heavy for the PC, the game drops to STANDARD by itself.

Copyright (c) 2026 Massinissa K. All rights reserved.
"""

import random

from prism_dash import entities
from prism_dash import settings as S

DURATION = 10.0
WARMUP = 1.0                 # the first second (shaders, caches) doesn't count
CROWD = 28                   # enemies kept on screen: busier than most real waves
WAVES = (entities.Drifter, entities.Dart, entities.Splitter, entities.Spinner, entities.Weaver, entities.Mine)


SMOOTH_CAP = 120            # past this, more frames aren't something anyone feels in this game
PLAYABLE = 57               # ~60 fps (a little slack for timing noise)


def summary(samples_ms, refresh):
    """Average and slow-frame numbers, plus a verdict: smooth when even the slowest frames
    keep up with the monitor (up to 120 Hz), playable at 60 fps or more, else slow."""
    if not samples_ms:
        return None
    ordered = sorted(samples_ms)
    avg = sum(ordered) / len(ordered)
    p99 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.99))]
    fps, low = 1000 / max(avg, 0.01), 1000 / max(p99, 0.01)
    target = min(refresh, SMOOTH_CAP)
    if low >= target * 0.95:
        verdict = "smooth"
    elif low >= PLAYABLE:
        verdict = "ok"
    else:
        verdict = "slow"
    return {"frames": len(ordered), "avg_ms": avg, "p99_ms": p99, "fps": fps, "low_fps": low,
            "target": target, "verdict": verdict}


def advice(result, ultra_on, ultra_possible, effects_full):
    """One line on what to change (or that nothing needs changing)."""
    if result is None:
        return ""
    if result["verdict"] == "slow":
        if ultra_on:
            return "Try GRAPHICS: STANDARD (lighter on the graphics card)."
        if effects_full:
            return "Try EFFECTS: LIGHT (skips the glow and the busy background)."
        return "This is the lightest setting: a smaller window helps a little."
    if result["verdict"] == "ok" and ultra_on:
        return "Playable. For more frames: GRAPHICS: STANDARD or EFFECTS: LIGHT."
    if not ultra_on and ultra_possible and result["verdict"] == "smooth":
        return "Plenty of room: GRAPHICS: ULTRA should run well here."
    return "Your settings fit this PC: nothing to change."


class Benchmark:
    """The scripted fight. The app builds the world (it owns fonts, audio, backgrounds);
    this keeps it busy and collects the frame times."""

    def __init__(self, world, pilot, target_fps):
        self.world, self.pilot = world, pilot
        self.target = target_fps
        self.time = 0.0
        self.samples = []
        self.spawn_timer = 0.0
        self.burst_timer = 1.5
        self.rng = random.Random(2026)
        world.player.lives = 999

    @property
    def done(self):
        return self.time >= DURATION

    @property
    def progress(self):
        return min(1.0, self.time / DURATION)

    def update(self, dt):
        self.time += dt
        w = self.world
        w.player.lives = max(w.player.lives, 999)
        self.spawn_timer -= dt
        if self.spawn_timer <= 0 and len(w.enemies) < CROWD:
            self.spawn_timer = 0.15
            cls = WAVES[self.rng.randrange(len(WAVES))]
            pos = (self.rng.uniform(80, S.WIDTH - 80), self.rng.uniform(80, S.HEIGHT - 80))
            try:
                w.add_enemy(cls(pos, w))
            except TypeError:            # an enemy type with a different constructor: skip it
                pass
        self.burst_timer -= dt
        if self.burst_timer <= 0 and w.enemies:
            self.burst_timer = 0.7       # a dash kill: shockwave, particles, chain pops
            w.kill(w.enemies[0], by_dash=True)
        w.update(dt, self.pilot.controls(w))
        w.particles.update(dt)
        w.bg.update(dt)

    def record(self, work_ms):
        if self.time > WARMUP:
            self.samples.append(work_ms)

    def result(self):
        return summary(self.samples, self.target)


class FirstLaunchCheck:
    """First launch with ULTRA: watch a few seconds of the menu; too heavy -> STANDARD.

    It times only the graphics card's share of each frame (ULTRA's own cost): the rest is
    the same with both renderers, and STANDARD is heavier on the processor."""

    START, END = 1.5, 5.0        # seconds of menu measured (after the first frames settle)

    def __init__(self, target_fps):
        self.target = target_fps
        self.time = 0.0
        self.samples = []

    GPU_BUDGET_MS = 9.0          # ULTRA's share: room left for a busy fight at 60 fps

    def record(self, dt, gpu_ms):
        """Returns None while measuring, then True (keep ULTRA) or False (too slow)."""
        self.time += dt
        if self.START < self.time <= self.END:
            self.samples.append(gpu_ms)
        if self.time <= self.END:
            return None
        ordered = sorted(self.samples) or [0.0]
        p95 = ordered[int(len(ordered) * 0.95) if len(ordered) > 1 else 0]
        return p95 <= self.GPU_BUDGET_MS
