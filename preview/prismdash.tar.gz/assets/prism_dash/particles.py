"""Sparks, shockwave rings and floating score numbers."""

import math
import random

import pygame

from prism_dash import render


class Spark:
    __slots__ = ("x", "y", "vx", "vy", "life", "max_life", "color", "size", "drag")

    def __init__(self, x, y, vx, vy, life, color, size, drag):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.life = self.max_life = life
        self.color, self.size, self.drag = color, size, drag


class Ring:
    __slots__ = ("x", "y", "radius", "speed", "life", "max_life", "color", "width")

    def __init__(self, x, y, speed, life, color, width):
        self.x, self.y, self.radius, self.speed = x, y, 4.0, speed
        self.life = self.max_life = life
        self.color, self.width = color, width


class FloatText:
    __slots__ = ("x", "y", "text", "color", "life", "max_life", "size")

    def __init__(self, x, y, text, color, size):
        self.x, self.y, self.text, self.color, self.size = x, y, text, color, size
        self.life = self.max_life = 0.9


class Particles:
    MAX_SPARKS = 1400

    def __init__(self, fonts):
        self.sparks = []
        self.rings = []
        self.texts = []
        self.fonts = fonts
        self.rng = random.Random()

    def burst(self, pos, color, count=18, speed=320, life=0.55, size=3, drag=3.5):
        rng = self.rng
        for _ in range(count):
            if len(self.sparks) >= self.MAX_SPARKS:
                break
            a = rng.uniform(0, math.tau)
            v = rng.uniform(0.25, 1.0) * speed
            self.sparks.append(Spark(pos[0], pos[1], math.cos(a) * v, math.sin(a) * v,
                                     rng.uniform(0.5, 1.0) * life, color, size, drag))

    def trail(self, pos, color, direction, spread=0.5, speed=120, count=2, life=0.3):
        rng = self.rng
        for _ in range(count):
            a = direction + math.pi + rng.uniform(-spread, spread)
            v = rng.uniform(0.3, 1.0) * speed
            self.sparks.append(Spark(pos[0], pos[1], math.cos(a) * v, math.sin(a) * v,
                                     rng.uniform(0.5, 1.0) * life, color, 2, 4.0))

    def ring(self, pos, color, speed=520, life=0.45, width=4):
        self.rings.append(Ring(pos[0], pos[1], speed, life, color, width))

    def popup(self, pos, message, color, size="small"):
        self.texts.append(FloatText(pos[0], pos[1], message, color, size))

    def clear(self):
        self.sparks.clear()
        self.rings.clear()
        self.texts.clear()

    def update(self, dt):
        alive = []
        for p in self.sparks:
            p.life -= dt
            if p.life > 0:
                k = math.exp(-p.drag * dt)
                p.vx *= k
                p.vy *= k
                p.x += p.vx * dt
                p.y += p.vy * dt
                alive.append(p)
        self.sparks = alive
        for r in self.rings:
            r.life -= dt
            r.radius += r.speed * dt * (r.life / r.max_life + 0.2)
        self.rings = [r for r in self.rings if r.life > 0]
        for t in self.texts:
            t.life -= dt
            t.y -= 45 * dt
        self.texts = [t for t in self.texts if t.life > 0]

    def draw(self, surface):
        for p in self.sparks:
            k = p.life / p.max_life
            color = tuple(int(c * k) for c in p.color)
            size = max(1, int(p.size * (0.5 + k)))
            surface.fill(color, (p.x - size / 2, p.y - size / 2, size, size),
                         special_flags=pygame.BLEND_RGB_ADD)
        for r in self.rings:
            k = r.life / r.max_life
            color = tuple(int(c * k) for c in r.color)
            width = max(1, int(r.width * k + 1))
            pygame.draw.aacircle(surface, color, (r.x, r.y), r.radius, width)
        for t in self.texts:
            k = min(1.0, t.life / t.max_life * 2)
            color = tuple(int(c * k) for c in t.color)
            render.text(surface, self.fonts[t.size], t.text, (t.x, t.y), color, anchor="center")
