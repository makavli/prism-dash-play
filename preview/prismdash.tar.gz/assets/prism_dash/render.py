"""Neon drawing helpers. Glow is faked with pre-rendered radial gradients
blitted using additive blending, which looks great on a dark background."""

import math
import random

import pygame

from prism_dash import settings as S

_glow_cache = {}


def _scaled(color, k):
    return tuple(min(255, int(c * k)) for c in color)


def glow_sprite(radius, color, strength=1.0):
    """A soft radial gradient, cached by (radius, color, strength)."""
    radius = max(2, int(radius))
    key = (radius, color, round(strength, 2))
    sprite = _glow_cache.get(key)
    if sprite is None:
        size = radius * 2
        sprite = pygame.Surface((size, size))
        sprite.fill((0, 0, 0))
        steps = min(radius, 28)
        for i in range(steps, 0, -1):
            r = radius * i / steps
            k = strength * (1 - i / steps) ** 1.4 * 1.15
            pygame.draw.circle(sprite, _scaled(color, k), (radius, radius), r)
        _glow_cache[key] = sprite
    return sprite


def glow(surface, pos, radius, color, strength=1.0):
    sprite = glow_sprite(radius, color, strength)
    r = sprite.get_width() // 2
    surface.blit(sprite, (pos[0] - r, pos[1] - r), special_flags=pygame.BLEND_RGB_ADD)


def neon_circle(surface, pos, radius, color, width=3, glow_scale=2.6, strength=0.9):
    glow(surface, pos, radius * glow_scale, color, strength)
    pygame.draw.circle(surface, color, pos, radius, width)
    if width:
        pygame.draw.circle(surface, _scaled(color, 0.35), pos, max(1, radius - width))


def neon_polygon(surface, points, color, width=3, glow_radius=None, strength=1.0):
    if glow_radius:
        cx = sum(p[0] for p in points) / len(points)
        cy = sum(p[1] for p in points) / len(points)
        glow(surface, (cx, cy), glow_radius, color, strength)
    pygame.draw.polygon(surface, _scaled(color, 0.25), points)
    pygame.draw.polygon(surface, color, points, width)
    if width >= 3:          # a white-hot line down the middle: it reads as a glowing tube
        pygame.draw.polygon(surface, hot(color), points, 1)


def hot(color, k=0.6):
    """The colour pushed towards white: the bright core of a neon tube."""
    return tuple(int(c + (255 - c) * k) for c in color)


def scaled_points(points, center, k):
    cx, cy = center
    return [(cx + (x - cx) * k, cy + (y - cy) * k) for x, y in points]


def eye(surface, pos, color, toward, radius=5, t=0.0):
    """A glowing eye whose pupil looks along `toward` (a unit vector)."""
    glow(surface, pos, radius * 3, color, 0.7)
    pygame.draw.circle(surface, (8, 8, 16), pos, radius + 1)
    pygame.draw.circle(surface, color, pos, radius + 1, 1)
    pupil = (pos[0] + toward[0] * radius * 0.45, pos[1] + toward[1] * radius * 0.45)
    pygame.draw.circle(surface, hot(color, 0.8), pupil, max(1, radius * 0.5 + math.sin(t * 7) * 0.5))


def regular_polygon(center, radius, sides, angle):
    return [(center[0] + math.cos(angle + i * 2 * math.pi / sides) * radius,
             center[1] + math.sin(angle + i * 2 * math.pi / sides) * radius)
            for i in range(sides)]


def ship_points(center, radius, angle):
    """An arrowhead pointing along angle."""
    cx, cy = center
    pts = [(1.45, 0), (-0.95, 0.85), (-0.45, 0), (-0.95, -0.85)]
    ca, sa = math.cos(angle), math.sin(angle)
    return [(cx + (x * ca - y * sa) * radius, cy + (x * sa + y * ca) * radius) for x, y in pts]


class Wireframes:
    """Big 3D wireframe solids drifting far behind the arena (a prism, an icosahedron, an
    octahedron), slowly turning, with parallax: they shift a little against the player's
    movement, so the arena feels like it floats in deep space."""

    PHI = (1 + 5 ** 0.5) / 2

    def __init__(self):
        phi = self.PHI
        ico = [(-1, phi, 0), (1, phi, 0), (-1, -phi, 0), (1, -phi, 0), (0, -1, phi), (0, 1, phi),
               (0, -1, -phi), (0, 1, -phi), (phi, 0, -1), (phi, 0, 1), (-phi, 0, -1), (-phi, 0, 1)]
        ico_edges = [(i, j) for i in range(12) for j in range(i + 1, 12)
                     if abs(sum((a - b) ** 2 for a, b in zip(ico[i], ico[j])) - 4) < 0.01]
        octa = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
        octa_edges = [(i, j) for i in range(6) for j in range(i + 1, 6) if i // 2 != j // 2]
        tri = [(math.cos(a), math.sin(a)) for a in (0, math.tau / 3, 2 * math.tau / 3)]
        prism = [(x, y, -1.3) for x, y in tri] + [(x, y, 1.3) for x, y in tri]
        prism_edges = [(0, 1), (1, 2), (2, 0), (3, 4), (4, 5), (5, 3), (0, 3), (1, 4), (2, 5)]
        # (vertices, edges, centre x, centre y, depth, size, spin x, spin y, colour)
        self.solids = [
            (ico, ico_edges, 1040, 210, 3.0, 95, 0.11, 0.07, (34, 22, 66)),
            (prism, prism_edges, 230, 540, 2.4, 85, 0.09, -0.13, (16, 44, 62)),
            (octa, octa_edges, 660, 120, 4.0, 60, -0.06, 0.1, (44, 20, 50)),
        ]

    def draw(self, surface, t, focus, pulse, pulse_color):
        fx, fy = focus[0] - S.WIDTH / 2, focus[1] - S.HEIGHT / 2
        for verts, edges, cx, cy, depth, size, sx, sy, colour in self.solids:
            ax, ay = t * sx, t * sy
            cax, sax, cay, say = math.cos(ax), math.sin(ax), math.cos(ay), math.sin(ay)
            px, py = cx - fx * 0.05 / depth, cy - fy * 0.05 / depth     # parallax: far moves less
            pts = []
            for x, y, z in verts:
                y, z = y * cax - z * sax, y * sax + z * cax           # turn around X
                x, z = x * cay + z * say, -x * say + z * cay          # turn around Y
                k = 4.0 / (4.0 + z)                                   # perspective
                pts.append((px + x * size * k, py + y * size * k))
            c = tuple(min(255, int(a * (1 + pulse * 0.6) + b * pulse * 0.12)) for a, b in zip(colour, pulse_color))
            for i, j in edges:
                pygame.draw.line(surface, c, pts[i], pts[j])


class Background:
    """The arena floor: a neon grid that *bends* - every kill, dash, nova and boss sends a
    ripple through it and it springs back - and the player's ship weighs it down a little,
    like a mass on a sheet. Behind it: drifting stars in three depths and big 3D wireframe
    solids (Wireframes), all with parallax. effects="low" keeps the classic flat grid."""

    STEP = 40                     # grid cell, in arena pixels
    STIFFNESS = 70.0              # pull of each grid point back home
    DAMPING = 6.5
    PHYSICS_HZ = 60               # the grid simulates at a fixed rate, whatever the frame rate

    def __init__(self, effects="high"):
        rng = random.Random(42)
        self.stars = [(rng.uniform(0, S.WIDTH), rng.uniform(0, S.HEIGHT),
                       rng.uniform(4, 22), rng.randint(40, 120)) for _ in range(120)]
        self.pulse = 0.0
        self.pulse_color = S.PURPLE
        self.effects = effects
        self.focus = (S.WIDTH / 2, S.HEIGHT / 2)    # the player: parallax and the grid's dip
        self.cols = S.WIDTH // self.STEP + 1
        self.rows = S.HEIGHT // self.STEP + 1
        n = self.cols * self.rows
        self.dx, self.dy, self.vx, self.vy = [0.0] * n, [0.0] * n, [0.0] * n, [0.0] * n
        self.ripples = []         # [x, y, radius, speed, strength, life]
        self.awake = 0.0          # seconds of motion left; the grid sleeps when still
        self._acc = 0.0
        self.wireframes = Wireframes()

    @property
    def fancy(self):
        return self.effects != "low"

    def kick(self, amount=1.0, color=S.PURPLE, pos=None):
        self.pulse = min(1.2, self.pulse + amount * 0.6)
        self.pulse_color = color
        if pos is not None:
            self.ripple(pos, amount)

    def ripple(self, pos, strength=1.0):
        """A ring that runs out from pos and shoves the grid as it passes."""
        if not self.fancy:
            return
        if len(self.ripples) >= 12:
            self.ripples.pop(0)
        self.ripples.append([pos[0], pos[1], 0.0, 620.0 + 260.0 * min(strength, 1.5),
                             min(strength, 2.0) * 900.0, 0.55 + 0.2 * min(strength, 1.5)])
        self.awake = 2.5

    def update(self, dt):
        self.pulse = max(0.0, self.pulse - dt * 2.2)
        if not self.fancy or self.awake <= 0:
            return
        self.awake -= dt
        self._acc = min(self._acc + dt, 0.1)
        step = 1.0 / self.PHYSICS_HZ
        while self._acc >= step:
            self._acc -= step
            self._step(step)

    def _step(self, dt):
        cols, rows, g = self.cols, self.rows, self.STEP
        dx, dy, vx, vy = self.dx, self.dy, self.vx, self.vy
        for r in self.ripples:                      # each ripple pushes the band it is crossing
            x0, y0, radius, _speed, strength, _life = r
            band = 46.0
            lo, hi = radius - band, radius + band
            c0, c1 = max(0, int((x0 - hi) // g)), min(cols - 1, int((x0 + hi) // g) + 1)
            r0, r1 = max(0, int((y0 - hi) // g)), min(rows - 1, int((y0 + hi) // g) + 1)
            for row in range(r0, r1 + 1):
                ry = row * g - y0
                base = row * cols
                for col in range(c0, c1 + 1):
                    rx = col * g - x0
                    d = math.hypot(rx, ry)
                    if lo < d < hi and d > 1:
                        k = strength * (1 - abs(d - radius) / band) * dt / d
                        i = base + col
                        vx[i] += rx * k
                        vy[i] += ry * k
        for r in self.ripples:
            r[2] += r[3] * dt
            r[4] *= 0.93
            r[5] -= dt
        self.ripples = [r for r in self.ripples if r[5] > 0]
        stiff, damp = self.STIFFNESS * dt, 1 - self.DAMPING * dt
        for i in range(cols * rows):
            vx[i] = (vx[i] - dx[i] * stiff) * damp
            vy[i] = (vy[i] - dy[i] * stiff) * damp
            dx[i] += vx[i] * dt
            dy[i] += vy[i] * dt

    def _grid_colour(self):
        pulse = min(self.pulse, 1.0)
        return tuple(min(255, int(g * (1 + pulse * 0.5) + p * pulse * 0.09))
                     for g, p in zip(S.GRID, self.pulse_color))

    def draw(self, surface, t, origin=(0, 0), arena=False):
        """Draw the background over the whole surface. `origin` is where the
        1280x720 arena's top-left sits on this surface: stars and grid lines are
        laid out relative to it, so the arena canvas and the wider screen around
        it (ultrawide sides, 16:10 / 4:3 bands) line up seamlessly. arena=True is the
        arena canvas itself: it gets the bending grid and the 3D solids."""
        w, h = surface.get_size()
        ox, oy = round(origin[0]), round(origin[1])     # screen shake gives fractional offsets
        surface.fill(S.BG)
        fx, fy = self.focus[0] - S.WIDTH / 2, self.focus[1] - S.HEIGHT / 2

        # stars tile every 1280x720 around the arena; nearer (faster) stars shift more
        tiles_x = range(-((ox + S.WIDTH - 1) // S.WIDTH), (w - ox) // S.WIDTH + 1)
        tiles_y = range(-((oy + S.HEIGHT - 1) // S.HEIGHT), (h - oy) // S.HEIGHT + 1)
        fancy = self.fancy
        for x, y, speed, b in self.stars:
            sy = (y + t * speed) % S.HEIGHT
            if fancy:
                x = (x - fx * speed * 0.004) % S.WIDTH
                sy = (sy - fy * speed * 0.004) % S.HEIGHT
            for tx in tiles_x:
                for ty in tiles_y:
                    surface.fill((b // 2, b // 2, b),
                                 (ox + x + tx * S.WIDTH, oy + sy + ty * S.HEIGHT, 2, 2))

        color = self._grid_colour()
        if arena and fancy:
            self.wireframes.draw(surface, t, self.focus, min(self.pulse, 1.0), self.pulse_color)
            self._draw_mesh(surface, color)
        else:
            step = self.STEP if fancy else 64
            drift = 0 if fancy else (t * 12) % step
            for x in range(int((ox - drift) % step) - step, w + step, step):
                pygame.draw.line(surface, color, (x, 0), (x, h))
            for y in range(int((oy - drift) % step) - step, h + step, step):
                pygame.draw.line(surface, color, (0, y), (w, y))

        arena_rect = pygame.Rect(ox, oy, S.WIDTH, S.HEIGHT)
        if (w, h) != (S.WIDTH, S.HEIGHT):
            # dim everything outside the arena so the eye stays on the action
            for rect in (pygame.Rect(0, 0, arena_rect.left, h), pygame.Rect(arena_rect.right, 0, w - arena_rect.right, h),
                         pygame.Rect(arena_rect.left, 0, S.WIDTH, arena_rect.top),
                         pygame.Rect(arena_rect.left, arena_rect.bottom, S.WIDTH, h - arena_rect.bottom)):
                if rect.width > 0 and rect.height > 0:
                    surface.fill((120, 120, 150), rect, special_flags=pygame.BLEND_RGB_MULT)

        m = S.ARENA_MARGIN
        edge = _scaled(S.PURPLE, 0.55 + self.pulse * 0.4)
        pygame.draw.rect(surface, edge, arena_rect.inflate(-2 * m, -2 * m), 2, border_radius=6)

    def point(self, col, row):
        """Where a grid point is drawn: home + spring displacement + the ship's dip."""
        g, i = self.STEP, row * self.cols + col
        x, y = col * g + self.dx[i], row * g + self.dy[i]
        ddx, ddy = self.focus[0] - x, self.focus[1] - y
        d2 = ddx * ddx + ddy * ddy
        if d2 < 32400:                              # within 180 px the ship pulls the grid in
            k = 0.16 * (1 - d2 / 32400)
            x, y = x + ddx * k, y + ddy * k
        return x, y

    def _draw_mesh(self, surface, color):
        cols, rows = self.cols, self.rows
        pts = [[self.point(c, r) for c in range(cols)] for r in range(rows)]
        for r in range(rows):
            pygame.draw.lines(surface, color, False, pts[r])
        for c in range(cols):
            pygame.draw.lines(surface, color, False, [pts[r][c] for r in range(rows)])


class Shake:
    def __init__(self):
        self.trauma = 0.0
        self.enabled = True

    def add(self, amount):
        self.trauma = min(1.0, self.trauma + amount)

    def update(self, dt):
        self.trauma = max(0.0, self.trauma - dt * 1.8)

    def offset(self, t):
        if not self.enabled or self.trauma <= 0:
            return 0, 0
        power = self.trauma ** 2 * 18
        return (math.sin(t * 73.1) * power, math.cos(t * 61.7) * power)


def text(surface, font, message, pos, color=S.WHITE, anchor="topleft", glow_color=None):
    img = font.render(message, True, color)
    rect = img.get_rect(**{anchor: pos})
    if glow_color:
        glow(surface, rect.center, max(rect.width, rect.height) * 0.75, glow_color, 0.35)
    surface.blit(img, rect)
    return rect


# ---------------------------------------------------------------- controller button icons
# Drawn in code (no image files): PlayStation face buttons are dark discs with the coloured
# cross / circle / square / triangle, Xbox ones carry coloured A / B / X / Y; shoulders,
# triggers, menu buttons, the d-pad and the stick have their own small shapes.

PS_FACE = {"a": ("cross", (124, 178, 232)), "b": ("circle", (255, 102, 102)),
           "x": ("square", (226, 140, 200)), "y": ("triangle", (64, 224, 176))}
XBOX_FACE = {"a": ("A", (96, 200, 80)), "b": ("B", (232, 72, 60)),
             "x": ("X", (64, 136, 232)), "y": ("Y", (240, 200, 48))}
SHOULDER = {"lb": ("L1", "LB"), "rb": ("R1", "RB"), "lt": ("L2", "LT"), "rt": ("R2", "RT"),
            "start": ("OPTIONS", "MENU"), "back": ("CREATE", "VIEW")}
_glyph_fonts = {}


def _glyph_font(size):
    font = _glyph_fonts.get(size)
    if font is None:
        font = _glyph_fonts[size] = pygame.font.Font(None, max(10, size))
    return font


def button_width(button, size, playstation):
    """Width of a button icon drawn `size` pixels tall."""
    if button in SHOULDER:
        label = SHOULDER[button][0 if playstation else 1]
        return max(int(size * 1.5), _glyph_font(int(size * 0.72)).size(label)[0] + int(size * 0.6))
    return size


def draw_button(surface, button, center, size, playstation):
    """Draws one controller button icon centred on `center`."""
    cx, cy = center
    r = size / 2
    dark, rim = (26, 24, 40), (120, 120, 150)
    if button in PS_FACE or button in XBOX_FACE:
        pygame.draw.circle(surface, dark, center, r)
        pygame.draw.circle(surface, rim, center, r, max(1, size // 14))
        if playstation:
            shape, colour = PS_FACE[button]
            k, w = r * 0.5, max(2, size // 8)
            if shape == "cross":
                pygame.draw.line(surface, colour, (cx - k, cy - k), (cx + k, cy + k), w)
                pygame.draw.line(surface, colour, (cx - k, cy + k), (cx + k, cy - k), w)
            elif shape == "circle":
                pygame.draw.circle(surface, colour, center, k * 1.05, w)
            elif shape == "square":
                pygame.draw.rect(surface, colour, pygame.Rect(cx - k * 0.9, cy - k * 0.9, k * 1.8, k * 1.8), w)
            else:
                pts = [(cx, cy - k * 1.05), (cx + k, cy + k * 0.7), (cx - k, cy + k * 0.7)]
                pygame.draw.polygon(surface, colour, pts, w)
        else:
            letter, colour = XBOX_FACE[button]
            img = _glyph_font(int(size * 0.95)).render(letter, True, colour)
            surface.blit(img, img.get_rect(center=(cx, cy + 1)))
    elif button in SHOULDER:
        label = SHOULDER[button][0 if playstation else 1]
        width = button_width(button, size, playstation)
        rect = pygame.Rect(0, 0, width, int(size * 0.8))
        rect.center = (cx, cy)
        pygame.draw.rect(surface, dark, rect, border_radius=int(size * 0.3))
        pygame.draw.rect(surface, rim, rect, max(1, size // 14), border_radius=int(size * 0.3))
        font = _glyph_font(int(size * 0.72))
        img = font.render(label, True, WHITE_SOFT)
        surface.blit(img, img.get_rect(center=(cx, cy + 1)))
    elif button == "dpad":
        a, b = r * 0.95, r * 0.34
        for rect in (pygame.Rect(cx - b, cy - a, 2 * b, 2 * a), pygame.Rect(cx - a, cy - b, 2 * a, 2 * b)):
            pygame.draw.rect(surface, rim, rect, border_radius=max(1, size // 10))
        pygame.draw.circle(surface, dark, center, b * 0.7)
    elif button == "lstick":
        pygame.draw.circle(surface, dark, center, r)
        pygame.draw.circle(surface, rim, center, r, max(1, size // 14))
        pygame.draw.circle(surface, rim, center, r * 0.55, max(1, size // 12))
        img = _glyph_font(int(size * 0.5)).render("L", True, WHITE_SOFT)
        surface.blit(img, img.get_rect(center=(cx, cy + 1)))


WHITE_SOFT = (225, 225, 240)


def rich_text(surface, font, parts, pos, color=S.WHITE, anchor="center", playstation=False):
    """A line mixing text and button icons. parts: strings and ("button", name) tuples."""
    size = max(24, int(font.get_height() * 1.25))
    gap = max(3, size // 6)
    widths = [font.size(p)[0] if isinstance(p, str) else button_width(p[1], size, playstation) + 2 * gap for p in parts]
    rect = pygame.Rect(0, 0, sum(widths), max(size, font.get_height()))
    setattr(rect, anchor, pos)
    x = rect.left
    for part, width in zip(parts, widths):
        if isinstance(part, str):
            img = font.render(part, True, color)
            surface.blit(img, img.get_rect(midleft=(x, rect.centery)))
        else:
            draw_button(surface, part[1], (x + width / 2, rect.centery), size, playstation)
        x += width
    return rect


# --------------------------------------------------------------------------
# Mouse cursors: a neon pointer for the menus, a neon reticle in a run
# --------------------------------------------------------------------------
def cursor_surface(kind):
    """A 32 x 32 image with a soft glow, and its hot spot."""
    size = 32
    image = pygame.Surface((size, size), pygame.SRCALPHA)
    halo = pygame.Surface((size, size), pygame.SRCALPHA)
    if kind == "reticle":
        c = (size // 2, size // 2)
        for width, alpha in ((7, 40), (4, 90)):
            pygame.draw.circle(halo, (*S.PINK, alpha), c, 10, width)
        image.blit(halo, (0, 0))
        pygame.draw.circle(image, (*S.PINK, 255), c, 10, 2)
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            a = (c[0] + dx * 6, c[1] + dy * 6)
            b = (c[0] + dx * 15, c[1] + dy * 15)
            pygame.draw.line(image, (*S.CYAN, 255), a, b, 2)
        pygame.draw.circle(image, (255, 255, 255, 255), c, 2)
        return image, c
    arrow = [(2, 2), (2, 24), (8, 18), (12, 28), (16, 26), (12, 17), (20, 17)]
    for width, alpha in ((7, 35), (4, 80)):
        pygame.draw.polygon(halo, (*S.CYAN, alpha), arrow, width)
    image.blit(halo, (0, 0))
    pygame.draw.polygon(image, (10, 30, 50, 235), arrow)
    pygame.draw.polygon(image, (*S.CYAN, 255), arrow, 2)
    pygame.draw.line(image, (255, 255, 255, 255), (4, 6), (4, 19), 1)
    return image, (2, 2)


_cursor_cache = {}


def set_cursor(kind):
    """Swaps the system mouse cursor for ours (drawn by the system: no lag). Safe anywhere."""
    try:
        if kind not in _cursor_cache:
            image, hot = cursor_surface(kind)
            _cursor_cache[kind] = pygame.cursors.Cursor(hot, image)
        pygame.mouse.set_cursor(_cursor_cache[kind])
        return True
    except (pygame.error, TypeError, ValueError):
        return False
