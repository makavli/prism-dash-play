"""Everything that moves: the player, enemies, the boss, bullets and power-ups.

Entities talk to the game through the `world` object passed to update():
world.player, world.rng, world.speed_scale, world.spawn_bullet(...),
world.add_enemy(...), world.particles, world.audio, world.shake.
"""

import math

import pygame
from pygame import Vector2

from prism_dash import render, ships
from prism_dash import settings as S

LEFT, TOP = S.ARENA_MARGIN, S.ARENA_MARGIN
RIGHT, BOTTOM = S.WIDTH - S.ARENA_MARGIN, S.HEIGHT - S.ARENA_MARGIN


def clamp_to_arena(pos, vel, radius, bounce=0.0):
    """Keep a circle inside the arena. Returns True if it touched a wall."""
    hit = False
    if pos.x < LEFT + radius:
        pos.x, vel.x, hit = LEFT + radius, abs(vel.x) * bounce, True
    elif pos.x > RIGHT - radius:
        pos.x, vel.x, hit = RIGHT - radius, -abs(vel.x) * bounce, True
    if pos.y < TOP + radius:
        pos.y, vel.y, hit = TOP + radius, abs(vel.y) * bounce, True
    elif pos.y > BOTTOM - radius:
        pos.y, vel.y, hit = BOTTOM - radius, -abs(vel.y) * bounce, True
    return hit


def angle_diff(a, b):
    """Smallest signed difference between two angles."""
    return (a - b + math.pi) % math.tau - math.pi


# ==========================================================================
# Player
# ==========================================================================
class Player:
    def __init__(self, ship=None):
        self.ship = ship or ships.SHIPS[0]
        self.pos = Vector2(S.WIDTH / 2, S.HEIGHT / 2)
        self.vel = Vector2()
        self.radius = S.PLAYER_RADIUS
        self.angle = -math.pi / 2
        self.lives = S.START_LIVES + self.ship.lives
        self.novas = S.START_NOVAS + self.ship.novas
        self.dash_time = 0.0
        self.dash_cd = 0.0            # time until the next charge comes back
        self.charges = self.ship.charges
        self.dash_dir = Vector2(1, 0)
        self.invuln = 1.0
        self.overdrive = 0.0
        self.kills_this_dash = 0
        self.perks = dict(self.ship.perks)   # perk id -> level
        self.barrier = bool(self.perks.get("barrier"))
        self.ghosts = []              # dash afterimages: [pos, angle, life]

    # ---- perks & ship ----
    def perk(self, perk_id):
        return self.perks.get(perk_id, 0)

    @property
    def color(self):
        return S.GOLD if self.overdrive > 0 else self.ship.color

    @property
    def max_lives(self):
        return S.MAX_LIVES + self.perk("vitality") + self.ship.lives

    @property
    def max_novas(self):
        return S.MAX_NOVAS + self.perk("novacache")

    @property
    def max_charges(self):
        return self.ship.charges

    @property
    def dash_duration(self):
        return S.DASH_TIME * self.ship.dash_time * (1 + 0.25 * self.perk("longdash"))

    @property
    def dash_speed(self):
        return S.DASH_SPEED * self.ship.dash_speed

    @property
    def max_speed(self):
        return S.PLAYER_MAX_SPEED * self.ship.move

    @property
    def overdrive_duration(self):
        return S.OVERDRIVE_TIME * (1 + 0.5 * self.perk("overcharge"))

    # ---- state ----
    @property
    def dashing(self):
        return self.dash_time > 0

    @property
    def safe(self):
        return self.dashing or self.invuln > 0

    @property
    def cooldown_total(self):
        if self.overdrive > 0:
            return S.OVERDRIVE_COOLDOWN
        return S.DASH_COOLDOWN * self.ship.cooldown * 0.8 ** self.perk("quickdash")

    @property
    def dash_ready(self):
        return self.charges > 0 and not self.dashing

    def try_dash(self, direction, world):
        if not self.dash_ready:
            return False
        if direction.length_squared() < 1e-6:
            direction = Vector2(math.cos(self.angle), math.sin(self.angle))
        self.dash_dir = direction.normalize()
        self.dash_time = self.dash_duration
        if self.charges == self.max_charges:
            self.dash_cd = self.cooldown_total      # start recharging
        self.charges -= 1
        self.kills_this_dash = 0
        self.angle = math.atan2(self.dash_dir.y, self.dash_dir.x)
        world.audio.play("dash", 0.7)
        world.particles.ring(self.pos, self.ship.color, speed=300, life=0.25, width=2)
        return True

    def refill(self, amount=None):
        """Give dash charges back (all of them if amount is None)."""
        self.charges = self.max_charges if amount is None else min(self.max_charges, self.charges + amount)
        if self.charges == self.max_charges:
            self.dash_cd = 0.0

    def refund_dash(self):
        """A kill during a dash gives a charge back: the core of chaining."""
        self.kills_this_dash += 1
        self.refill(1)
        self.dash_time = max(self.dash_time, 0.07)   # carry momentum through a cluster

    def end_dash(self):
        self.dash_time = 0.0

    def _recharge(self, world, dt):
        if self.charges >= self.max_charges:
            self.dash_cd = 0.0
            return
        if self.overdrive > 0:
            self.dash_cd = min(self.dash_cd, S.OVERDRIVE_COOLDOWN)
        self.dash_cd -= dt
        if self.dash_cd <= 0:
            self.charges += 1
            if self.charges < self.max_charges:
                self.dash_cd = self.cooldown_total
            else:
                self.dash_cd = 0.0
            if self.overdrive <= 0:
                world.audio.play("ready", 0.5)     # an audible "you can dash again"

    def update(self, world, dt, move):
        self.invuln = max(0.0, self.invuln - dt)
        self.overdrive = max(0.0, self.overdrive - dt)
        for g in self.ghosts:
            g[2] -= dt
        self.ghosts = [g for g in self.ghosts if g[2] > 0]
        if self.dashing:
            self.dash_time -= dt
            self.vel = self.dash_dir * self.dash_speed
            world.particles.trail(self.pos, self.color, self.angle, spread=0.25, speed=220, count=4)
            if not self.ghosts or self.ghosts[-1][0].distance_to(self.pos) > 26:
                self.ghosts.append([Vector2(self.pos), self.angle, 0.22])
            if self.dash_time <= 0:
                self.vel = self.dash_dir * self.max_speed
        else:
            if move.length_squared() > 0:
                self.vel += move.normalize() * S.PLAYER_ACCEL * self.ship.move * dt
                target = math.atan2(move.y, move.x)
                self.angle += angle_diff(target, self.angle) * min(1.0, dt * 14)
            self.vel *= math.exp(-S.PLAYER_FRICTION * dt)
            if self.vel.length() > self.max_speed:
                self.vel.scale_to_length(self.max_speed)
        if not self.dashing:
            self._recharge(world, dt)
        self.pos += self.vel * dt
        if clamp_to_arena(self.pos, self.vel, self.radius, bounce=0.4) and self.dashing:
            world.particles.burst(self.pos, self.ship.color, count=8, speed=200, life=0.3)

    def draw(self, surface, t):
        base = self.color
        for pos, angle, life in self.ghosts:     # afterimages
            k = life / 0.22
            ghost = tuple(int(c * 0.6 * k) for c in base)
            render.aa_outline(surface, ghost, render.ship_points(pos, self.radius, angle), 2)
        if self.invuln > 0 and not self.dashing and int(t * 20) % 2:
            return   # blink while invulnerable
        color = S.WHITE if self.dashing else base
        if self.barrier:
            r = self.radius + 9 + math.sin(t * 6) * 1.5
            render.glow(surface, self.pos, r * 2, S.WHITE, 0.25)
            pygame.draw.aacircle(surface, (200, 220, 255), self.pos, r, 1)
        pts = render.ship_points(self.pos, self.radius, self.angle)
        render.neon_polygon(surface, pts, color, width=3, glow_radius=self.radius * 3.2,
                            strength=1.1 if self.dashing else 0.8)
        back = Vector2(math.cos(self.angle), math.sin(self.angle)) * -self.radius
        for i in range(self.charges):            # one dot per stored dash
            side = Vector2(-back.y, back.x).normalize() * (i - (self.charges - 1) / 2) * 9 if self.charges > 1 else Vector2()
            render.glow(surface, self.pos + back * 1.2 + side, 9, color, 0.9)


# ==========================================================================
# Enemies
# ==========================================================================
class Enemy:
    kind = "enemy"
    radius = 14
    color = S.PINK
    points = 100
    speed = 120
    drops = True
    hurts = True          # touching it hurts the player
    spawn_grace = 0.15    # seconds after appearing when it can't touch or be touched

    def __init__(self, pos, world):
        self.pos = Vector2(pos)
        self.vel = Vector2()
        self.alive = True
        self.age = 0.0
        self.spin = world.rng.uniform(0, math.tau)
        self.speed = self.speed * world.speed_scale
        self.gaze = Vector2(1, 0)       # where its eye looks (the player)

    def size(self):
        """0 -> 1 over the first 0.3 s with a little overshoot: enemies pop in."""
        k = min(1.0, self.age / 0.3)
        return 1.0 + 2.2 * (k - 1) ** 3 + 1.2 * (k - 1) ** 2 if k < 1 else 1.0

    def to_player(self, world):
        d = world.player.pos - self.pos
        return d.normalize() if d.length_squared() > 1 else Vector2()

    def dash_hit(self, world):
        """What happens when the dashing player touches this: 'kill', 'bounce' or 'damage'."""
        return "kill"

    def update(self, world, dt):
        self.age += dt
        self.gaze = self.to_player(world) or self.gaze

    def on_death(self, world):
        world.particles.burst(self.pos, self.color, count=22, speed=380)
        world.particles.ring(self.pos, self.color, speed=380, life=0.35, width=3)

    def draw(self, surface, t):
        render.neon_circle(surface, self.pos, self.radius, self.color)


class Drifter(Enemy):
    """Slowly homes in on the player, wobbling as it goes."""
    kind = "drifter"

    def update(self, world, dt):
        super().update(world, dt)
        toward = self.to_player(world)
        wobble = Vector2(-toward.y, toward.x) * math.sin(self.age * 3 + self.spin) * 0.5
        desired = (toward + wobble) * self.speed
        self.vel += (desired - self.vel) * min(1.0, dt * 3)
        self.pos += self.vel * dt
        clamp_to_arena(self.pos, self.vel, self.radius, 0.5)

    def draw(self, surface, t):
        r = self.radius * self.size()
        pts = render.regular_polygon(self.pos, r * 1.15, 3, self.age * 2 + self.spin)
        render.neon_polygon(surface, pts, self.color, glow_radius=r * 2.6)
        inner = render.regular_polygon(self.pos, r * 0.62, 3, -self.age * 3 + self.spin)
        render.aa_outline(surface, render._scaled(self.color, 0.6), inner, 1)
        if r > 10:
            render.eye(surface, self.pos, self.color, self.gaze, max(2, r * 0.28), t + self.spin)
        else:
            pygame.draw.aacircle(surface, render.hot(self.color), self.pos, 2)


class Mini(Drifter):
    """The fragments a Splitter breaks into."""
    kind = "mini"
    radius = 9
    color = S.GREEN
    points = 50
    speed = 175
    drops = False
    spawn_grace = 0.35    # let the fragments scatter before they can be dashed

    def __init__(self, pos, world, kick):
        super().__init__(pos, world)
        self.vel = kick


class Dart(Enemy):
    """Locks on, telegraphs with a laser line, then charges in a straight line."""
    kind = "dart"
    radius = 12
    color = S.YELLOW
    points = 150
    speed = 760

    def __init__(self, pos, world):
        super().__init__(pos, world)
        self.state = "aim"
        self.timer = 1.1 + world.rng.uniform(0, 0.5)
        self.direction = Vector2(1, 0)
        self.angle = 0.0

    def update(self, world, dt):
        super().update(world, dt)
        self.timer -= dt
        if self.state == "aim":
            aim = self.to_player(world)
            if aim.length_squared() > 0:
                self.direction = aim
            self.angle = math.atan2(self.direction.y, self.direction.x)
            self.vel *= math.exp(-4 * dt)
            if self.timer <= 0:
                self.state, self.timer = "charge", 1.3
                world.particles.burst(self.pos, self.color, count=8, speed=150, life=0.3)
        elif self.state == "charge":
            self.vel = self.direction * self.speed
            world.particles.trail(self.pos, self.color, self.angle, count=1, speed=80)
            if self.timer <= 0:
                self.state, self.timer = "rest", 0.5
        else:
            self.vel *= math.exp(-6 * dt)
            if self.timer <= 0:
                self.state, self.timer = "aim", 0.9
        self.pos += self.vel * dt
        if clamp_to_arena(self.pos, self.vel, self.radius) and self.state == "charge":
            self.state, self.timer = "rest", 0.5
            world.particles.burst(self.pos, self.color, count=10, speed=200, life=0.3)

    def draw(self, surface, t):
        if self.state == "aim":
            k = 1 - max(0.0, self.timer) / 1.6
            end = self.pos + self.direction * 900
            line_color = tuple(int(c * (0.15 + 0.5 * k)) for c in self.color)
            pygame.draw.aaline(surface, line_color, self.pos, end, 1 + int(k * 2))
        r = self.radius * self.size()
        forward = Vector2(math.cos(self.angle), math.sin(self.angle))
        flare = 1.6 if self.state == "charge" else (0.6 + 0.4 * math.sin(t * 20) if self.state == "aim" else 0.4)
        render.glow(surface, self.pos - forward * r * 1.1, r * 1.6 * flare, S.ORANGE, 0.9)
        pts = render.ship_points(self.pos, r * 1.25, self.angle)
        render.neon_polygon(surface, pts, self.color, glow_radius=r * 2.8)
        pygame.draw.aaline(surface, render.hot(self.color), self.pos - forward * r * 0.4, self.pos + forward * r * 1.4, 2)


class Splitter(Enemy):
    """Big and slow. Breaks into three fast Minis when destroyed."""
    kind = "splitter"
    radius = 24
    color = S.GREEN
    points = 150
    speed = 70

    def update(self, world, dt):
        super().update(world, dt)
        self.vel += (self.to_player(world) * self.speed - self.vel) * min(1.0, dt * 1.5)
        self.pos += self.vel * dt
        clamp_to_arena(self.pos, self.vel, self.radius, 0.5)

    def on_death(self, world):
        super().on_death(world)
        base = world.rng.uniform(0, math.tau)
        for i in range(3):
            a = base + i * math.tau / 3
            kick = Vector2(math.cos(a), math.sin(a)) * 320
            world.add_enemy(Mini(self.pos + kick * 0.05, world, kick))

    def draw(self, surface, t):
        r = self.radius * self.size()
        breathe = 1 + 0.04 * math.sin(self.age * 4 + self.spin)
        pts = render.regular_polygon(self.pos, r * breathe, 6, self.age * 0.8 + self.spin)
        render.neon_polygon(surface, pts, self.color, glow_radius=r * 2.4)
        render.aa_outline(surface, render._scaled(self.color, 0.55), render.scaled_points(pts, self.pos, 0.8), 1)
        for i in range(3):                       # the three fragments, waiting inside
            a = -self.age * 2 + i * math.tau / 3
            c = (self.pos.x + math.cos(a) * r * 0.42, self.pos.y + math.sin(a) * r * 0.42)
            mini = render.regular_polygon(c, r * 0.24, 3, a * 2)
            render.aa_outline(surface, render.hot(self.color, 0.3), mini, 2)


class Spinner(Enemy):
    """Wanders between points and fires rotating rings of bullets."""
    kind = "spinner"
    radius = 17
    color = S.CYAN
    points = 200
    speed = 90

    def __init__(self, pos, world):
        super().__init__(pos, world)
        self.target = self._new_target(world)
        self.fire_timer = 1.5 + world.rng.uniform(0, 1.0)
        self.storm = getattr(getattr(world, "rules", None), "bullets", 1.0)   # BULLET STORM difficulty
        self.bullets = round((7 + min(5, world.wave // 4)) * self.storm)

    def _new_target(self, world):
        return Vector2(world.rng.uniform(LEFT + 100, RIGHT - 100),
                       world.rng.uniform(TOP + 100, BOTTOM - 100))

    def update(self, world, dt):
        super().update(world, dt)
        d = self.target - self.pos
        if d.length() < 20:
            self.target = self._new_target(world)
        else:
            self.vel += (d.normalize() * self.speed - self.vel) * min(1.0, dt * 2)
        self.pos += self.vel * dt
        clamp_to_arena(self.pos, self.vel, self.radius)
        self.fire_timer -= dt
        if self.fire_timer <= 0:
            self.fire_timer = 2.6 / world.speed_scale / self.storm
            offset = self.age * 1.7
            for i in range(self.bullets):
                a = offset + i * math.tau / self.bullets
                world.spawn_bullet(self.pos, Vector2(math.cos(a), math.sin(a)) * 165 * world.speed_scale, self.color)
            world.audio.play("shoot", 0.5)

    def draw(self, surface, t):
        charging = self.fire_timer < 0.45
        color = S.WHITE if charging and int(t * 30) % 2 else self.color
        r = self.radius * self.size()
        pts = render.regular_polygon(self.pos, r * 1.2, 4, self.age * 2.5)
        render.neon_polygon(surface, pts, color, glow_radius=r * 2.6)
        for i in range(4):                       # four nodes orbiting the other way
            a = -self.age * 4 + i * math.tau / 4
            node = (self.pos.x + math.cos(a) * r * 1.65, self.pos.y + math.sin(a) * r * 1.65)
            pygame.draw.aacircle(surface, render.hot(color, 0.4), node, 3)
        charge = 1 - min(1.0, max(0.0, self.fire_timer) / 1.5)   # the core fills before it fires
        pygame.draw.aacircle(surface, color, self.pos, r * 0.38, 2)
        if charge > 0.05:
            pygame.draw.aacircle(surface, render.hot(color, 0.5), self.pos, max(1, r * 0.3 * charge))


class Warden(Enemy):
    """Carries a shield that faces you. Dashing into the shield bounces you
    off: you have to get around it and hit it from the side or behind."""
    kind = "warden"
    radius = 18
    color = S.ORANGE
    points = 300
    speed = 95
    SHIELD_HALF_ARC = math.radians(70)
    TURN_RATE = 1.9

    def __init__(self, pos, world):
        super().__init__(pos, world)
        d = world.player.pos - self.pos
        self.facing = math.atan2(d.y, d.x)
        self.flash = 0.0

    def dash_hit(self, world):
        to_player = world.player.pos - self.pos
        a = math.atan2(to_player.y, to_player.x)
        return "bounce" if abs(angle_diff(a, self.facing)) < self.SHIELD_HALF_ARC else "kill"

    def update(self, world, dt):
        super().update(world, dt)
        self.flash = max(0.0, self.flash - dt)
        d = world.player.pos - self.pos
        target = math.atan2(d.y, d.x)
        turn = angle_diff(target, self.facing)
        self.facing += max(-self.TURN_RATE * dt, min(self.TURN_RATE * dt, turn))
        self.vel += (self.to_player(world) * self.speed - self.vel) * min(1.0, dt * 2)
        self.pos += self.vel * dt
        clamp_to_arena(self.pos, self.vel, self.radius, 0.5)

    def draw(self, surface, t):
        size = self.size()
        pts = render.regular_polygon(self.pos, self.radius * size, 5, self.facing)
        render.neon_polygon(surface, pts, self.color, glow_radius=self.radius * 2.4)
        render.eye(surface, self.pos, self.color, self.gaze, self.radius * 0.32 * size, t + self.spin)
        r = (self.radius + 11) * size
        rect = pygame.Rect(0, 0, r * 2, r * 2)
        rect.center = self.pos
        shield = S.WHITE if self.flash > 0 else S.GOLD
        # pygame's arc angles go counter-clockwise with y up, so negate ours
        start = -self.facing - self.SHIELD_HALF_ARC
        render.glow(surface, self.pos + Vector2(math.cos(self.facing), math.sin(self.facing)) * r,
                    26, shield, 0.7)
        pygame.draw.arc(surface, shield, rect, start, start + 2 * self.SHIELD_HALF_ARC, 5)


class Mine(Enemy):
    """Left behind by Weavers. Arms, blinks faster and faster, then bursts
    into bullets. Dash through it first to defuse it."""
    kind = "mine"
    radius = 9
    color = S.LIME
    points = 25
    drops = False
    FUSE = 4.5

    def __init__(self, pos, world):
        super().__init__(pos, world)
        self.fuse = self.FUSE

    def update(self, world, dt):
        super().update(world, dt)
        self.fuse -= dt
        if self.fuse <= 0:
            self.alive = False
            for i in range(6):
                a = self.spin + i * math.tau / 6
                world.spawn_bullet(self.pos, Vector2(math.cos(a), math.sin(a)) * 200, self.color)
            world.particles.burst(self.pos, self.color, count=14, speed=240, life=0.35)
            world.audio.play("shoot", 0.6)

    def draw(self, surface, t):
        blink_rate = 4 + (1 - self.fuse / self.FUSE) * 22
        lit = int(t * blink_rate) % 2 == 0
        color = S.WHITE if lit and self.fuse < 1.5 else self.color
        render.glow(surface, self.pos, self.radius * (3.0 if lit else 2.0), color, 0.6)
        r = self.radius * self.size()
        pts = render.regular_polygon(self.pos, r, 8, self.spin + self.age)
        pygame.draw.polygon(surface, render._scaled(color, 0.2), pts)
        render.aa_outline(surface, color, pts, 2)
        for x, y in pts[::2]:                    # spikes
            pygame.draw.aaline(surface, color, (x, y), (self.pos.x + (x - self.pos.x) * 1.45,
                                                      self.pos.y + (y - self.pos.y) * 1.45), 2)
        pygame.draw.aacircle(surface, render.hot(color), self.pos, 3)


class Weaver(Enemy):
    """Criss-crosses the arena, bouncing off walls and laying mines."""
    kind = "weaver"
    radius = 16
    color = S.LIME
    points = 250
    speed = 170
    LAY_EVERY = 1.5

    def __init__(self, pos, world):
        super().__init__(pos, world)
        a = world.rng.uniform(0, math.tau)
        self.vel = Vector2(math.cos(a), math.sin(a)) * self.speed
        self.lay_timer = 1.0

    def update(self, world, dt):
        super().update(world, dt)
        self.pos += self.vel * dt
        if clamp_to_arena(self.pos, self.vel, self.radius, bounce=1.0):
            self.vel.rotate_ip(world.rng.uniform(-25, 25))
            self.vel.scale_to_length(self.speed)
        self.lay_timer -= dt
        if self.lay_timer <= 0 and len([e for e in world.enemies if e.kind == "mine"]) < 14:
            self.lay_timer = self.LAY_EVERY
            world.add_enemy(Mine(self.pos, world))

    def draw(self, surface, t):
        angle = math.atan2(self.vel.y, self.vel.x)
        r = self.radius * self.size()
        forward = Vector2(math.cos(angle), math.sin(angle))
        side = Vector2(-forward.y, forward.x)
        flap = 0.85 + 0.15 * math.sin(self.age * 10)    # the wings beat
        pts = [self.pos + forward * r * 1.2, self.pos - forward * r * 0.8 + side * r * flap,
               self.pos - forward * r * 0.25, self.pos - forward * r * 0.8 - side * r * flap]
        render.glow(surface, self.pos - forward * r * 0.6, r * 1.4, S.CYAN, 0.6)
        render.neon_polygon(surface, pts, self.color, glow_radius=r * 2.6)
        pygame.draw.aacircle(surface, render.hot(self.color), self.pos + forward * r * 0.3, 3)


class Boss(Enemy):
    """THE CORE. Takes several dash hits. Cycles through bullet spirals,
    summoning drifters and ring bursts, and gets angrier at half health."""
    kind = "boss"
    title = "THE CORE"
    radius = 56
    color = S.PURPLE
    speed = 60
    drops = False

    def __init__(self, pos, world):
        super().__init__(pos, world)
        tier = world.wave // 5
        self.max_hp = 6 + tier * 2
        self.hp = self.max_hp
        self.points = 5000 * tier
        self.invuln = 0.0
        self.state = "spiral"
        self.timer = 3.0
        self.shot_timer = 0.0
        self.home = Vector2(S.WIDTH / 2, S.HEIGHT / 2)

    def scale_health(self, k):
        """Difficulty: more or less health."""
        self.max_hp = max(2, round(self.max_hp * k))
        self.hp = self.max_hp

    @property
    def enraged(self):
        return self.hp <= self.max_hp / 2

    def dash_hit(self, world):
        return "damage"

    def take_hit(self, world):
        if self.invuln > 0:
            return False
        self.hp -= 1
        self.invuln = 0.45
        world.particles.burst(self.pos, S.WHITE, count=30, speed=500)
        world.particles.ring(self.pos, self.color, speed=600, life=0.4)
        if self.hp <= 0:
            self.alive = False
        return True

    def update(self, world, dt):
        super().update(world, dt)
        self.invuln = max(0.0, self.invuln - dt)
        rage = 1.35 if self.enraged else 1.0
        # drift in a figure-eight around the centre
        target = self.home + Vector2(math.sin(self.age * 0.5) * 330, math.sin(self.age * 1.0) * 160)
        self.vel += ((target - self.pos) * 1.2 - self.vel) * min(1.0, dt * 2)
        self.pos += self.vel * dt
        clamp_to_arena(self.pos, self.vel, self.radius)

        self.timer -= dt
        self.shot_timer -= dt
        if self.state == "spiral" and self.shot_timer <= 0:
            self.shot_timer = 0.11 / rage
            for arm in range(3 if self.enraged else 2):
                a = self.age * 2.4 + arm * math.tau / (3 if self.enraged else 2)
                world.spawn_bullet(self.pos, Vector2(math.cos(a), math.sin(a)) * 190, S.PINK)
        elif self.state == "burst" and self.shot_timer <= 0:
            self.shot_timer = 0.8 / rage
            for i in range(18):
                a = i * math.tau / 18 + self.age
                world.spawn_bullet(self.pos, Vector2(math.cos(a), math.sin(a)) * 230, S.ORANGE, radius=7)
            world.audio.play("shoot", 0.8)
        if self.timer <= 0:
            order = ["spiral", "summon", "burst"]
            self.state = order[(order.index(self.state) + 1) % 3]
            self.timer = {"spiral": 3.2, "summon": 1.2, "burst": 2.6}[self.state]
            self.shot_timer = 0.3
            if self.state == "summon":
                for i in range(4 if self.enraged else 3):
                    a = i * math.tau / 4 + self.age
                    world.spawn_marker("drifter", self.pos + Vector2(math.cos(a), math.sin(a)) * 140)

    def on_death(self, world):
        for color in (S.PURPLE, S.PINK, S.WHITE, S.CYAN):
            world.particles.burst(self.pos, color, count=70, speed=900, life=1.2, size=4)
        for i in range(4):
            world.particles.ring(self.pos, (S.PURPLE, S.PINK, S.CYAN, S.WHITE)[i],
                                 speed=500 + i * 250, life=0.9, width=6)

    def draw(self, surface, t):
        hurt = self.invuln > 0 and int(t * 30) % 2
        color = S.WHITE if hurt else (S.PINK if self.enraged else self.color)
        render.glow(surface, self.pos, self.radius * 3, color, 0.9)
        for i, sides in enumerate((6, 4, 3)):
            r = self.radius * (1 - i * 0.28)
            pts = render.regular_polygon(self.pos, r, sides, self.age * (0.6 + i * 0.7) * (-1) ** i)
            render.aa_outline(surface, color, pts, 3)
            render.aa_outline(surface, render.hot(color), pts, 1)
        beat = 1 + 0.25 * max(0.0, math.sin(t * (9 if self.enraged else 5)))   # a heartbeat
        render.glow(surface, self.pos, 26 * beat, S.WHITE, 0.8)
        pygame.draw.aacircle(surface, S.WHITE, self.pos, 8 * beat)


class SerpentSegment(Enemy):
    """One link of the Serpent's body. Each one is a normal dash kill —
    which refunds your dash, so a good run tears down the whole body in one chain."""
    kind = "segment"
    radius = 15
    color = S.EMERALD
    points = 150
    drops = False
    spawn_grace = 0.8

    def __init__(self, pos, world, index):
        super().__init__(pos, world)
        self.index = index

    def draw(self, surface, t):
        r = self.radius * self.size()
        pts = render.regular_polygon(self.pos, r, 6, self.age * 1.5 + self.index * 0.5)
        render.neon_polygon(surface, pts, self.color, glow_radius=r * 2.2, strength=0.8)
        pygame.draw.aacircle(surface, render.hot(self.color, 0.4), self.pos, max(2, r * 0.25))


class Serpent(Boss):
    """THE SERPENT. A head followed by a long chain of segments. The head is
    shielded until every segment is destroyed; then it panics, speeds up and
    takes a few dash hits to kill."""
    kind = "serpent"
    title = "THE SERPENT"
    radius = 24
    color = S.EMERALD
    SPACING = 30
    TURN_RATE = 2.3

    def __init__(self, pos, world):
        Enemy.__init__(self, pos, world)
        tier = max(1, world.wave // 10)
        self.head_hp = 3 + tier
        self.segments = []
        for i in range(10 + 3 * (tier - 1)):
            seg = SerpentSegment(self.pos + Vector2(-(i + 1) * self.SPACING * 0.4, 0), world, i)
            self.segments.append(seg)
            world.add_enemy(seg)
        self.max_hp = self.head_hp + len(self.segments)
        self.points = 6000 * tier
        self.invuln = 0.0
        to_player = world.player.pos - self.pos
        self.heading = math.atan2(to_player.y, to_player.x)
        self.shot_timer = 2.0
        self.flash = 0.0

    def scale_health(self, k):
        """Difficulty: the head takes more or fewer strikes (the body stays one hit a link)."""
        self.head_hp = max(1, round(self.head_hp * k))
        self.max_hp = self.head_hp + len(self.segments)

    @property
    def hp(self):
        return self.head_hp + sum(1 for s in self.segments if s.alive)

    @property
    def shielded(self):
        return any(s.alive for s in self.segments)

    @property
    def enraged(self):
        return not self.shielded

    def dash_hit(self, world):
        return "bounce" if self.shielded else "damage"

    def take_hit(self, world):
        if self.shielded or self.invuln > 0:
            return False
        self.head_hp -= 1
        self.invuln = 0.45
        world.particles.burst(self.pos, S.WHITE, count=30, speed=500)
        world.particles.ring(self.pos, self.color, speed=600, life=0.4)
        if self.head_hp <= 0:
            self.alive = False
        return True

    def update(self, world, dt):
        Enemy.update(self, world, dt)
        self.invuln = max(0.0, self.invuln - dt)
        self.flash = max(0.0, self.flash - dt)
        speed = (300 if self.enraged else 215) * world.speed_scale
        # steer towards a point that swings around the player: a slithering chase
        swing = Vector2(math.cos(self.age * 0.9), math.sin(self.age * 1.3)) * 220
        target = world.player.pos + swing
        desired = math.atan2(target.y - self.pos.y, target.x - self.pos.x)
        turn = angle_diff(desired, self.heading)
        rate = self.TURN_RATE * (1.4 if self.enraged else 1.0)
        self.heading += max(-rate * dt, min(rate * dt, turn))
        self.vel = Vector2(math.cos(self.heading), math.sin(self.heading)) * speed
        self.pos += self.vel * dt
        if clamp_to_arena(self.pos, self.vel, self.radius, bounce=1.0):
            self.heading = math.atan2(self.vel.y, self.vel.x)

        leader = self.pos
        for seg in self.segments:               # the body follows like a chain
            if not seg.alive:
                continue
            d = seg.pos - leader
            if d.length() > self.SPACING:
                seg.pos = leader + d.normalize() * self.SPACING
            leader = seg.pos

        self.shot_timer -= dt
        if self.shot_timer <= 0:
            alive = [s for s in self.segments if s.alive]
            if alive:
                self.shot_timer = 1.7 / world.speed_scale
                shooter = world.rng.choice(alive)
                aim = world.player.pos - shooter.pos
                base = math.atan2(aim.y, aim.x)
                for spread in (-0.25, 0, 0.25):
                    a = base + spread
                    world.spawn_bullet(shooter.pos, Vector2(math.cos(a), math.sin(a)) * 210, self.color)
            else:
                self.shot_timer = 1.3
                for i in range(12):
                    a = self.age + i * math.tau / 12
                    world.spawn_bullet(self.pos, Vector2(math.cos(a), math.sin(a)) * 230, S.PINK, radius=6)
            world.audio.play("shoot", 0.7)

    def draw(self, surface, t):
        alive = [s for s in self.segments if s.alive]
        spine = [self.pos] + [s.pos for s in alive]
        if len(spine) > 1:
            render.aa_lines(surface, tuple(c // 3 for c in self.color), False, spine, 4)
        hurt = self.invuln > 0 and int(t * 30) % 2
        color = S.WHITE if hurt else (S.PINK if self.enraged else self.color)
        render.glow(surface, self.pos, self.radius * 3.2, color, 0.9)
        head = render.ship_points(self.pos, self.radius, self.heading)
        pygame.draw.polygon(surface, (10, 30, 25), head)
        render.aa_outline(surface, color, head, 3)
        if self.shielded:
            r = self.radius + 12 + math.sin(t * 5) * 2
            render.glow(surface, self.pos, r * 1.6, S.WHITE, 0.3)
            pygame.draw.aacircle(surface, (210, 255, 240), self.pos, r, 2)


ENEMY_CLASSES = {"drifter": Drifter, "dart": Dart, "splitter": Splitter, "weaver": Weaver,
                 "serpent": Serpent,
                 "spinner": Spinner, "warden": Warden, "boss": Boss}


# ==========================================================================
# Bullets and power-ups
# ==========================================================================
class Bullet:
    __slots__ = ("pos", "vel", "color", "radius", "alive")

    def __init__(self, pos, vel, color, radius=5):
        self.pos, self.vel, self.color, self.radius = Vector2(pos), Vector2(vel), color, radius
        self.alive = True

    def update(self, dt):
        self.pos += self.vel * dt
        if not (LEFT - 20 < self.pos.x < RIGHT + 20 and TOP - 20 < self.pos.y < BOTTOM + 20):
            self.alive = False

    def draw(self, surface):
        render.glow(surface, self.pos, self.radius * 3, self.color, 0.8)
        pygame.draw.aacircle(surface, S.WHITE, self.pos, self.radius - 2)


class PowerUp:
    INFO = {
        "life": (S.RED, "+1 LIFE"),
        "nova": (S.PURPLE, "+1 NOVA"),
        "overdrive": (S.GOLD, "OVERDRIVE!"),
    }
    radius = 14

    def __init__(self, pos, kind):
        self.pos = Vector2(pos)
        self.kind = kind
        self.life = S.POWERUP_LIFETIME
        self.alive = True

    @property
    def color(self):
        return self.INFO[self.kind][0]

    @property
    def label(self):
        return self.INFO[self.kind][1]

    def update(self, dt):
        self.life -= dt
        if self.life <= 0:
            self.alive = False

    def draw(self, surface, t):
        if self.life < 2.5 and int(t * 10) % 2:
            return
        y = self.pos.y + math.sin(t * 4) * 4
        center = (self.pos.x, y)
        render.neon_circle(surface, center, self.radius, self.color, width=2, glow_scale=2.4)
        if self.kind == "life":
            pygame.draw.aaline(surface, S.WHITE, (center[0] - 6, y), (center[0] + 6, y), 3)
            pygame.draw.aaline(surface, S.WHITE, (center[0], y - 6), (center[0], y + 6), 3)
        elif self.kind == "nova":
            pygame.draw.aacircle(surface, S.WHITE, center, 5, 2)
            pygame.draw.aacircle(surface, S.WHITE, center, 9, 1)
        else:
            pts = [(center[0] - 2, y - 8), (center[0] + 4, y - 1), (center[0], y - 1),
                   (center[0] + 2, y + 8), (center[0] - 4, y + 1), (center[0], y + 1)]
            pygame.draw.polygon(surface, S.WHITE, pts)
