"""Difficulty levels. Each level is a set of options the player can tick or untick; the
options turn into the numbers the game runs on (Rules). Pure Python, no pygame.

Copyright (c) 2026 Massinissa K. All rights reserved.
"""

from dataclasses import dataclass

# id -> (name, what it does)
OPTIONS = {
    "aim_assist":    ("AIM ASSIST", "a dash bends towards the enemy you are heading for"),
    "steady_aim":    ("STEADY AIM", "softer, less twitchy steering and aiming"),
    "fewer_enemies": ("FEWER ENEMIES", "about a third fewer enemies in each wave"),
    "weak_bosses":   ("WEAKER BOSSES", "bosses have 40% less health"),
    "slow_enemies":  ("SLOWER ENEMIES", "enemies move 15% slower"),
    "extra_life":    ("EXTRA LIFE", "start with one more life"),
    "more_enemies":  ("MORE ENEMIES", "about a third more enemies in each wave"),
    "tough_bosses":  ("TOUGHER BOSSES", "bosses have 50% more health"),
    "fast_enemies":  ("FASTER ENEMIES", "enemies move 15% faster"),
    "horde":         ("HORDE", "twice the enemies, and waves arrive back to back"),
    "ambush":        ("AMBUSH", "enemies appear from every side, close to you"),
    "bullet_storm":  ("BULLET STORM", "shooters fire more bullets, and faster"),
    "one_life":      ("ONE LIFE", "one hit and the run is over"),
}

# (id, name, colour, options ticked by default). Each level has its own high-score boards.
LEVELS = [
    ("easy", "EASY", (110, 255, 140),
     ("aim_assist", "steady_aim", "fewer_enemies", "weak_bosses", "slow_enemies", "extra_life")),
    ("medium", "MEDIUM", (60, 230, 255), ()),
    ("hard", "HARD", (255, 160, 60), ("more_enemies", "tough_bosses", "fast_enemies")),
    ("die", "YOU WILL DIE", (255, 60, 90),
     ("horde", "ambush", "bullet_storm", "tough_bosses", "fast_enemies")),
    # V3: locked until a run on YOU WILL DIE is won; you start with your last run's upgrades
    ("ngplus", "NEW GAME+", (255, 200, 90),
     ("horde", "ambush", "bullet_storm", "tough_bosses", "fast_enemies")),
]
BY_ID = {level[0]: level for level in LEVELS}
DEFAULT = "medium"


def unlocked_levels(settings):
    """The levels the launch screen offers: NEW GAME+ only once it's been earned."""
    return [lv[0] for lv in LEVELS if lv[0] != "ngplus" or settings.get("ngplus_unlocked")]


def level(level_id):
    return BY_ID.get(level_id, BY_ID[DEFAULT])


def defaults(level_id):
    return list(level(level_id)[3])


def ticked(settings, level_id=None):
    """The options ticked for a level (the player's own choice, or the level's defaults)."""
    level_id = level(level_id or settings.get("difficulty"))[0]
    chosen = settings.get("difficulty_options", {}).get(level_id)
    if not isinstance(chosen, list):
        return defaults(level_id)
    return [o for o in chosen if o in OPTIONS]


def toggle(settings, option, level_id=None):
    level_id = level(level_id or settings.get("difficulty"))[0]
    current = ticked(settings, level_id)
    current = [o for o in current if o != option] if option in current else current + [option]
    settings.setdefault("difficulty_options", {})[level_id] = [o for o in OPTIONS if o in current]


def reset(settings, level_id=None):
    level_id = level(level_id or settings.get("difficulty"))[0]
    settings.setdefault("difficulty_options", {}).pop(level_id, None)


def board_suffix(level_id):
    """Medium keeps the original high-score boards; the other levels get their own."""
    level_id = level(level_id)[0]
    return "" if level_id == DEFAULT else f"-{level_id}"


@dataclass
class Rules:
    """What the world actually uses. Rules() is the classic game (MEDIUM, nothing ticked)."""
    level: str = DEFAULT
    enemies: float = 1.0          # enemies per wave
    enemy_speed: float = 1.0
    boss_health: float = 1.0
    extra_lives: int = 0
    one_life: bool = False
    aim_assist: bool = False
    steady_aim: bool = False
    ambush: bool = False
    pace: float = 1.0             # time between spawn groups and waves
    group_size: int = 4
    bullets: float = 1.0          # bullet count and speed

    @classmethod
    def build(cls, level_id, options):
        o = set(options)
        r = cls(level=level(level_id)[0])
        if "fewer_enemies" in o:
            r.enemies *= 0.67
        if "more_enemies" in o:
            r.enemies *= 1.35
        if "horde" in o:
            r.enemies *= 2.0
            r.pace *= 0.5
            r.group_size = 6
        r.enemy_speed *= (0.85 if "slow_enemies" in o else 1.0) * (1.15 if "fast_enemies" in o else 1.0)
        r.boss_health *= (0.6 if "weak_bosses" in o else 1.0) * (1.5 if "tough_bosses" in o else 1.0)
        r.extra_lives = 1 if "extra_life" in o else 0
        r.one_life = "one_life" in o
        r.aim_assist = "aim_assist" in o
        r.steady_aim = "steady_aim" in o
        r.ambush = "ambush" in o
        r.bullets = 1.5 if "bullet_storm" in o else 1.0
        return r

    @classmethod
    def from_settings(cls, settings):
        level_id = level(settings.get("difficulty"))[0]
        return cls.build(level_id, ticked(settings, level_id))
