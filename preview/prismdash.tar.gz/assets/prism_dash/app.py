"""Window, menus, HUD and the main loop."""

import asyncio
import math
import sys
import warnings

import pygame
from pygame import Vector2

import random

from prism_dash import __copyright__, __version__, modes, perks, render, ships, storage, web
from prism_dash import settings as S
from prism_dash.achievements import ACHIEVEMENTS, newly_unlocked
from prism_dash.audio import Audio
from prism_dash.gamepad import PADBUTTON, Pads, hint_parts
from prism_dash.autopilot import Autopilot
from prism_dash.icon import make_icon
from prism_dash.particles import Particles
from prism_dash.world import Controls, World


def _pad(e, *names):
    """A controller button press (any pad, any layout) among names."""
    return e.type == PADBUTTON and e.button in names


def _pad_press(e):
    """A real button press on a pad (not the stick nudging a menu)."""
    return e.type == PADBUTTON and not getattr(e, "stick", False)


class FeelingAudio:
    """The game's audio, plus controller rumble for the same moments."""

    def __init__(self, audio, pads):
        self._audio, self._pads = audio, pads

    def play(self, name, *args, **kwargs):
        self._audio.play(name, *args, **kwargs)
        self._pads.feel(name)

    def kill(self, chain):
        self._audio.kill(chain)
        self._pads.feel("kill")

    def __getattr__(self, name):
        return getattr(self._audio, name)


class SilentAudio:
    """Stands in for Audio in the menu's demo game."""
    def play(self, *_a, **_k): pass
    def kill(self, *_a, **_k): pass


class App:
    def __init__(self):
        pygame.init()
        self.settings = storage.load_settings()
        pygame.display.set_caption(S.TITLE)
        if not web.IS_WEB:                # the page has its own favicon
            pygame.display.set_icon(make_icon(64))
        self._create_display()
        self.canvas = pygame.Surface((S.WIDTH, S.HEIGHT))
        self.clock = pygame.time.Clock()

        self.fonts = {
            "huge": pygame.font.Font(None, 150),
            "big": pygame.font.Font(None, 72),
            "medium": pygame.font.Font(None, 38),
            "small": pygame.font.Font(None, 28),
            "tiny": pygame.font.Font(None, 22),
        }
        self.input_seen = False           # browser: sound is allowed after the first click / key
        self.pads = Pads()
        self.cursor = None                 # which neon cursor is showing
        self.audio = FeelingAudio(Audio(muted=self.settings["muted"]), self.pads)
        self.shake = render.Shake()
        self.shake.enabled = self.settings["shake"]
        self.background = render.Background(self.settings.get("effects", "high"))

        self.state = "menu"
        self.menu_index = 0
        self.world = None
        self.over_timer = 0.0
        self.result = None
        self.draft_index = 0
        self.unlocked = storage.load_achievements()
        self.run_unlocks = []
        self.toasts = []                  # [achievement id, time shown]
        self.show_fps = False
        self.t = 0.0
        self._new_demo()

    # ------------------------------------------------------------ setup
    def _new_demo(self):
        self.demo = World(SilentAudio(), Particles(self.fonts), render.Shake(),
                          render.Background(self.settings.get("effects", "high")), seed=None,
                          ship=random.choice(ships.SHIPS))
        self.demo.player.lives = 99
        self.demo_pilot = Autopilot(skill=1.0)

    def run_setup(self):
        """(mode, seed, ship) for the next run, from the launch screen's choices."""
        mode = self.settings.get("mode", "classic")
        if mode == "daily":
            return mode, modes.daily_seed(), modes.daily_ship()
        ship = ships.get(self.settings.get("ship"))
        if not ships.is_unlocked(ship, self.unlocked):
            ship = ships.SHIPS[0]
        return mode, None, ship

    def start_game(self):
        self.audio.play("select")
        self.particles = Particles(self.fonts)
        mode, seed, ship = self.run_setup()
        self.world = World(self.audio, self.particles, self.shake, self.background,
                           seed=seed, mode=mode, ship=ship)
        self.state = "play"
        self.over_timer = 0.0
        self.result = None
        self.run_unlocks = []

    def check_achievements(self):
        new = newly_unlocked(self.world.run_stats(), self.unlocked)
        if new:
            self.unlocked = storage.unlock_achievements(new)
            self.run_unlocks += new
            for aid in new:
                self.toasts.append([aid, 0.0])
            self.audio.play("achievement")

    # ------------------------------------------------------------ menu
    def menu_items(self):
        on_off = lambda flag: "ON" if flag else "OFF"   # noqa: E731
        return [
            ("play", "PLAY"),
            ("howto", "HOW TO PLAY"),
            ("trophies", f"ACHIEVEMENTS  {len(self.unlocked)}/{len(ACHIEVEMENTS)}"),
            ("sound", f"SOUND: {on_off(not self.settings['muted'])}"),
            ("shake", f"SCREEN SHAKE: {on_off(self.settings['shake'])}"),
            ("effects", f"EFFECTS: {'FULL' if self.settings.get('effects', 'high') != 'low' else 'LIGHT'}"),
            ("fullscreen", "FULLSCREEN" if web.IS_WEB else f"FULLSCREEN: {on_off(self.settings['fullscreen'])}"),
        ] + ([] if web.IS_WEB else [("quit", "QUIT")])

    def menu_rects(self):
        rects = []
        for i, (_, label) in enumerate(self.menu_items()):
            img = self.fonts["medium"].render(label, True, S.WHITE)
            rects.append(img.get_rect(midleft=(120, 310 + i * 50)).inflate(30, 14))
        return rects

    def activate(self, key):
        self.audio.play("select")
        if key == "play":
            self.state = "launch"
            self.launch_row = 0
        elif key == "howto":
            self.state = "howto"
        elif key == "trophies":
            self.state = "trophies"
        elif key == "sound":
            self.settings["muted"] = not self.settings["muted"]
            self.audio.set_muted(self.settings["muted"])
        elif key == "shake":
            self.settings["shake"] = not self.settings["shake"]
            self.shake.enabled = self.settings["shake"]
        elif key == "effects":
            self.settings["effects"] = "low" if self.settings.get("effects", "high") != "low" else "high"
            self.background.effects = self.settings["effects"]
            self.demo.bg.effects = self.settings["effects"]
        elif key == "fullscreen":
            self.toggle_fullscreen()
        elif key == "quit":
            self.quit()
        storage.save_settings(self.settings)

    # ------------------------------------------------------------ display
    @staticmethod
    def display_size():
        """A logical resolution with the monitor's shape. The 1280x720 arena sits
        in the middle; wider screens (21:9, 32:9) get extra background at the
        sides, taller ones (16:10, 4:3) at the top and bottom. The playfield
        itself never changes size, so every screen plays exactly the same.
        In a browser the canvas is fixed at 16:9 and the page scales it."""
        if web.IS_WEB:
            return S.WIDTH, S.HEIGHT
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0]
        except (pygame.error, IndexError):
            return S.WIDTH, S.HEIGHT
        aspect = dw / dh
        if aspect >= S.WIDTH / S.HEIGHT:
            return round(S.HEIGHT * aspect), S.HEIGHT
        return S.WIDTH, round(S.WIDTH / aspect)

    def _create_display(self):
        # The size is chosen once: pygame-ce crashes if a SCALED display changes
        # size later, so fullscreen is toggled without recreating it.
        if web.IS_WEB:
            # The browser page scales the canvas; desktop window flags don't apply.
            pygame.display.set_mode((S.WIDTH, S.HEIGHT))
            self._bind_surfaces()
            return
        flags = pygame.SCALED | pygame.RESIZABLE
        if self.settings["fullscreen"]:
            flags |= pygame.FULLSCREEN
        size = self.display_size()
        try:
            pygame.display.set_mode(size, flags, vsync=1)
        except pygame.error:
            pygame.display.set_mode(size, flags)
        self._bind_surfaces()
        window = self._window()
        if window is not None:
            # never let the window be dragged/resized into something unplayable
            window.minimum_size = (size[0] // 2, size[1] // 2)
            if not self.settings["fullscreen"]:
                self.restore_window()

    @staticmethod
    def _window():
        """The window behind pygame.display (used to resize/centre it).
        from_display_module() is deprecated in pygame-ce in favour of creating a
        pygame.Window directly; switch to that if it's ever removed."""
        if web.IS_WEB:
            return None
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", DeprecationWarning)
                return pygame.Window.from_display_module()
        except (AttributeError, pygame.error):
            return None

    def normal_window_size(self):
        """The windowed size: the logical size times the largest whole-number
        scale that fits comfortably on the desktop (room left for the taskbar
        and title bar), shrunk instead if even x1 doesn't fit."""
        lw, lh = self.display.get_size()
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0]
        except (pygame.error, IndexError):
            return lw, lh
        max_w, max_h = dw * 0.90, dh * 0.85
        scale = max(1, int(min(max_w / lw, max_h / lh)))
        if lw * scale > max_w or lh * scale > max_h:
            scale = min(max_w / lw, max_h / lh)
        return round(lw * scale), round(lh * scale)

    def restore_window(self):
        """Back to a normal-size window, centred, with the title bar on screen.
        (Without this, leaving a fullscreen the game *started* in kept the
        window desktop-sized, pushing its title bar and close button off-screen.)"""
        window = self._window()
        if window is None:
            return
        window.size = self.normal_window_size()
        window.position = pygame.WINDOWPOS_CENTERED

    def _bind_surfaces(self):
        """self.display is the whole screen; self.screen is the 1280x720 arena
        inside it, which all HUD and menu drawing uses."""
        self.display = pygame.display.get_surface()
        w, h = self.display.get_size()
        self.offset = ((w - S.WIDTH) // 2, (h - S.HEIGHT) // 2)
        self.screen = self.display.subsurface(pygame.Rect(self.offset, (S.WIDTH, S.HEIGHT)))
        self._veils = {}

    def to_arena(self, event):
        """Convert mouse positions from screen to arena coordinates."""
        if hasattr(event, "pos") and self.offset != (0, 0):
            x, y = event.pos
            return pygame.event.Event(event.type, {**event.dict, "pos": (x - self.offset[0], y - self.offset[1])})
        return event

    def toggle_fullscreen(self):
        if web.IS_WEB:
            web.toggle_browser_fullscreen()
            return
        pygame.display.toggle_fullscreen()
        if not pygame.display.is_fullscreen():
            self.restore_window()
        self._bind_surfaces()
        self.settings["fullscreen"] = pygame.display.is_fullscreen()
        storage.save_settings(self.settings)

    def quit(self):
        storage.save_settings(self.settings)
        self.pads.close()
        if web.IS_WEB:
            return                      # a browser tab is closed by the player, not the game
        pygame.quit()
        sys.exit(0)

    # ------------------------------------------------------------ input
    def read_controls(self, events):
        keys = pygame.key.get_pressed()
        move = Vector2(
            (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT]),
            (keys[pygame.K_s] or keys[pygame.K_DOWN]) - (keys[pygame.K_w] or keys[pygame.K_UP]),
        )
        c = Controls(move=move)
        stick = self.pads.stick()
        if stick.length() > 0:
            c.move = stick
        for e in events:
            if e.type == pygame.KEYDOWN and e.key in (pygame.K_SPACE, pygame.K_LSHIFT, pygame.K_RSHIFT, pygame.K_j):
                c.dash = True
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                c.dash, c.dash_target = True, Vector2(e.pos)
            elif e.type == pygame.KEYDOWN and e.key in (pygame.K_e, pygame.K_k):
                c.nova = True
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 3:
                c.nova = True
            elif _pad(e, "a", "rb", "rt"):
                c.dash = True
            elif _pad(e, "b", "lb", "lt"):
                c.nova = True
        return c

    def update_pad_feedback(self):
        """DualSense / DualShock light bar and triggers follow what's on screen."""
        if self.state == "play" and self.world and not self.world.over:
            p = self.world.player
            self.pads.light(p.ship.color)
            self.pads.triggers("play" if p.novas > 0 else "play_no_nova")
        else:
            self.pads.light(S.PINK)
            self.pads.triggers("off")

    def handle_global(self, e):
        if e.type == pygame.QUIT:
            self.quit()
        # Desktop: no sound while the window is in the background (the game pauses itself too).
        if e.type == pygame.WINDOWFOCUSLOST and self.audio.enabled:
            pygame.mixer.pause()
        elif e.type == pygame.WINDOWFOCUSGAINED and self.audio.enabled:
            pygame.mixer.unpause()
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_F11 or (e.key == pygame.K_RETURN and e.mod & pygame.KMOD_ALT):
                self.toggle_fullscreen()
                return True
            if e.key == pygame.K_m:
                self.settings["muted"] = not self.settings["muted"]
                self.audio.set_muted(self.settings["muted"])
                storage.save_settings(self.settings)
                return True
            if e.key == pygame.K_F3:
                self.show_fps = not self.show_fps
                return True
        return False

    def handle_menu(self, events):
        items = self.menu_items()
        for e in events:
            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_UP, pygame.K_w):
                    self.menu_index = (self.menu_index - 1) % len(items)
                    self.audio.play("select", 0.4)
                elif e.key in (pygame.K_DOWN, pygame.K_s):
                    self.menu_index = (self.menu_index + 1) % len(items)
                    self.audio.play("select", 0.4)
                elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self.activate(items[self.menu_index][0])
                elif e.key == pygame.K_ESCAPE:
                    self.quit()
            elif e.type == pygame.MOUSEMOTION:
                for i, rect in enumerate(self.menu_rects()):
                    if rect.collidepoint(e.pos):
                        self.menu_index = i
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for i, rect in enumerate(self.menu_rects()):
                    if rect.collidepoint(e.pos):
                        self.activate(items[i][0])
            elif _pad(e, "a", "start"):
                self.activate(items[self.menu_index][0])
            elif _pad(e, "up", "down"):
                self.menu_index = (self.menu_index + (1 if e.button == "down" else -1)) % len(items)
                self.audio.play("select", 0.4)

    def music_mood(self):
        """Which track fits the moment: menus, a run, or a boss fight (it cross-fades)."""
        if self.state in ("play", "paused") and self.world and not self.world.over:
            return "boss" if self.world.boss else "play"
        return "menu"

    # ------------------------------------------------------------ main loop
    def frame(self):
        # Browser: no cap, requestAnimationFrame already paces frames to the display.
        raw_dt = self.clock.tick(0 if web.IS_WEB else S.FPS) / 1000
        dt = min(raw_dt, S.MAX_DT)
        if raw_dt > 0.5 and self.state == "play" and self.world and not self.world.over:
            self.state = "paused"         # back from another tab (the browser froze the game)
        self.t += dt
        raw = [e for e in pygame.event.get() if not self.handle_global(e)]
        events = [self.to_arena(e) for e in self.pads.translate(raw)]
        if not self.input_seen and any(e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN) for e in raw):
            self.input_seen = True
            self.audio.start_music()      # the browser lets sound out from this click / key on
        self.update_pad_feedback()
        self.update(dt, events)
        self.audio.set_mood(self.music_mood())
        self.audio.update()
        cursor = "reticle" if self.state == "play" and self.world and not self.world.draft else "pointer"
        if cursor != self.cursor:
            render.set_cursor(cursor)
            self.cursor = cursor
        self.draw()
        pygame.display.flip()

    def run(self):
        while True:
            self.frame()

    async def run_async(self):
        """Browser main loop: yield to the page after every frame (it paces us with
        requestAnimationFrame, so the frame rate follows the monitor)."""
        while True:
            self.frame()
            await asyncio.sleep(0)

    def draft_rects(self):
        count = len(self.world.draft) if self.world and self.world.draft else 3
        w, h, gap = 320, 230, 36
        left = S.WIDTH / 2 - (count * w + (count - 1) * gap) / 2
        return [pygame.Rect(left + i * (w + gap), 250, w, h) for i in range(count)]

    def read_draft(self, events):
        """Keyboard / mouse / gamepad input on the upgrade cards. Returns a pick or None."""
        count = len(self.world.draft)
        self.draft_index = min(self.draft_index, count - 1)
        for e in events:
            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_1, pygame.K_2, pygame.K_3) and e.key - pygame.K_1 < count:
                    return e.key - pygame.K_1
                if e.key in (pygame.K_LEFT, pygame.K_a):
                    self.draft_index = (self.draft_index - 1) % count
                    self.audio.play("select", 0.4)
                elif e.key in (pygame.K_RIGHT, pygame.K_d):
                    self.draft_index = (self.draft_index + 1) % count
                    self.audio.play("select", 0.4)
                elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    return self.draft_index
            elif e.type == pygame.MOUSEMOTION:
                for i, rect in enumerate(self.draft_rects()):
                    if rect.collidepoint(e.pos):
                        self.draft_index = i
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for i, rect in enumerate(self.draft_rects()):
                    if rect.collidepoint(e.pos):
                        return i
            elif _pad(e, "left", "right"):
                self.draft_index = (self.draft_index + (1 if e.button == "right" else -1)) % count
                self.audio.play("select", 0.4)
            elif _pad(e, "a"):
                return self.draft_index
        return None

    # ------------------------------------------------------------ launch screen
    def _cycle(self, row, step):
        if row == 0:
            ids = [m.id for m in modes.MODES]
            current = self.settings.get("mode")
            i = ids.index(current) if current in ids else 0
            self.settings["mode"] = ids[(i + step) % len(ids)]
        elif self.settings.get("mode") != "daily":
            ids = [sh.id for sh in ships.SHIPS]
            current = self.settings.get("ship")
            i = ids.index(current) if current in ids else 0
            self.settings["ship"] = ids[(i + step) % len(ids)]
        self.audio.play("select", 0.4)
        storage.save_settings(self.settings)

    def launch_ready(self):
        if self.settings.get("mode") == "daily":
            return True
        return ships.is_unlocked(ships.get(self.settings.get("ship")), self.unlocked)

    def launch_rects(self):
        return {"mode": pygame.Rect(140, 110, 1000, 160), "ship": pygame.Rect(140, 290, 1000, 310),
                "start": pygame.Rect(S.WIDTH / 2 - 160, 625, 320, 56)}

    def handle_launch(self, events):
        rects = self.launch_rects()
        for e in events:
            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_UP, pygame.K_w, pygame.K_DOWN, pygame.K_s):
                    self.launch_row = 1 - self.launch_row
                    self.audio.play("select", 0.3)
                elif e.key in (pygame.K_LEFT, pygame.K_a):
                    self._cycle(self.launch_row, -1)
                elif e.key in (pygame.K_RIGHT, pygame.K_d, pygame.K_TAB):
                    self._cycle(self.launch_row, 1)
                elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self._try_launch()
                elif e.key == pygame.K_ESCAPE:
                    self.state = "menu"
                    self.audio.play("select")
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                if rects["start"].collidepoint(e.pos):
                    self._try_launch()
                for row, key in ((0, "mode"), (1, "ship")):
                    if rects[key].collidepoint(e.pos):
                        self.launch_row = row
                        self._cycle(row, 1 if e.pos[0] > S.WIDTH / 2 else -1)
            elif _pad(e, "up", "down"):
                self.launch_row = 1 - self.launch_row
                self.audio.play("select", 0.3)
            elif _pad(e, "left", "right", "lb", "rb"):
                self._cycle(self.launch_row, 1 if e.button in ("right", "rb") else -1)
            elif _pad(e, "a", "start"):
                self._try_launch()
            elif _pad(e, "b"):
                self.state = "menu"
                self.audio.play("select")

    def _try_launch(self):
        if self.launch_ready():
            self.start_game()
        else:
            self.audio.play("clang", 0.6)

    def update(self, dt, events):
        self.shake.update(dt)
        self.background.update(dt)
        for toast in self.toasts:
            toast[1] += dt
        self.toasts = [t for t in self.toasts if t[1] < 3.6]
        if self.state == "menu":
            self.handle_menu(events)
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
            self.demo.bg.update(dt)
            if self.demo.over or self.demo.wave > 7:
                self._new_demo()
        elif self.state == "launch":
            self.handle_launch(events)
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
        elif self.state in ("howto", "trophies"):
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
            if any(e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN) or _pad_press(e) for e in events):
                self.audio.play("select")
                self.state = "menu"
        elif self.state == "play":
            for e in events:
                if (e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_p)) or \
                        _pad(e, "start") or \
                        (e.type == pygame.WINDOWFOCUSLOST):
                    self.state = "paused"
                    return
            if self.world.draft:
                controls = Controls(pick=self.read_draft(events))
            else:
                self.draft_index = 1
                controls = self.read_controls(events)
            self.world.update(dt, controls)
            self.particles.update(dt)
            self.check_achievements()
            if self.world.over:
                self.over_timer += dt
                if self.over_timer > 2.2:
                    self.finish_game()
        elif self.state == "paused":
            for e in events:
                if e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_p, pygame.K_RETURN):
                    self.state = "play"
                elif e.type == pygame.KEYDOWN and e.key == pygame.K_q:
                    self.state = "menu"
                elif e.type == pygame.KEYDOWN and e.key == pygame.K_r:
                    self.start_game()
                elif _pad(e, "y"):
                    self.start_game()
                elif _pad(e, "back"):
                    self.state = "menu"
                elif e.type == pygame.MOUSEBUTTONDOWN or _pad(e, "a", "b", "start"):
                    self.state = "play"
        elif self.state == "gameover":
            self.particles.update(dt)
            for e in events:
                if (e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_r)) or \
                        _pad(e, "a", "y"):
                    self.start_game()
                elif (e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE) or \
                        _pad(e, "b"):
                    self.state = "menu"
                    self.audio.play("select")

    def finish_game(self):
        w = self.world
        self.check_achievements()
        rank = storage.add_score(w.score, w.wave, w.combo.best_chain,
                                 board=modes.score_key(w.mode), ship=w.player.ship.id)
        storage.add_lifetime(games=1, kills=w.stats["kills"], bosses=w.stats["bosses"],
                             waves=w.wave, dashes=w.stats["dashes"], seconds=w.t)
        self.result = {"score": w.score, "wave": w.wave, "chain": w.combo.best_chain,
                       "kills": w.stats["kills"], "best_dash": w.stats["best_dash_kills"], "rank": rank,
                       "unlocks": list(self.run_unlocks), "perks": dict(w.player.perks),
                       "mode": w.mode, "ship": w.player.ship}
        self.state = "gameover"

    # ------------------------------------------------------------ drawing
    def draw_world(self, world, background, shake=(0, 0)):
        """Background over the whole display, then the arena (with screen shake)."""
        x, y = round(self.offset[0] + shake[0]), round(self.offset[1] + shake[1])
        background.draw(self.display, self.t, origin=(x, y))
        background.draw(self.canvas, self.t, arena=True)
        world.draw(self.canvas)
        self.display.blit(self.canvas, (x, y))

    def draw(self):
        if self.state in ("menu", "howto", "trophies", "launch"):
            self.draw_world(self.demo, self.demo.bg)
            self.dim(150 if self.state == "menu" else 200)
            {"menu": self.draw_menu, "howto": self.draw_howto, "trophies": self.draw_trophies,
             "launch": self.draw_launch}[self.state]()
        else:
            self.draw_world(self.world, self.background, self.shake.offset(self.t))
            self.draw_danger()
            if self.state == "gameover":
                self.dim(170)
                self.draw_gameover()
            else:
                self.draw_hud()
                if self.world.draft and self.state == "play":
                    self.draw_draft()
                if self.state == "paused":
                    self.dim(160)
                    self.big_center("PAUSED", "{pause}: resume     {restart}: restart     {quit}: quit to menu")
        self.draw_toasts()
        if web.IS_WEB and not self.settings["muted"] and not web.sound_allowed(self.input_seen):
            pulse = 170 + int(85 * math.sin(self.t * 4))
            render.text(self.screen, self.fonts["small"], "CLICK OR PRESS A KEY TO TURN THE SOUND ON",
                        (S.WIDTH / 2, 18), (pulse, pulse, 255), anchor="midtop", glow_color=S.CYAN)
        if self.show_fps:
            render.text(self.screen, self.fonts["tiny"], f"{self.clock.get_fps():.0f} fps",
                        (S.WIDTH - 10, S.HEIGHT - 8), S.GREEN, anchor="bottomright")

    def dim(self, alpha):
        """Darken the whole display (sides included) behind a menu or overlay."""
        veil = self._veils.get(alpha)
        if veil is None:
            veil = pygame.Surface(self.display.get_size(), pygame.SRCALPHA)
            veil.fill((4, 3, 12, alpha))
            self._veils[alpha] = veil
        self.display.blit(veil, (0, 0))

    def title(self, pos, size="huge"):
        font = self.fonts[size]
        wobble = math.sin(self.t * 2) * 3
        # chromatic-aberration look: pink and cyan copies peeking out either side
        img = font.render(S.TITLE, True, S.WHITE)
        rect = img.get_rect(midleft=pos)
        render.glow(self.screen, (rect.centerx, rect.centery), rect.width * 0.55, S.PURPLE, 0.35)
        for dx, color in ((-4 - wobble, S.PINK), (4 + wobble, S.CYAN)):
            self.screen.blit(font.render(S.TITLE, True, color), rect.move(dx, 0))
        self.screen.blit(img, rect)
        if size == "huge":                       # the V2 badge
            badge = pygame.Rect(rect.right + 18, rect.top + 12, 74, 56)
            render.glow(self.screen, badge.center, 70, S.GOLD, 0.45)
            pygame.draw.rect(self.screen, S.GOLD, badge, 3, border_radius=10)
            render.text(self.screen, self.fonts["big"], "2", badge.center, S.GOLD, anchor="center")

    def draw_menu(self):
        self.title((110, 170))
        render.text(self.screen, self.fonts["small"], "your dash is your only weapon",
                    (118, 240), S.GOLD)
        for i, ((key, label), rect) in enumerate(zip(self.menu_items(), self.menu_rects())):
            selected = i == self.menu_index
            if selected:
                render.glow(self.screen, (rect.left + 10, rect.centery), 26, S.CYAN, 0.8)
                pts = render.ship_points((rect.left - 6, rect.centery), 9, 0)
                pygame.draw.polygon(self.screen, S.CYAN, pts)
            color = S.WHITE if selected else (150, 150, 185)
            render.text(self.screen, self.fonts["medium"], label, (rect.left + 15, rect.centery),
                        color, anchor="midleft")

        # high scores
        x, y = 800, 320
        mode_id = self.settings.get("mode", "classic")
        board = modes.score_key(mode_id)
        label = "TODAY'S DAILY RUN" if mode_id == "daily" else modes.BY_ID.get(mode_id, modes.MODES[0]).name
        render.text(self.screen, self.fonts["medium"], "HIGH SCORES", (x, y - 30), S.PINK)
        render.text(self.screen, self.fonts["tiny"], label, (x + 2, y + 6), (170, 170, 205))
        y += 10
        scores = storage.load_scores(board)
        if not scores:
            render.text(self.screen, self.fonts["small"], "none yet - be the first!", (x, y + 50), (150, 150, 185))
        for i, s in enumerate(scores):
            row = y + 50 + i * 36
            render.text(self.screen, self.fonts["small"], f"{i + 1}.", (x, row), S.GOLD)
            render.text(self.screen, self.fonts["small"], f"{s['score']:,}", (x + 40, row), S.WHITE)
            ship = ships.get(s.get("ship", "prism"))
            render.text(self.screen, self.fonts["tiny"], f"wave {s['wave']}  chain {s.get('chain', 0)}",
                        (x + 190, row + 3), (150, 150, 185))
            pygame.draw.polygon(self.screen, ship.color, render.ship_points((x + 350, row + 10), 7, 0))
        self.hint(f"v{__version__}   arrows/WASD + Enter   -   M mute   -   F11 fullscreen" if self.pads.device == "keyboard"
                  else f"v{__version__}     {{navigate}}  move     {{confirm}}  select",
                  (S.WIDTH / 2, S.HEIGHT - 38), "tiny", (120, 120, 160))
        render.text(self.screen, self.fonts["tiny"], f"PRISM DASH {__copyright__}",
                    (S.WIDTH / 2, S.HEIGHT - 16), (95, 95, 130), anchor="center")

    def draw_howto(self):
        render.text(self.screen, self.fonts["big"], "HOW TO PLAY", (S.WIDTH / 2, 70), S.WHITE,
                    anchor="center", glow_color=S.CYAN)
        lines = [
            ("MOVE", "WASD / arrow keys" if self.pads.device == "keyboard" else "{move}  left stick"),
            ("DASH", "Space or Shift (move direction), or LEFT CLICK (towards the cursor)"
                     if self.pads.device == "keyboard" else "{dash}  dashes the way the left stick points"),
            ("NOVA", "{nova}  destroys everything on screen (limited!)"),
            ("PAUSE", ("Esc / P" if self.pads.device == "keyboard" else "{pause}") + "     -     PLAY lets you pick a mode and a ship"),
        ]
        for i, (key, desc) in enumerate(lines):
            render.text(self.screen, self.fonts["medium"], key, (180, 140 + i * 40), S.GOLD)
            self.hint(desc, (330, 145 + i * 40), "small", S.WHITE, anchor="topleft")

        render.text(self.screen, self.fonts["small"],
                    "You have no gun. DASH THROUGH enemies to destroy them - you're invincible while dashing.",
                    (S.WIDTH / 2, 330), S.CYAN, anchor="center")
        render.text(self.screen, self.fonts["small"],
                    "Every kill during a dash RECHARGES it instantly. Chain kills to build your multiplier (up to x8).",
                    (S.WIDTH / 2, 362), S.CYAN, anchor="center")

        enemies = [
            (S.PINK, 3, "DRIFTER", "chases you"),
            (S.YELLOW, 4, "DART", "aims a laser, then charges"),
            (S.GREEN, 6, "SPLITTER", "breaks into three"),
            (S.CYAN, 4, "SPINNER", "fires rings of bullets"),
            (S.ORANGE, 5, "WARDEN", "shielded - hit it from behind"),
            (S.LIME, 8, "WEAVER", "lays mines - dash to defuse"),
            (S.PURPLE, 6, "BOSSES", "Core & Serpent, every 5 waves"),
            (S.GOLD, 5, "UPGRADES", "pick 1 of 3 after some waves"),
        ]
        for i, (color, sides, name, desc) in enumerate(enemies):
            col, row = i % 4, i // 4
            x, y = 110 + col * 290, 450 + row * 95
            pts = render.regular_polygon((x, y), 20, sides, self.t * 1.5)
            render.neon_polygon(self.screen, pts, color, glow_radius=50)
            render.text(self.screen, self.fonts["small"], name, (x + 40, y - 18), color)
            render.text(self.screen, self.fonts["tiny"], desc, (x + 40, y + 6), S.WHITE)
        render.text(self.screen, self.fonts["tiny"],
                    "Power-ups: red = +1 life   purple = +1 nova   gold = OVERDRIVE (dash with no cooldown)",
                    (S.WIDTH / 2, 655), S.GOLD, anchor="center")
        render.text(self.screen, self.fonts["tiny"], "press any key", (S.WIDTH / 2, 684),
                    (150, 150, 185), anchor="center")
        render.text(self.screen, self.fonts["tiny"],
                    f"PRISM DASH is an original game.   {__copyright__}",
                    (S.WIDTH / 2, 708), (95, 95, 130), anchor="center")

    def draw_hud(self):
        w, p, f = self.world, self.world.player, self.fonts
        render.text(self.screen, f["big"], f"{w.score:,}", (40, 30), S.WHITE)
        mult = w.combo.multiplier
        if w.combo.chain:
            color = S.GOLD if mult >= 4 else S.CYAN
            render.text(self.screen, f["medium"], f"x{mult}", (42, 84), color, glow_color=color)
            render.text(self.screen, f["tiny"], f"chain {w.combo.chain}", (100, 92), (170, 170, 200))
            bar = min(1.0, w.combo.timer / w.combo.window)
            pygame.draw.rect(self.screen, (40, 40, 70), (42, 118, 160, 5))
            pygame.draw.rect(self.screen, color, (42, 118, 160 * bar, 5))
        render.text(self.screen, f["medium"], f"WAVE {max(1, w.wave)}", (S.WIDTH - 40, 36),
                    S.WHITE, anchor="topright")
        if w.mode != "classic":
            tag = "DAILY RUN" if w.mode == "daily" else "BLITZ"
            render.text(self.screen, f["tiny"], tag, (S.WIDTH - 40, 66), S.GOLD, anchor="topright")
        if w.blitz:
            secs = max(0.0, w.time_left)
            urgent = secs < 20
            color = S.RED if urgent else S.WHITE
            clock = f"{int(secs) // 60}:{int(secs) % 60:02d}"
            pos = (S.WIDTH / 2, 92 if w.boss else 40)
            if urgent and int(self.t * 4) % 2:
                render.glow(self.screen, pos, 70, S.RED, 0.4)
            render.text(self.screen, f["big"], clock, pos, color, anchor="center")
        else:
            for i in range(p.lives):              # lives (Blitz has none: hits cost time)
                pts = render.ship_points((52 + i * 34, S.HEIGHT - 44), 10, -math.pi / 2)
                render.neon_polygon(self.screen, pts, p.ship.color, width=2, glow_radius=22)
        for i in range(p.novas):
            pos = (60 + i * 32, S.HEIGHT - 84)
            render.neon_circle(self.screen, pos, 9, S.PURPLE, width=2, glow_scale=2)
        if p.novas:
            self.hint("NOVA {nova1}" if self.pads.device != "keyboard" else "NOVA [E]",
                      (50 + p.novas * 32, S.HEIGHT - 92), "tiny", S.PURPLE, anchor="topleft")

        # dash meter
        width = 220
        x, y = S.WIDTH / 2 - width / 2, S.HEIGHT - 40
        ready = p.dash_ready
        color = S.GOLD if p.overdrive > 0 else (p.ship.color if ready else (90, 110, 150))
        slots, gap = p.max_charges, 8
        slot_w = (width - gap * (slots - 1)) / slots
        for i in range(slots):                    # one bar per dash charge
            if i < p.charges:
                fill = 1.0
            elif i == p.charges and p.dash_cd > 0:
                fill = 1 - p.dash_cd / p.cooldown_total
            else:
                fill = 0.0
            sx = x + i * (slot_w + gap)
            pygame.draw.rect(self.screen, (30, 30, 55), (sx, y, slot_w, 8), border_radius=4)
            pygame.draw.rect(self.screen, color if i < p.charges else (90, 110, 150),
                             (sx, y, slot_w * max(0.0, fill), 8), border_radius=4)
        if ready:
            render.glow(self.screen, (S.WIDTH / 2, y + 4), 60, color, 0.35)
        label = f"OVERDRIVE {p.overdrive:.1f}s" if p.overdrive > 0 else "DASH"
        render.text(self.screen, f["tiny"], label, (S.WIDTH / 2, y - 12), color, anchor="center")

        if p.barrier:
            render.text(self.screen, f["tiny"], "BARRIER", (52, S.HEIGHT - 22), S.WHITE)
        self.draw_perk_icons()

        boss = w.boss
        if boss:
            bw = 500
            bx = S.WIDTH / 2 - bw / 2
            bar_color = S.PINK if boss.enraged else boss.color
            render.text(self.screen, f["small"], boss.title, (S.WIDTH / 2, 26), bar_color, anchor="center")
            pygame.draw.rect(self.screen, (40, 25, 50), (bx, 44, bw, 10), border_radius=5)
            pygame.draw.rect(self.screen, bar_color, (bx, 44, bw * max(0, boss.hp) / boss.max_hp, 10),
                             border_radius=5)

        if w.banner and not w.draft:
            text, sub, left, color = w.banner
            alpha = min(1.0, left * 2.5)
            c = tuple(int(v * alpha) for v in color)
            render.text(self.screen, f["big"], text, (S.WIDTH / 2, S.HEIGHT / 2 - 150), c,
                        anchor="center", glow_color=c)
            if sub:
                render.text(self.screen, f["small"], sub, (S.WIDTH / 2, S.HEIGHT / 2 - 100),
                            tuple(int(v * alpha) for v in S.WHITE), anchor="center")

    def draw_danger(self):
        """Red flash when hit, and a pulsing red edge when on your last life."""
        w = self.world
        if w.flash > 0:
            veil = pygame.Surface((S.WIDTH, S.HEIGHT), pygame.SRCALPHA)
            veil.fill((255, 40, 60, int(45 * w.flash / 0.35)))
            self.screen.blit(veil, (0, 0))
        if w.player.lives == 1 and not w.over:
            k = 0.5 + 0.5 * math.sin(self.t * 5)
            edge = pygame.Surface((S.WIDTH, S.HEIGHT), pygame.SRCALPHA)
            for i in range(14):
                alpha = int((14 - i) * 7 * k)
                pygame.draw.rect(edge, (255, 30, 60, alpha), (i * 3, i * 3, S.WIDTH - i * 6, S.HEIGHT - i * 6), 3)
            self.screen.blit(edge, (0, 0))

    def draw_perk_icons(self):
        owned = self.world.player.perks
        x = S.WIDTH - 40
        for pid, level in reversed(list(owned.items())):
            perk = perks.PERKS[pid]
            label = perk.name.split()[0] + (f" {level}" if perk.max_level > 1 else "")
            img = self.fonts["tiny"].render(label, True, perk.color)
            rect = img.get_rect(bottomright=(x, S.HEIGHT - 36))
            pygame.draw.rect(self.screen, (20, 18, 40), rect.inflate(14, 8), border_radius=6)
            pygame.draw.rect(self.screen, perk.color, rect.inflate(14, 8), 1, border_radius=6)
            self.screen.blit(img, rect)
            x = rect.left - 22

    def draw_draft(self):
        self.dim(175)
        w = self.world
        render.text(self.screen, self.fonts["big"], "CHOOSE AN UPGRADE", (S.WIDTH / 2, 170), S.WHITE,
                    anchor="center", glow_color=S.GOLD)
        self.hint("{pick}  or click" if self.pads.device == "keyboard" else "{pick}  pick",
                  (S.WIDTH / 2, 215), "small", (170, 170, 205))
        for i, (pid, rect) in enumerate(zip(w.draft, self.draft_rects())):
            perk = perks.PERKS[pid]
            level = w.player.perk(pid) + 1
            selected = i == self.draft_index
            card = rect.move(0, -8 if selected else 0)
            if selected:
                render.glow(self.screen, card.center, card.width * 0.7, perk.color, 0.35)
            pygame.draw.rect(self.screen, (16, 14, 34), card, border_radius=14)
            pygame.draw.rect(self.screen, perk.color if selected else tuple(c // 2 for c in perk.color),
                             card, 3 if selected else 2, border_radius=14)
            render.text(self.screen, self.fonts["tiny"], f"[{i + 1}]", (card.left + 16, card.top + 14), (150, 150, 190))
            render.text(self.screen, self.fonts["medium"], perk.name, (card.centerx, card.top + 58),
                        perk.color, anchor="center")
            if perk.max_level > 1:          # level pips: filled up to the level you'd reach
                for n in range(perk.max_level):
                    cx = card.centerx + (n - (perk.max_level - 1) / 2) * 22
                    pygame.draw.circle(self.screen, perk.color, (cx, card.top + 92), 6, 0 if n < level else 2)
            else:
                render.text(self.screen, self.fonts["tiny"], "UNIQUE", (card.centerx, card.top + 92),
                            perk.color, anchor="center")
            self._wrapped(perks.describe(pid, level), card.centerx, card.top + 125, card.width - 40)

    def _wrapped(self, message, cx, top, width, font="small", color=S.WHITE):
        words, line, y = message.split(), "", top
        for word in words:
            trial = f"{line} {word}".strip()
            if self.fonts[font].size(trial)[0] > width and line:
                render.text(self.screen, self.fonts[font], line, (cx, y), color, anchor="midtop")
                line, y = word, y + self.fonts[font].get_linesize()
            else:
                line = trial
        if line:
            render.text(self.screen, self.fonts[font], line, (cx, y), color, anchor="midtop")

    def draw_toasts(self):
        for i, (aid, age) in enumerate(self.toasts[:3]):
            name, desc = ACHIEVEMENTS[aid]
            slide = max(0.0, min(1.0, age * 5, (3.6 - age) * 4))
            x = S.WIDTH + 10 - 390 * slide
            rect = pygame.Rect(x, S.HEIGHT - 160 - i * 84, 360, 70)
            pygame.draw.rect(self.screen, (22, 18, 42), rect, border_radius=12)
            pygame.draw.rect(self.screen, S.GOLD, rect, 2, border_radius=12)
            render.glow(self.screen, (rect.left + 36, rect.centery), 34, S.GOLD, 0.5)
            pygame.draw.polygon(self.screen, S.GOLD, render.regular_polygon((rect.left + 36, rect.centery), 14, 5, -math.pi / 2))
            render.text(self.screen, self.fonts["tiny"], "ACHIEVEMENT UNLOCKED", (rect.left + 66, rect.top + 10), S.GOLD)
            render.text(self.screen, self.fonts["small"], name, (rect.left + 66, rect.top + 28), S.WHITE)
            render.text(self.screen, self.fonts["tiny"], desc, (rect.left + 66, rect.top + 50), (170, 170, 205))

    def draw_trophies(self):
        render.text(self.screen, self.fonts["big"], "ACHIEVEMENTS", (S.WIDTH / 2, 60), S.WHITE,
                    anchor="center", glow_color=S.GOLD)
        render.text(self.screen, self.fonts["small"], f"{len(self.unlocked)} / {len(ACHIEVEMENTS)} unlocked",
                    (S.WIDTH / 2, 105), S.GOLD, anchor="center")
        for i, (aid, (name, desc)) in enumerate(ACHIEVEMENTS.items()):
            col, row = i % 3, i // 3
            x, y = 90 + col * 380, 140 + row * 92
            got = aid in self.unlocked
            color = S.GOLD if got else (80, 80, 110)
            rect = pygame.Rect(x, y, 360, 78)
            pygame.draw.rect(self.screen, (20, 17, 38) if got else (12, 11, 24), rect, border_radius=12)
            pygame.draw.rect(self.screen, color, rect, 2, border_radius=12)
            star = render.regular_polygon((x + 34, y + 39), 14, 5, -math.pi / 2)
            if got:
                render.glow(self.screen, (x + 34, y + 39), 32, S.GOLD, 0.45)
            pygame.draw.polygon(self.screen, color, star, 0 if got else 2)
            render.text(self.screen, self.fonts["small"], name, (x + 62, y + 14), S.WHITE if got else (130, 130, 160))
            render.text(self.screen, self.fonts["tiny"], desc, (x + 62, y + 42), (170, 170, 205) if got else (100, 100, 130))
            if got:
                render.text(self.screen, self.fonts["tiny"], self.unlocked[aid], (x + 62, y + 58), (120, 120, 160))
        life = storage.load_lifetime()
        hours, rest = divmod(life["seconds"], 3600)
        summary = (f"games {life['games']}     kills {life['kills']:,}     cores {life['bosses']}     "
                   f"dashes {life['dashes']:,}     time played {hours}h {rest // 60:02d}m")
        render.text(self.screen, self.fonts["small"], summary, (S.WIDTH / 2, 640), (180, 180, 210), anchor="center")
        render.text(self.screen, self.fonts["tiny"], "press any key", (S.WIDTH / 2, 690), (150, 150, 185), anchor="center")

    def draw_launch(self):
        f = self.fonts
        rects = self.launch_rects()
        mode_id = self.settings.get("mode", "classic")
        mode = modes.BY_ID.get(mode_id, modes.MODES[0])
        daily = mode_id == "daily"
        ship = modes.daily_ship() if daily else ships.get(self.settings.get("ship"))
        unlocked = daily or ships.is_unlocked(ship, self.unlocked)

        render.text(self.screen, f["big"], "LAUNCH", (S.WIDTH / 2, 62), S.WHITE, anchor="center", glow_color=S.CYAN)

        def panel(rect, row, title):
            selected = self.launch_row == row
            pygame.draw.rect(self.screen, (14, 12, 30), rect, border_radius=16)
            pygame.draw.rect(self.screen, S.CYAN if selected else (60, 60, 95), rect, 2, border_radius=16)
            render.text(self.screen, f["tiny"], title, (rect.left + 20, rect.top + 14),
                        S.CYAN if selected else (130, 130, 170))
            for side, x in ((-1, rect.left + 36), (1, rect.right - 36)):
                pts = render.ship_points((x, rect.centery), 12, 0 if side > 0 else math.pi)
                pygame.draw.polygon(self.screen, S.CYAN if selected else (70, 70, 110), pts)

        # ---- mode ----
        r = rects["mode"]
        panel(r, 0, "MODE   (left / right)")
        render.text(self.screen, f["big"], mode.name, (r.centerx, r.top + 58), S.GOLD, anchor="center")
        render.text(self.screen, f["small"], mode.description, (r.centerx, r.top + 100), S.WHITE, anchor="center")
        best = storage.load_scores(modes.score_key(mode_id))
        best_text = f"best: {best[0]['score']:,}" if best else "no score yet"
        if daily:
            best_text = f"today ({modes.score_key('daily')[6:]})  -  " + best_text
        render.text(self.screen, f["tiny"], best_text, (r.centerx, r.top + 132), (170, 170, 205), anchor="center")

        # ---- ship ----
        r = rects["ship"]
        panel(r, 1, "TODAY'S SHIP (fixed for the Daily Run)" if daily else "SHIP   (up / down to switch row)")
        center = (r.left + 250, r.centery + 10)
        color = ship.color if unlocked else (70, 70, 100)
        render.glow(self.screen, center, 120, color, 0.5 if unlocked else 0.15)
        pts = render.ship_points(center, 46, self.t * 0.8)
        render.neon_polygon(self.screen, pts, color, width=4)
        if ship.charges > 1 and unlocked:
            render.text(self.screen, f["tiny"], f"x{ship.charges} DASH", (center[0], center[1] + 80), color, anchor="center")
        tx = r.left + 450
        render.text(self.screen, f["big"], ship.name, (tx, r.top + 40), color)
        if unlocked:
            render.text(self.screen, f["small"], ship.trait, (tx, r.top + 100), S.WHITE)
        else:
            from prism_dash.achievements import ACHIEVEMENTS as ACH
            name, desc = ACH[ship.unlock]
            render.text(self.screen, f["small"], f"LOCKED - earn '{name}': {desc}", (tx, r.top + 100), S.RED)
        for i, (label, value) in enumerate(ships.stat_bars(ship).items()):
            y = r.top + 150 + i * 32
            render.text(self.screen, f["tiny"], label, (tx, y), (170, 170, 205))
            pygame.draw.rect(self.screen, (35, 35, 60), (tx + 140, y + 4, 300, 10), border_radius=5)
            pygame.draw.rect(self.screen, color, (tx + 140, y + 4, 300 * value, 10), border_radius=5)
        if not daily:
            owned = sum(ships.is_unlocked(sh, self.unlocked) for sh in ships.SHIPS)
            render.text(self.screen, f["tiny"], f"{owned} / {len(ships.SHIPS)} ships unlocked",
                        (r.right - 24, r.bottom - 26), (150, 150, 185), anchor="topright")

        # ---- start ----
        r = rects["start"]
        ok = self.launch_ready()
        pygame.draw.rect(self.screen, (20, 40, 50) if ok else (40, 25, 35), r, border_radius=14)
        pygame.draw.rect(self.screen, S.CYAN if ok else S.RED, r, 3, border_radius=14)
        if ok:
            render.glow(self.screen, r.center, 140, S.CYAN, 0.25 + 0.1 * math.sin(self.t * 4))
        if ok:
            self.hint("START  [{confirm}]" if self.pads.device == "keyboard" else "START  {confirm}", r.center, "medium", S.WHITE)
        else:
            render.text(self.screen, f["medium"], "SHIP LOCKED", r.center, S.RED, anchor="center")
        self.hint("{back}: back", (S.WIDTH / 2, 700), "tiny", (130, 130, 165))

    def hint(self, markup, pos, font="small", color=(180, 180, 210), anchor="center"):
        """A line of text whose {action} markers show the keys, or the pad's button icons."""
        return render.rich_text(self.screen, self.fonts[font], hint_parts(markup, self.pads.device), pos, color,
                                anchor, playstation=self.pads.device == "playstation")

    def big_center(self, title, subtitle):
        render.text(self.screen, self.fonts["big"], title, (S.WIDTH / 2, S.HEIGHT / 2 - 30),
                    S.WHITE, anchor="center", glow_color=S.CYAN)
        self.hint(subtitle, (S.WIDTH / 2, S.HEIGHT / 2 + 30))

    def draw_gameover(self):
        r, f = self.result, self.fonts
        headline = "TIME UP" if r["mode"] == "blitz" else "GAME OVER"
        render.text(self.screen, f["huge"], headline, (S.WIDTH / 2, 140), S.PINK,
                    anchor="center", glow_color=S.PINK)
        mode_name = "DAILY RUN " + modes.score_key("daily")[6:] if r["mode"] == "daily" \
            else modes.BY_ID[r["mode"]].name
        render.text(self.screen, f["small"], f"{mode_name}   -   {r['ship'].name}", (S.WIDTH / 2, 215),
                    r["ship"].color, anchor="center")
        render.text(self.screen, f["big"], f"{r['score']:,}", (S.WIDTH / 2, 270), S.WHITE, anchor="center")
        if r["rank"] == 1:
            msg, color = "NEW HIGH SCORE!", S.GOLD
        elif r["rank"]:
            msg, color = f"#{r['rank']} on the high score table", S.CYAN
        else:
            msg, color = "", S.WHITE
        if msg and int(self.t * 3) % 2 == 0:
            render.text(self.screen, f["medium"], msg, (S.WIDTH / 2, 330), color, anchor="center", glow_color=color)
        stats = [("WAVE", r["wave"]), ("KILLS", r["kills"]), ("BEST CHAIN", r["chain"]),
                 ("MOST IN ONE DASH", r["best_dash"])]
        for i, (label, value) in enumerate(stats):
            x = S.WIDTH / 2 + (i - 1.5) * 230
            render.text(self.screen, f["tiny"], label, (x, 400), (160, 160, 200), anchor="center")
            render.text(self.screen, f["big"], str(value), (x, 445), S.WHITE, anchor="center")
        if r["perks"]:
            build = "   ".join(perks.PERKS[pid].name + (f" {lv}" if lv > 1 else "") for pid, lv in r["perks"].items())
            render.text(self.screen, f["tiny"], "BUILD:  " + build, (S.WIDTH / 2, 515), (170, 170, 205), anchor="center")
        if r["unlocks"]:
            names = ", ".join(ACHIEVEMENTS[a][0] for a in r["unlocks"])
            render.text(self.screen, f["small"], f"Unlocked: {names}", (S.WIDTH / 2, 550), S.GOLD, anchor="center")
        self.hint("{confirm}: play again      {back}: menu", (S.WIDTH / 2, 610), "small", (190, 190, 220))


def main():
    App().run()


async def main_async():
    await App().run_async()
