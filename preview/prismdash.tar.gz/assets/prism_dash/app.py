"""Window, menus, HUD and the main loop."""

import asyncio
import math
import os
import sys
import time
import warnings

if sys.platform == "win32":
    # Draw at the screen's real pixels: without this, Windows stretches the window on
    # 125% / 150% displays and blurs everything. (Must be set before pygame starts.)
    os.environ.setdefault("SDL_WINDOWS_DPI_AWARENESS", "permonitorv2")

import pygame
from pygame import Vector2

import random

from prism_dash import __copyright__, __version__, benchmark, credits, difficulty, gpu, hires, modes, perks, render, sectors, ships, storage, web
from prism_dash import settings as S
from prism_dash.achievements import ACHIEVEMENTS, newly_unlocked
from prism_dash.audio import Audio
from prism_dash.gamepad import PADBUTTON, Pads, hint_parts
from prism_dash.autopilot import Autopilot
from prism_dash.icon import make_icon
from prism_dash.options import OptionsMenu, apply_settings
from prism_dash.particles import Particles
from prism_dash.world import Controls, World


def _pad(e, *names):
    """A controller button press (any pad, any layout) among names."""
    return e.type == PADBUTTON and e.button in names


def _pad_press(e):
    """A real button press on a pad (not the stick nudging a menu)."""
    return e.type == PADBUTTON and not getattr(e, "stick", False)


class FeelingAudio:
    """The game's audio, plus controller rumble for the same moments."""

    def __init__(self, audio, pads):
        self._audio, self._pads = audio, pads

    def play(self, name, *args, **kwargs):
        self._audio.play(name, *args, **kwargs)
        self._pads.feel(name)

    def kill(self, chain):
        self._audio.kill(chain)
        self._pads.feel("kill")

    def __getattr__(self, name):
        return getattr(self._audio, name)


class SilentAudio:
    """Stands in for Audio in the menu's demo game."""
    def play(self, *_a, **_k): pass
    def kill(self, *_a, **_k): pass


class App:
    def __init__(self):
        pygame.init()
        self.settings = storage.load_settings()
        pygame.display.set_caption(S.TITLE)
        if not web.IS_WEB:                # the page has its own favicon
            pygame.display.set_icon(make_icon(64))
        self.gpu = None                    # the ULTRA renderer, when the graphics card runs the show
        self.gpu_mode = False
        self.frame_dim = 0.0
        self._create_display()
        self.clock = pygame.time.Clock()
        self.fonts = {}
        self._make_surfaces()
        self.input_seen = False           # browser: sound is allowed after the first click / key
        self.pads = Pads()
        self.cursor = None                 # which neon cursor is showing
        self.bloom = render.Bloom()
        self.bloom_ok = True               # a slow computer drops the bloom by itself
        self.slow_time = 0.0
        self.audio = FeelingAudio(Audio(muted=self.settings["muted"]), self.pads)
        self.shake = render.Shake()
        self.shake.enabled = self.settings["shake"]
        self.options = OptionsMenu(self)
        self.howto_back = "menu"           # HOW TO PLAY returns here (OPTIONS opens it too)
        apply_settings(self)
        self.background = render.Background(self.settings.get("effects", "high"))
        self._gpu_background(self.background)

        self.state = "menu"
        self.menu_index = 0
        self.world = None
        self.over_timer = 0.0
        self.result = None
        self.draft_index = 0
        self.unlocked = storage.load_achievements()
        self.run_unlocks = []
        self.toasts = []                  # [achievement id, time shown]
        self.show_fps = self.settings.get("show_fps", False)
        self.t = 0.0
        self._new_demo()
        self.bench = None                 # the BENCHMARK fight, while it runs
        self.bench_result = None
        self.notice = None                # [message, seconds shown]: one line under the menu
        self.first_check = None
        if self.gpu is not None and not self.settings.get("speed_checked"):
            self.first_check = benchmark.FirstLaunchCheck(self.refresh_rate())

    # ------------------------------------------------------------ setup
    def _new_demo(self):
        self.demo = World(SilentAudio(), Particles(self.fonts), render.Shake(),
                          render.Background(self.settings.get("effects", "high")), seed=None,
                          ship=random.choice(ships.SHIPS))
        self.demo.player.lives = 99
        self._gpu_background(self.demo.bg)
        self.demo_pilot = Autopilot(skill=1.0)

    def run_setup(self):
        """(mode, seed, ship) for the next run, from the launch screen's choices."""
        mode = self.settings.get("mode", "classic")
        if mode == "daily":
            return mode, modes.daily_seed(), modes.daily_ship()
        ship = ships.get(self.settings.get("ship"))
        if not ships.is_unlocked(ship, self.unlocked):
            ship = ships.SHIPS[0]
        return mode, None, ship

    def start_game(self):
        self.audio.play("select")
        self.particles = Particles(self.fonts)
        mode, seed, ship = self.run_setup()
        rules = difficulty.Rules() if mode == "daily" else difficulty.Rules.from_settings(self.settings)
        self.world = World(self.audio, self.particles, self.shake, self.background,
                           seed=seed, mode=mode, ship=ship, rules=rules)
        if rules.level == "ngplus":
            self.world.grant_perks(self.settings.get("last_gear", {}))
        self.state = "play"
        self.over_timer = 0.0
        self.result = None
        self.run_unlocks = []

    def check_achievements(self):
        new = newly_unlocked(self.world.run_stats(), self.unlocked)
        if new:
            self.unlocked = storage.unlock_achievements(new)
            self.run_unlocks += new
            for aid in new:
                self.toasts.append([aid, 0.0])
            self.audio.play("achievement")

    # ------------------------------------------------------------ menu
    def menu_items(self):
        on_off = lambda flag: "ON" if flag else "OFF"   # noqa: E731
        return [
            ("play", "PLAY"),
            ("howto", "HOW TO PLAY"),
            ("trophies", f"ACHIEVEMENTS  {len(self.unlocked)}/{len(ACHIEVEMENTS)}"),
            ("options", "OPTIONS"),
            ("sound", f"SOUND: {on_off(not self.settings['muted'])}"),
        ] + ([] if web.IS_WEB else [("quit", "QUIT")])

    def menu_rects(self):
        rects = []
        items = self.menu_items()
        step = min(50, 360 // max(1, len(items) - 1))     # more items: closer rows, never past the footer
        for i, (_, label) in enumerate(items):
            img = self.fonts["medium"].render(label, True, S.WHITE)
            rects.append(img.get_rect(midleft=(120, 310 + i * step)).inflate(30, 14))
        return rects

    def activate(self, key):
        self.audio.play("select")
        if key == "play":
            self.state = "launch"
            self.launch_row = 0
        elif key == "howto":
            self.state = "howto"
            self.howto_back = "menu"
        elif key == "options":
            self.options.open()
            self.state = "options"
        elif key == "trophies":
            self.state = "trophies"
        elif key == "sound":
            self.settings["muted"] = not self.settings["muted"]
            self.audio.set_muted(self.settings["muted"])
        elif key == "shake":
            self.settings["shake"] = not self.settings["shake"]
            self.shake.enabled = self.settings["shake"]
        elif key == "graphics":
            self.settings["graphics"] = "standard" if self.settings.get("graphics", "ultra") == "ultra" else "ultra"
        elif key == "resolution":
            native = self.settings.get("resolution", "native") == "native"
            self.settings["resolution"] = "fast" if native else "native"
            self.rebuild_gpu_display()
        elif key == "effects":
            self.settings["effects"] = "low" if self.settings.get("effects", "high") != "low" else "high"
            self.background.effects = self.settings["effects"]
            self.demo.bg.effects = self.settings["effects"]
        elif key == "fullscreen":
            self.toggle_fullscreen()
        elif key == "display":
            modes = list(self.DISPLAY_MODES)
            self.set_display(modes[(modes.index(self.display_mode) + 1) % len(modes)])
        elif key == "benchmark":
            self.start_benchmark()
        elif key == "quit":
            self.quit()
        storage.save_settings(self.settings)

    # ------------------------------------------------------------ benchmark
    @staticmethod
    def refresh_rate():
        """The monitor's refresh rate (what vsync paces frames to); 60 when unknown."""
        try:
            rate = pygame.display.get_current_refresh_rate()
        except (AttributeError, pygame.error):
            rate = 0
        return rate if 30 <= rate <= 500 else 60

    def start_benchmark(self):
        world = World(SilentAudio(), Particles(self.fonts), render.Shake(),
                      render.Background(self.settings.get("effects", "high")), seed=2026,
                      ship=ships.SHIPS[0])
        self._gpu_background(world.bg)
        self.bench = benchmark.Benchmark(world, Autopilot(skill=1.0), self.refresh_rate())
        self.bench_result = None
        self.state = "benchmark"

    def finish_benchmark(self):
        self.bench_result = self.bench.result()
        self.state = "bench_result"

    def switch_to_standard(self, message):
        """ULTRA off now (the classic renderer takes over in the same session)."""
        self._drop_gpu()
        self.settings["graphics"] = "standard"
        self._create_display()
        self._make_surfaces()
        for bg in (self.background, self.demo.bg, self.bench.world.bg if self.bench else None):
            if bg is not None:
                bg.sky, bg.on_kick = True, None
        self._veils = {}
        storage.save_settings(self.settings)
        self.notice = [message, 0.0]

    def _first_check(self, dt, gpu_ms):
        if self.first_check is None or self.state != "menu" or self.gpu is None:
            return
        fast_enough = self.first_check.record(dt, gpu_ms)
        if fast_enough is None:
            return
        self.first_check = None
        self.settings["speed_checked"] = True
        storage.save_settings(self.settings)
        if not fast_enough and hires.active():      # first step down: same look, logical resolution
            self.settings["resolution"] = "fast"
            self.rebuild_gpu_display()
            self.notice = ["Native resolution was too heavy for this PC: now RESOLUTION FAST.", 0.0]
        elif not fast_enough:
            self.switch_to_standard("ULTRA was too heavy for this PC: now STANDARD graphics. BENCHMARK tells more.")

    def draw_benchmark(self):
        b = self.bench
        bar = pygame.Rect(S.WIDTH / 2 - 200, 26, 400, 10)
        pygame.draw.rect(self.screen, (40, 36, 70), bar, border_radius=5)
        pygame.draw.rect(self.screen, S.CYAN, (bar.left, bar.top, round(bar.width * b.progress), bar.height), border_radius=5)
        render.text(self.screen, self.fonts["small"], "BENCHMARK", (S.WIDTH / 2, 46), S.WHITE, anchor="midtop", glow_color=S.CYAN)
        self.hint("{back}: stop", (S.WIDTH / 2, S.HEIGHT - 30), "tiny", (150, 150, 190))

    def draw_bench_result(self):
        r = self.bench_result
        panel = pygame.Rect(0, 0, 680, 390)
        panel.center = (S.WIDTH / 2, S.HEIGHT / 2)
        pygame.draw.rect(self.screen, (18, 14, 36), panel, border_radius=16)
        pygame.draw.rect(self.screen, S.CYAN, panel, 2, border_radius=16)
        render.text(self.screen, self.fonts["big"], "BENCHMARK", (panel.centerx, panel.top + 24), S.WHITE,
                    anchor="midtop", glow_color=S.CYAN)
        renderer = "ULTRA" if self.gpu is not None else "STANDARD"
        effects = "FULL" if self.settings.get("effects", "high") != "low" else "LIGHT"
        w, h = pygame.display.get_window_size()
        if self.display_mode == "borderless":
            w, h = pygame.display.get_desktop_sizes()[0]      # not the hidden extra pixel row
        render.text(self.screen, self.fonts["tiny"],
                    f"GRAPHICS {renderer}   EFFECTS {effects}   {w}x{h}   monitor {self.refresh_rate()} Hz",
                    (panel.centerx, panel.top + 98), (170, 170, 205), anchor="midtop")
        if r is None:
            self._wrapped("Stopped before it could measure anything.", panel.centerx, panel.top + 170, 560)
        else:
            colour = {"smooth": S.GREEN, "ok": S.GOLD, "slow": S.PINK}[r["verdict"]]
            words = {"smooth": "SMOOTH", "ok": "PLAYABLE", "slow": "TOO SLOW"}[r["verdict"]]
            cells = ((f"{r['fps']:.0f}", "average fps"), (f"{r['low_fps']:.0f}", "slowest 1% fps"),
                     (f"{r['avg_ms']:.1f}", "ms per frame"))
            for i, (value, label) in enumerate(cells):
                x = panel.left + 120 + i * 220
                render.text(self.screen, self.fonts["big"], value, (x, panel.top + 136), S.WHITE, anchor="midtop")
                render.text(self.screen, self.fonts["tiny"], label, (x, panel.top + 192), (150, 150, 185), anchor="midtop")
            render.text(self.screen, self.fonts["medium"], words, (panel.centerx, panel.top + 232), colour,
                        anchor="midtop", glow_color=colour)
            tip = benchmark.advice(r, self.gpu is not None, gpu.available(), effects == "FULL", hires.active())
            self._wrapped(tip, panel.centerx, panel.top + 280, 600)
        self.hint("{confirm}: back to the menu", (panel.centerx, panel.bottom - 26), "tiny", (150, 150, 190))

    def draw_notice(self):
        if self.notice is None:
            return
        message, age = self.notice
        if age > 8.0:
            self.notice = None
            return
        render.text(self.screen, self.fonts["small"], message, (S.WIDTH / 2, S.HEIGHT - 70), S.GOLD,
                    anchor="center", glow_color=S.PINK)

    # ------------------------------------------------------------ display
    @staticmethod
    def display_size():
        """A logical resolution with the monitor's shape. The 1280x720 arena sits
        in the middle; wider screens (21:9, 32:9) get extra background at the
        sides, taller ones (16:10, 4:3) at the top and bottom. The playfield
        itself never changes size, so every screen plays exactly the same.
        In a browser the canvas is fixed at 16:9 and the page scales it."""
        if web.IS_WEB:
            return S.WIDTH, S.HEIGHT
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0]
        except (pygame.error, IndexError):
            return S.WIDTH, S.HEIGHT
        aspect = dw / dh
        if aspect >= S.WIDTH / S.HEIGHT:
            return round(S.HEIGHT * aspect), S.HEIGHT
        return S.WIDTH, round(S.WIDTH / aspect)

    def _create_display(self):
        # The size is chosen once: pygame-ce crashes if a SCALED display changes
        # size later, so fullscreen is toggled without recreating it.
        if web.IS_WEB:
            # The browser page scales the canvas; desktop window flags don't apply.
            pygame.display.set_mode((S.WIDTH, S.HEIGHT))
            self._bind_surfaces()
            return
        if self.settings.get("graphics", "ultra") == "ultra" and gpu.available():
            try:
                self._create_gpu_display()
                return
            except Exception as error:     # noqa: BLE001 - any GL trouble: the classic renderer
                print(f"ULTRA graphics unavailable ({error}); using the classic renderer")
                self._drop_gpu()
        flags = pygame.SCALED | pygame.RESIZABLE
        if self.display_mode != "windowed":
            flags |= pygame.FULLSCREEN
        size = self.display_size()
        try:
            pygame.display.set_mode(size, flags, vsync=1)
        except pygame.error:
            pygame.display.set_mode(size, flags)
        self._bind_surfaces()
        window = self._window()
        if window is not None:
            # never let the window be dragged/resized into something unplayable
            window.minimum_size = (size[0] // 2, size[1] // 2)
            if self.display_mode == "windowed":
                self.restore_window()

    # ------------------------------------------------------------ ULTRA display
    def _create_gpu_display(self):
        """An OpenGL window at the screen's real resolution. The game draws into an ordinary
        surface of the logical size; gpu.Renderer turns it into the final picture."""
        logical = self.display_size()
        self.gpu_mode = True
        if self.settings.get("resolution", "native") == "native":
            hires.enable(hires.scale_for(logical, pygame.display.get_desktop_sizes()[0]))
        self.display = hires.surface(logical, 0, 32)
        self._bind_surfaces()
        self._open_gpu_window()

    def _open_gpu_window(self):
        if self.gpu is not None:
            self.gpu.release()
            self.gpu = None
        mode = self.display_mode
        if mode == "borderless":            # fullscreen windowed: fills the screen, instant alt-tab
            # One pixel taller than the screen (hidden below it): Windows then keeps it an
            # ordinary window instead of switching the monitor into a fullscreen mode, which
            # blanks the screen for seconds on launch, exit and alt-tab on some setups.
            dw, dh = pygame.display.get_desktop_sizes()[0]
            size = (dw, dh + 1)
            flags = pygame.OPENGL | pygame.DOUBLEBUF | pygame.NOFRAME
        elif mode == "fullscreen":          # exclusive fullscreen at the desktop resolution
            size = pygame.display.get_desktop_sizes()[0]
            flags = pygame.OPENGL | pygame.DOUBLEBUF | pygame.FULLSCREEN
        else:
            size = self.normal_window_size()
            flags = pygame.OPENGL | pygame.DOUBLEBUF | pygame.RESIZABLE
        try:
            pygame.display.set_mode(size, flags, vsync=1)
        except pygame.error:
            pygame.display.set_mode(size, flags)
        window = self._window()
        if window is not None:
            if mode == "borderless":
                window.position = (0, 0)
            elif mode == "windowed":
                window.position = pygame.WINDOWPOS_CENTERED
                window.minimum_size = (self.display.get_width() // 2, self.display.get_height() // 2)
        arena = (float(self.offset[0]), float(self.offset[1]), float(S.WIDTH), float(S.HEIGHT))
        self.gpu = gpu.Renderer(self.display.get_size(), arena, pygame.display.get_window_size(),
                                hires.real(self.display).get_size())
        for bg in (getattr(self, "background", None), getattr(getattr(self, "demo", None), "bg", None)):
            if bg is not None:
                self._gpu_background(bg)

    def _make_surfaces(self):
        """The arena canvas and the fonts, at native resolution when ULTRA draws that way.
        The fonts dict is updated in place: particles and worlds share it."""
        self.canvas = hires.surface((S.WIDTH, S.HEIGHT))
        self.fonts.update({
            "huge": hires.font(None, 150),
            "big": hires.font(None, 72),
            "medium": hires.font(None, 38),
            "small": hires.font(None, 28),
            "tiny": hires.font(None, 22),
        })
        render.reset_fonts()
        self._veils = {}

    def rebuild_gpu_display(self):
        """ULTRA again from scratch (the drawing resolution changed)."""
        if self.gpu is None:
            return
        self._drop_gpu()
        self._create_display()
        self._make_surfaces()

    def _drop_gpu(self):
        hires.disable()
        if self.gpu is not None:
            self.gpu.release()
        self.gpu = None
        self.gpu_mode = False

    def _gpu_background(self, bg):
        """With ULTRA the GPU paints the sky; the game layer keeps the grid and the action."""
        if self.gpu is not None:
            bg.sky = False
            bg.on_kick = self.gpu.kick

    def mouse_pos(self):
        """The mouse in logical (whole-picture) coordinates."""
        pos = pygame.mouse.get_pos()
        if self.gpu is not None:
            pos = gpu.window_to_logical(pos, pygame.display.get_window_size(), self.display.get_size())
        return pos

    def _gpu_event(self, e):
        """ULTRA: mouse positions arrive in window pixels; the game thinks in logical ones."""
        if self.gpu is None or not hasattr(e, "pos"):
            return e
        window, logical = pygame.display.get_window_size(), self.display.get_size()
        data = {**e.dict, "pos": gpu.window_to_logical(e.pos, window, logical)}
        if hasattr(e, "rel"):
            scale = gpu.viewport(window, logical)[4]
            data["rel"] = (e.rel[0] / scale, e.rel[1] / scale)
        return pygame.event.Event(e.type, data)

    @staticmethod
    def _window():
        """The window behind pygame.display (used to resize/centre it).
        from_display_module() is deprecated in pygame-ce in favour of creating a
        pygame.Window directly; switch to that if it's ever removed."""
        if web.IS_WEB:
            return None
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", DeprecationWarning)
                return pygame.Window.from_display_module()
        except (AttributeError, pygame.error):
            return None

    def normal_window_size(self):
        """The windowed size: the logical size times the largest whole-number
        scale that fits comfortably on the desktop (room left for the taskbar
        and title bar), shrunk instead if even x1 doesn't fit."""
        lw, lh = self.display.get_size()
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0]
        except (pygame.error, IndexError):
            return lw, lh
        max_w, max_h = dw * 0.90, dh * 0.85
        if self.gpu_mode:                   # ULTRA scales smoothly: as big as fits
            scale = min(max_w / lw, max_h / lh)
            return round(lw * scale), round(lh * scale)
        scale = max(1, int(min(max_w / lw, max_h / lh)))
        if lw * scale > max_w or lh * scale > max_h:
            scale = min(max_w / lw, max_h / lh)
        return round(lw * scale), round(lh * scale)

    def restore_window(self):
        """Back to a normal-size window, centred, with the title bar on screen.
        (Without this, leaving a fullscreen the game *started* in kept the
        window desktop-sized, pushing its title bar and close button off-screen.)"""
        window = self._window()
        if window is None:
            return
        window.size = self.normal_window_size()
        window.position = pygame.WINDOWPOS_CENTERED

    def _bind_surfaces(self):
        """self.display is the whole screen; self.screen is the 1280x720 arena
        inside it, which all HUD and menu drawing uses."""
        if not self.gpu_mode:                  # ULTRA keeps its own off-screen surface
            self.display = pygame.display.get_surface()
        w, h = self.display.get_size()
        self.offset = ((w - S.WIDTH) // 2, (h - S.HEIGHT) // 2)
        self.screen = self.display.subsurface(pygame.Rect(self.offset, (S.WIDTH, S.HEIGHT)))
        self._veils = {}

    def to_arena(self, event):
        """Convert mouse positions from screen to arena coordinates."""
        if hasattr(event, "pos") and self.offset != (0, 0):
            x, y = event.pos
            return pygame.event.Event(event.type, {**event.dict, "pos": (x - self.offset[0], y - self.offset[1])})
        return event

    DISPLAY_MODES = ("borderless", "fullscreen", "windowed")

    @property
    def display_mode(self):
        """borderless (fullscreen windowed, the default), fullscreen (exclusive) or windowed."""
        mode = self.settings.get("display")
        return mode if mode in self.DISPLAY_MODES else "borderless"

    def set_display(self, mode):
        if web.IS_WEB or mode not in self.DISPLAY_MODES:
            return
        if mode != "windowed":
            self.settings["last_fullscreen"] = mode          # what F11 brings back
        self.settings["display"] = mode
        self.settings["fullscreen"] = mode != "windowed"
        if self.gpu is not None:
            self._open_gpu_window()
        elif (mode != "windowed") != pygame.display.is_fullscreen():
            pygame.display.toggle_fullscreen()
            if not pygame.display.is_fullscreen():
                self.restore_window()
            self._bind_surfaces()
        storage.save_settings(self.settings)

    def toggle_fullscreen(self):
        """F11 / Alt+Enter: windowed <-> the fullscreen mode chosen in the menu."""
        if web.IS_WEB:
            web.toggle_browser_fullscreen()
            return
        if self.display_mode == "windowed":
            back = self.settings.get("last_fullscreen")
            self.set_display(back if back in ("borderless", "fullscreen") else "borderless")
        else:
            self.set_display("windowed")

    def quit(self):
        storage.save_settings(self.settings)
        self.pads.close()
        self.audio.shutdown()
        if web.IS_WEB:
            return                      # a browser tab is closed by the player, not the game
        pygame.quit()
        sys.exit(0)

    # ------------------------------------------------------------ input
    def read_controls(self, events):
        keys = pygame.key.get_pressed()
        move = Vector2(
            (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT]),
            (keys[pygame.K_s] or keys[pygame.K_DOWN]) - (keys[pygame.K_w] or keys[pygame.K_UP]),
        )
        c = Controls(move=move)
        stick = self.pads.stick()
        if stick.length() > 0:
            c.move = stick
        for e in events:
            if e.type == pygame.KEYDOWN and e.key in (pygame.K_SPACE, pygame.K_LSHIFT, pygame.K_RSHIFT, pygame.K_j):
                c.dash = True
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                c.dash, c.dash_target = True, Vector2(e.pos)
            elif e.type == pygame.KEYDOWN and e.key in (pygame.K_e, pygame.K_k):
                c.nova = True
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 3:
                c.nova = True
            elif _pad(e, "a", "rb", "rt"):
                c.dash = True
            elif _pad(e, "b", "lb", "lt"):
                c.nova = True
        return c

    def update_pad_feedback(self):
        """DualSense / DualShock light bar and triggers follow what's on screen."""
        if self.state == "play" and self.world and not self.world.over:
            p = self.world.player
            self.pads.light(p.ship.color)
            self.pads.triggers("play" if p.novas > 0 else "play_no_nova")
        else:
            self.pads.light(S.PINK)
            self.pads.triggers("off")

    def handle_global(self, e):
        if e.type == pygame.QUIT:
            self.quit()
        if self.gpu is not None and e.type in (pygame.VIDEORESIZE, pygame.WINDOWSIZECHANGED):
            self.gpu.resize(pygame.display.get_window_size())
        # Desktop: no sound while the window is in the background (the game pauses itself too).
        if e.type == pygame.WINDOWFOCUSLOST and pygame.mixer.get_init():
            pygame.mixer.pause()
        elif e.type == pygame.WINDOWFOCUSGAINED and pygame.mixer.get_init():
            pygame.mixer.unpause()
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_F11 or (e.key == pygame.K_RETURN and e.mod & pygame.KMOD_ALT):
                self.toggle_fullscreen()
                return True
            if e.key == pygame.K_m:
                self.settings["muted"] = not self.settings["muted"]
                self.audio.set_muted(self.settings["muted"])
                storage.save_settings(self.settings)
                return True
            if e.key == pygame.K_F3:
                self.show_fps = self.settings["show_fps"] = not self.show_fps
                storage.save_settings(self.settings)
                return True
        return False

    def handle_menu(self, events):
        items = self.menu_items()
        for e in events:
            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_UP, pygame.K_w):
                    self.menu_index = (self.menu_index - 1) % len(items)
                    self.audio.play("select", 0.4)
                elif e.key in (pygame.K_DOWN, pygame.K_s):
                    self.menu_index = (self.menu_index + 1) % len(items)
                    self.audio.play("select", 0.4)
                elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self.activate(items[self.menu_index][0])
                elif e.key == pygame.K_ESCAPE:
                    self.quit()
            elif e.type == pygame.MOUSEMOTION:
                for i, rect in enumerate(self.menu_rects()):
                    if rect.collidepoint(e.pos):
                        self.menu_index = i
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for i, rect in enumerate(self.menu_rects()):
                    if rect.collidepoint(e.pos):
                        self.activate(items[i][0])
            elif _pad(e, "a", "start"):
                self.activate(items[self.menu_index][0])
            elif _pad(e, "up", "down"):
                self.menu_index = (self.menu_index + (1 if e.button == "down" else -1)) % len(items)
                self.audio.play("select", 0.4)

    def music_mood(self):
        """Which track fits the moment: menus, a run, or a boss fight (it cross-fades)."""
        if self.state in ("play", "paused") and self.world and not self.world.over:
            return "boss" if self.world.boss else self.world.sector.music
        return "menu"

    # ------------------------------------------------------------ main loop
    def frame(self):
        # Browser: no cap, requestAnimationFrame already paces frames to the display.
        raw_dt = self.clock.tick(0 if web.IS_WEB else S.FPS) / 1000
        dt = min(raw_dt, S.MAX_DT)
        work_start = time.perf_counter()
        if raw_dt > 0.5 and self.state == "play" and self.world and not self.world.over:
            self.state = "paused"         # back from another tab (the browser froze the game)
        self.t += dt
        # Running below ~45 fps for 3 s in a row: drop the bloom (the costliest effect).
        self.slow_time = self.slow_time + raw_dt if 0.022 < raw_dt < 0.5 else 0.0
        if self.slow_time > 3.0 and self.bloom_ok:
            self.bloom_ok = False
        raw = [e for e in map(self._gpu_event, pygame.event.get()) if not self.handle_global(e)]
        events = [self.to_arena(e) for e in self.pads.translate(raw)]
        if not self.input_seen and any(e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN) for e in raw):
            self.input_seen = True
            self.audio.start_music()      # the browser lets sound out from this click / key on
        self.update_pad_feedback()
        self.update(dt, events)
        self.audio.set_mood(self.music_mood())
        self.audio.update()
        cursor = "reticle" if self.state == "play" and self.world and not self.world.draft else "pointer"
        if cursor != self.cursor:
            render.set_cursor(cursor)
            self.cursor = cursor
        self.frame_dim = 0.0
        self.draw()
        measuring = self.state == "benchmark" or self.first_check is not None
        gpu_start = time.perf_counter()
        if self.gpu is not None:
            self.present_gpu(dt)
            if measuring and self.gpu is not None:
                self.gpu.ctx.finish()      # count the graphics card's share of the frame too
        if measuring:
            now = time.perf_counter()
            if self.state == "benchmark" and self.bench is not None:
                self.bench.record((now - work_start) * 1000)
            self._first_check(dt, (now - gpu_start) * 1000)
        pygame.display.flip()

    def present_gpu(self, dt):
        """ULTRA: hand the frame to the graphics card for the sky, shockwaves and post."""
        bg = self.demo.bg if self.state in self.DEMO_STATES else self.background
        if self.state in ("benchmark", "bench_result") and self.bench is not None:
            bg = self.bench.world.bg
        focus = (bg.focus[0] - S.WIDTH / 2, bg.focus[1] - S.HEIGHT / 2)
        flash = self.world.flash if self.world is not None and self.state == "play" else 0.0
        self.gpu.update(dt)
        self.gpu.nebula_colours = bg.palette.nebula()
        try:
            self.gpu.render(hires.real(self.display), self.t, (self.t * 16.0, self.t * 5.0), focus, self.frame_dim, flash)
        except Exception as error:         # noqa: BLE001 - GPU lost: keep playing, classic look
            print(f"ULTRA graphics stopped ({error}); restart the game to use them again")
            self._drop_gpu()
            self.settings["graphics"] = "standard"
            storage.save_settings(self.settings)

    def run(self):
        while True:
            self.frame()

    async def run_async(self):
        """Browser main loop: yield to the page after every frame (it paces us with
        requestAnimationFrame, so the frame rate follows the monitor)."""
        while True:
            self.frame()
            await asyncio.sleep(0)

    def draft_rects(self):
        count = len(self.world.draft) if self.world and self.world.draft else 3
        w, h, gap = 320, 230, 36
        left = S.WIDTH / 2 - (count * w + (count - 1) * gap) / 2
        return [pygame.Rect(left + i * (w + gap), 250, w, h) for i in range(count)]

    def read_draft(self, events):
        """Keyboard / mouse / gamepad input on the upgrade cards. Returns a pick or None."""
        count = len(self.world.draft)
        self.draft_index = min(self.draft_index, count - 1)
        for e in events:
            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_1, pygame.K_2, pygame.K_3) and e.key - pygame.K_1 < count:
                    return e.key - pygame.K_1
                if e.key in (pygame.K_LEFT, pygame.K_a):
                    self.draft_index = (self.draft_index - 1) % count
                    self.audio.play("select", 0.4)
                elif e.key in (pygame.K_RIGHT, pygame.K_d):
                    self.draft_index = (self.draft_index + 1) % count
                    self.audio.play("select", 0.4)
                elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    return self.draft_index
            elif e.type == pygame.MOUSEMOTION:
                for i, rect in enumerate(self.draft_rects()):
                    if rect.collidepoint(e.pos):
                        self.draft_index = i
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for i, rect in enumerate(self.draft_rects()):
                    if rect.collidepoint(e.pos):
                        return i
            elif _pad(e, "left", "right"):
                self.draft_index = (self.draft_index + (1 if e.button == "right" else -1)) % count
                self.audio.play("select", 0.4)
            elif _pad(e, "a"):
                return self.draft_index
        return None

    # ------------------------------------------------------------ launch screen
    def _cycle(self, row, step):
        if row == 1:
            if self.settings.get("mode") != "daily":
                ids = difficulty.unlocked_levels(self.settings)
                current = difficulty.level(self.settings.get("difficulty"))[0]
                i = ids.index(current) if current in ids else 0
                self.settings["difficulty"] = ids[(i + step) % len(ids)]
        elif row == 0:
            ids = [m.id for m in modes.MODES]
            current = self.settings.get("mode")
            i = ids.index(current) if current in ids else 0
            self.settings["mode"] = ids[(i + step) % len(ids)]
        elif self.settings.get("mode") != "daily":
            ids = [sh.id for sh in ships.SHIPS]
            current = self.settings.get("ship")
            i = ids.index(current) if current in ids else 0
            self.settings["ship"] = ids[(i + step) % len(ids)]
        self.audio.play("select", 0.4)
        storage.save_settings(self.settings)

    def launch_ready(self):
        if self.settings.get("mode") == "daily":
            return True
        return ships.is_unlocked(ships.get(self.settings.get("ship")), self.unlocked)

    def launch_rects(self):
        return {"mode": pygame.Rect(140, 96, 1000, 122), "difficulty": pygame.Rect(140, 228, 1000, 122),
                "options": pygame.Rect(940, 304, 180, 34),
                "ship": pygame.Rect(140, 360, 1000, 250), "start": pygame.Rect(S.WIDTH / 2 - 160, 626, 320, 56)}

    def handle_launch(self, events):
        rects = self.launch_rects()
        for e in events:
            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_UP, pygame.K_w, pygame.K_DOWN, pygame.K_s):
                    self.launch_row = (self.launch_row + (1 if e.key in (pygame.K_DOWN, pygame.K_s) else -1)) % 3
                    self.audio.play("select", 0.3)
                elif e.key == pygame.K_o:
                    self.open_difficulty()
                elif e.key in (pygame.K_LEFT, pygame.K_a):
                    self._cycle(self.launch_row, -1)
                elif e.key in (pygame.K_RIGHT, pygame.K_d, pygame.K_TAB):
                    self._cycle(self.launch_row, 1)
                elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self._try_launch()
                elif e.key == pygame.K_ESCAPE:
                    self.state = "menu"
                    self.audio.play("select")
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                if rects["start"].collidepoint(e.pos):
                    self._try_launch()
                    continue
                if rects["options"].collidepoint(e.pos):
                    self.open_difficulty()
                    continue
                for row, key in ((0, "mode"), (1, "difficulty"), (2, "ship")):
                    if rects[key].collidepoint(e.pos):
                        self.launch_row = row
                        self._cycle(row, 1 if e.pos[0] > S.WIDTH / 2 else -1)
            elif _pad(e, "up", "down"):
                self.launch_row = (self.launch_row + (1 if e.button == "down" else -1)) % 3
                self.audio.play("select", 0.3)
            elif _pad(e, "y"):
                self.open_difficulty()
            elif _pad(e, "left", "right", "lb", "rb"):
                self._cycle(self.launch_row, 1 if e.button in ("right", "rb") else -1)
            elif _pad(e, "a", "start"):
                self._try_launch()
            elif _pad(e, "b"):
                self.state = "menu"
                self.audio.play("select")

    # ------------------------------------------------------------ difficulty options
    def difficulty_items(self):
        return list(difficulty.OPTIONS) + ["reset", "done"]

    def difficulty_rects(self):
        return [pygame.Rect(170, 120 + i * 36, 940, 32) for i in range(len(self.difficulty_items()))]

    def open_difficulty(self):
        if self.settings.get("mode") == "daily":
            self.audio.play("clang", 0.5)
            return
        self.state, self.diff_index = "difficulty", 0
        self.audio.play("select", 0.5)

    def _difficulty_activate(self, index):
        item = self.difficulty_items()[index]
        if item == "done":
            self.state = "launch"
        elif item == "reset":
            difficulty.reset(self.settings)
        else:
            difficulty.toggle(self.settings, item)
        self.audio.play("select", 0.5)
        storage.save_settings(self.settings)

    def handle_difficulty(self, events):
        n = len(self.difficulty_items())
        for e in events:
            if e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_UP, pygame.K_w, pygame.K_DOWN, pygame.K_s):
                    self.diff_index = (self.diff_index + (1 if e.key in (pygame.K_DOWN, pygame.K_s) else -1)) % n
                    self.audio.play("select", 0.3)
                elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
                    self._difficulty_activate(self.diff_index)
                elif e.key in (pygame.K_ESCAPE, pygame.K_o):
                    self.state = "launch"
                    self.audio.play("select")
            elif e.type == pygame.MOUSEMOTION:
                for i, rect in enumerate(self.difficulty_rects()):
                    if rect.collidepoint(e.pos):
                        self.diff_index = i
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for i, rect in enumerate(self.difficulty_rects()):
                    if rect.collidepoint(e.pos):
                        self.diff_index = i
                        self._difficulty_activate(i)
            elif _pad(e, "up", "down"):
                self.diff_index = (self.diff_index + (1 if e.button == "down" else -1)) % n
                self.audio.play("select", 0.3)
            elif _pad(e, "a"):
                self._difficulty_activate(self.diff_index)
            elif _pad(e, "b", "y", "start"):
                self.state = "launch"
                self.audio.play("select")

    def draw_difficulty(self):
        f = self.fonts
        lid, name, color, _ = difficulty.level(self.settings.get("difficulty"))
        render.text(self.screen, f["big"], f"{name}", (S.WIDTH / 2, 52), color, anchor="center", glow_color=color)
        render.text(self.screen, f["tiny"], "tick what you want: every difficulty keeps its own choices and high scores",
                    (S.WIDTH / 2, 96), (170, 170, 205), anchor="center")
        chosen = difficulty.ticked(self.settings)
        defaults = difficulty.defaults(lid)
        for i, (item, rect) in enumerate(zip(self.difficulty_items(), self.difficulty_rects())):
            selected = i == self.diff_index
            if selected:
                pygame.draw.rect(self.screen, (22, 20, 46), rect, border_radius=8)
                pygame.draw.rect(self.screen, color, rect, 2, border_radius=8)
            y = rect.centery
            if item in difficulty.OPTIONS:
                label, desc = difficulty.OPTIONS[item]
                box = pygame.Rect(rect.left + 14, y - 10, 20, 20)
                on = item in chosen
                pygame.draw.rect(self.screen, color if on else (90, 90, 130), box, 2, border_radius=4)
                if on:
                    render.aa_lines(self.screen, color, False,
                                    [(box.left + 4, y), (box.left + 9, y + 5), (box.right - 3, y - 6)], 3)
                render.text(self.screen, f["small"], label, (rect.left + 50, y), S.WHITE if on else (150, 150, 185),
                            anchor="midleft")
                render.text(self.screen, f["tiny"], desc + ("" if (item in defaults) == on else "   (changed)"),
                            (rect.left + 330, y), (190, 190, 220) if on else (120, 120, 155), anchor="midleft")
            else:
                label = "RESET TO DEFAULTS" if item == "reset" else "DONE"
                render.text(self.screen, f["small"], label, (rect.left + 50, y), color if item == "done" else S.WHITE,
                            anchor="midleft")
        self.hint("{navigate}  move      {tick}  tick / untick      {back}  done", (S.WIDTH / 2, 700), "tiny",
                  (130, 130, 165))

    def _try_launch(self):
        if self.launch_ready():
            self.start_game()
        else:
            self.audio.play("clang", 0.6)

    def update(self, dt, events):
        self.shake.update(dt)
        self.background.update(dt)
        for toast in self.toasts:
            toast[1] += dt
        self.toasts = [t for t in self.toasts if t[1] < 3.6]
        if self.notice is not None:
            self.notice[1] += dt
        if self.state == "benchmark":
            for e in events:
                if (e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE) or _pad(e, "b", "back"):
                    self.finish_benchmark()
                    return
            self.bench.update(dt)
            if self.bench.done:
                self.finish_benchmark()
        elif self.state == "bench_result":
            if any(e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN) or _pad_press(e) for e in events):
                self.audio.play("select")
                self.state = "menu"
                self.bench = None
        elif self.state == "menu":
            self.handle_menu(events)
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
            self.demo.bg.update(dt)
            if self.demo.over or self.demo.wave > 7:
                self._new_demo()
        elif self.state == "difficulty":
            self.handle_difficulty(events)
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
        elif self.state == "launch":
            self.handle_launch(events)
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
        elif self.state == "credits":
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
            self.credits_t += dt
            skip = self.credits_t > 1.0 and any(
                e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN) or _pad_press(e) for e in events)
            if skip or self.credits_t > self.credits_length():
                self.state = "menu"
        elif self.state == "options":
            self.options.handle(events)
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
        elif self.state in ("howto", "trophies"):
            self.demo.update(dt, self.demo_pilot.controls(self.demo))
            self.demo.particles.update(dt)
            if any(e.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN) or _pad_press(e) for e in events):
                self.audio.play("select")
                self.state = self.howto_back if self.state == "howto" else "menu"
        elif self.state == "play":
            for e in events:
                if (e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_p)) or \
                        _pad(e, "start") or \
                        (e.type == pygame.WINDOWFOCUSLOST):
                    self.state = "paused"
                    return
            if self.world.draft:
                controls = Controls(pick=self.read_draft(events))
            else:
                self.draft_index = 1
                controls = self.read_controls(events)
            self.world.update(dt, controls)
            self.particles.update(dt)
            self.check_achievements()
            if self.world.over:
                self.over_timer += dt
                if self.over_timer > 2.2:
                    self.finish_game()
        elif self.state == "paused":
            for e in events:
                if e.type == pygame.KEYDOWN and e.key in (pygame.K_ESCAPE, pygame.K_p, pygame.K_RETURN):
                    self.state = "play"
                elif e.type == pygame.KEYDOWN and e.key == pygame.K_q:
                    self.state = "menu"
                elif e.type == pygame.KEYDOWN and e.key == pygame.K_r:
                    self.start_game()
                elif _pad(e, "y"):
                    self.start_game()
                elif _pad(e, "back"):
                    self.state = "menu"
                elif e.type == pygame.MOUSEBUTTONDOWN or _pad(e, "a", "b", "start"):
                    self.state = "play"
        elif self.state == "gameover":
            self.particles.update(dt)
            for e in events:
                if self.result.get("won") and ((e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_SPACE))
                                               or _pad(e, "a")):
                    self.audio.play("select")
                    self.credits_t = 0.0
                    self.state = "credits"
                    return
                if (e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_r)) or \
                        _pad(e, "a", "y"):
                    self.start_game()
                elif (e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE) or \
                        _pad(e, "b"):
                    self.state = "menu"
                    self.audio.play("select")

    def finish_game(self):
        w = self.world
        self.check_achievements()
        rank = storage.add_score(w.score, w.wave, w.combo.best_chain,
                                 board=modes.score_key(w.mode) + difficulty.board_suffix(w.rules.level),
                                 ship=w.player.ship.id)
        storage.add_lifetime(games=1, kills=w.stats["kills"], bosses=w.stats["bosses"],
                             waves=w.wave, dashes=w.stats["dashes"], seconds=w.t)
        self.result = {"score": w.score, "wave": w.wave, "chain": w.combo.best_chain,
                       "kills": w.stats["kills"], "best_dash": w.stats["best_dash_kills"], "rank": rank,
                       "unlocks": list(self.run_unlocks), "perks": dict(w.player.perks),
                       "mode": w.mode, "ship": w.player.ship, "won": w.won,
                       "sector": w.sector_index, "ngplus_new": False}
        if w.mode != "daily":
            self.settings["last_gear"] = dict(w.player.perks)    # what NEW GAME+ starts with
        if w.won and w.rules.level in ("die", "ngplus") and not self.settings.get("ngplus_unlocked"):
            self.settings["ngplus_unlocked"] = True
            self.result["ngplus_new"] = True
        storage.save_settings(self.settings)
        self.state = "gameover"

    # ------------------------------------------------------------ drawing
    def draw_world(self, world, background, shake=(0, 0)):
        """Background over the whole display, then the arena (with screen shake)."""
        x, y = round(self.offset[0] + shake[0]), round(self.offset[1] + shake[1])
        background.draw(self.display, self.t, origin=(x, y))
        background.draw(self.canvas, self.t, arena=True)
        world.draw(self.canvas)
        self.display.blit(self.canvas, (x, y))

    DEMO_STATES = ("menu", "howto", "trophies", "launch", "difficulty", "credits", "options")

    def draw(self):
        if self.state in self.DEMO_STATES:
            self.draw_world(self.demo, self.demo.bg)
            self.dim(150 if self.state == "menu" else 200)
            {"menu": self.draw_menu, "howto": self.draw_howto, "trophies": self.draw_trophies,
             "options": lambda: self.options.draw(self.screen, self.fonts, self.hint),
             "launch": self.draw_launch, "difficulty": self.draw_difficulty,
             "credits": self.draw_credits}[self.state]()
        elif self.state in ("benchmark", "bench_result"):
            self.draw_world(self.bench.world, self.bench.world.bg)
            if self.state == "benchmark":
                self.draw_benchmark()
            else:
                self.dim(170)
                self.draw_bench_result()
        else:
            self.draw_world(self.world, self.background, self.shake.offset(self.t))
            self.draw_danger()
            if self.state == "gameover":
                self.dim(170)
                self.draw_gameover()
            else:
                self.draw_hud()
                if self.world.draft and self.state == "play":
                    self.draw_draft()
                if self.state == "paused":
                    self.dim(160)
                    self.big_center("PAUSED", "{pause}: resume     {restart}: restart     {quit}: quit to menu")
        if self.settings.get("effects", "high") != "low" and self.bloom_ok and self.gpu is None:
            self.bloom.apply(self.display)      # neon glow on everything drawn so far
        self.draw_toasts()
        if self.state == "menu":
            self.draw_notice()
        if web.IS_WEB and not self.settings["muted"] and not web.sound_allowed(self.input_seen):
            pulse = 170 + int(85 * math.sin(self.t * 4))
            render.text(self.screen, self.fonts["small"], "CLICK OR PRESS A KEY TO TURN THE SOUND ON",
                        (S.WIDTH / 2, 18), (pulse, pulse, 255), anchor="midtop", glow_color=S.CYAN)
        if self.show_fps:
            render.text(self.screen, self.fonts["tiny"], f"{self.clock.get_fps():.0f} fps",
                        (S.WIDTH - 10, S.HEIGHT - 8), S.GREEN, anchor="bottomright")

    def dim(self, alpha):
        """Darken the whole display (sides included) behind a menu or overlay."""
        self.frame_dim = max(self.frame_dim, alpha / 255)
        veil = self._veils.get(alpha)
        if veil is None:
            veil = hires.surface(self.display.get_size(), pygame.SRCALPHA)
            veil.fill((4, 3, 12, alpha))
            self._veils[alpha] = veil
        self.display.blit(veil, (0, 0))

    def title(self, pos, size="huge"):
        font = self.fonts[size]
        wobble = math.sin(self.t * 2) * 3
        # chromatic-aberration look: pink and cyan copies peeking out either side
        img = font.render(S.TITLE, True, S.WHITE)
        rect = img.get_rect(midleft=pos)
        render.glow(self.screen, (rect.centerx, rect.centery), rect.width * 0.55, S.PURPLE, 0.35)
        for dx, color in ((-4 - wobble, S.PINK), (4 + wobble, S.CYAN)):
            self.screen.blit(font.render(S.TITLE, True, color), rect.move(dx, 0))
        self.screen.blit(img, rect)
        if size == "huge":                       # the V2 badge
            badge = pygame.Rect(rect.right + 18, rect.top + 12, 74, 56)
            render.glow(self.screen, badge.center, 70, S.GOLD, 0.45)
            pygame.draw.rect(self.screen, S.GOLD, badge, 3, border_radius=10)
            render.text(self.screen, self.fonts["big"], "2", badge.center, S.GOLD, anchor="center")

    def draw_menu(self):
        self.title((110, 170))
        render.text(self.screen, self.fonts["small"], "your dash is your only weapon",
                    (118, 240), S.GOLD)
        for i, ((key, label), rect) in enumerate(zip(self.menu_items(), self.menu_rects())):
            selected = i == self.menu_index
            if selected:
                render.glow(self.screen, (rect.left + 10, rect.centery), 26, S.CYAN, 0.8)
                pts = render.ship_points((rect.left - 6, rect.centery), 9, 0)
                pygame.draw.polygon(self.screen, S.CYAN, pts)
            color = S.WHITE if selected else (150, 150, 185)
            render.text(self.screen, self.fonts["medium"], label, (rect.left + 15, rect.centery),
                        color, anchor="midleft")

        # high scores
        x, y = 800, 320
        mode_id = self.settings.get("mode", "classic")
        board = modes.score_key(mode_id)
        label = "TODAY'S DAILY RUN" if mode_id == "daily" else modes.BY_ID.get(mode_id, modes.MODES[0]).name
        render.text(self.screen, self.fonts["medium"], "HIGH SCORES", (x, y - 30), S.PINK)
        render.text(self.screen, self.fonts["tiny"], label, (x + 2, y + 6), (170, 170, 205))
        y += 10
        scores = storage.load_scores(board)
        if not scores:
            render.text(self.screen, self.fonts["small"], "none yet - be the first!", (x, y + 50), (150, 150, 185))
        for i, s in enumerate(scores):
            row = y + 50 + i * 36
            render.text(self.screen, self.fonts["small"], f"{i + 1}.", (x, row), S.GOLD)
            render.text(self.screen, self.fonts["small"], f"{s['score']:,}", (x + 40, row), S.WHITE)
            ship = ships.get(s.get("ship", "prism"))
            render.text(self.screen, self.fonts["tiny"], f"wave {s['wave']}  chain {s.get('chain', 0)}",
                        (x + 190, row + 3), (150, 150, 185))
            pygame.draw.polygon(self.screen, ship.color, render.ship_points((x + 350, row + 10), 7, 0))
        self.hint(f"v{__version__}   arrows/WASD + Enter   -   M mute   -   F11 fullscreen" if self.pads.device == "keyboard"
                  else f"v{__version__}     {{navigate}}  move     {{confirm}}  select",
                  (S.WIDTH / 2, S.HEIGHT - 38), "tiny", (120, 120, 160))
        render.text(self.screen, self.fonts["tiny"], f"PRISM DASH {__copyright__}",
                    (S.WIDTH / 2, S.HEIGHT - 16), (95, 95, 130), anchor="center")

    def draw_howto(self):
        render.text(self.screen, self.fonts["big"], "HOW TO PLAY", (S.WIDTH / 2, 70), S.WHITE,
                    anchor="center", glow_color=S.CYAN)
        lines = [
            ("MOVE", "WASD / arrow keys" if self.pads.device == "keyboard" else "{move}  left stick"),
            ("DASH", "Space or Shift (move direction), or LEFT CLICK (towards the cursor)"
                     if self.pads.device == "keyboard" else "{dash}  dashes the way the left stick points"),
            ("NOVA", "{nova}  destroys everything on screen (limited!)"),
            ("PAUSE", ("Esc / P" if self.pads.device == "keyboard" else "{pause}") + "     -     PLAY lets you pick a mode and a ship"),
        ]
        for i, (key, desc) in enumerate(lines):
            render.text(self.screen, self.fonts["medium"], key, (180, 140 + i * 40), S.GOLD)
            self.hint(desc, (330, 145 + i * 40), "small", S.WHITE, anchor="topleft")

        render.text(self.screen, self.fonts["small"],
                    "You have no gun. DASH THROUGH enemies to destroy them - you're invincible while dashing.",
                    (S.WIDTH / 2, 330), S.CYAN, anchor="center")
        render.text(self.screen, self.fonts["small"],
                    "Every kill during a dash RECHARGES it instantly. Chain kills to build your multiplier (up to x8).",
                    (S.WIDTH / 2, 362), S.CYAN, anchor="center")

        enemies = [
            (S.PINK, 3, "DRIFTER", "chases you"),
            (S.YELLOW, 4, "DART", "aims a laser, then charges"),
            (S.GREEN, 6, "SPLITTER", "breaks into three"),
            (S.CYAN, 4, "SPINNER", "fires rings of bullets"),
            (S.ORANGE, 5, "WARDEN", "shielded - hit it from behind"),
            (S.LIME, 8, "WEAVER", "lays mines - dash to defuse"),
            (S.PURPLE, 6, "BOSSES", "a new one ends every sector"),
            (S.GOLD, 5, "UPGRADES", "pick 1 of 3 after some waves"),
        ]
        for i, (color, sides, name, desc) in enumerate(enemies):
            col, row = i % 4, i // 4
            x, y = 110 + col * 290, 450 + row * 95
            pts = render.regular_polygon((x, y), 20, sides, self.t * 1.5)
            render.neon_polygon(self.screen, pts, color, glow_radius=50)
            render.text(self.screen, self.fonts["small"], name, (x + 40, y - 18), color)
            render.text(self.screen, self.fonts["tiny"], desc, (x + 40, y + 6), S.WHITE)
        render.text(self.screen, self.fonts["tiny"],
                    "Power-ups: red = +1 life   purple = +1 nova   gold = OVERDRIVE (dash with no cooldown)",
                    (S.WIDTH / 2, 655), S.GOLD, anchor="center")
        render.text(self.screen, self.fonts["tiny"], "press any key", (S.WIDTH / 2, 684),
                    (150, 150, 185), anchor="center")
        render.text(self.screen, self.fonts["tiny"],
                    f"PRISM DASH is an original game.   {__copyright__}",
                    (S.WIDTH / 2, 708), (95, 95, 130), anchor="center")

    def draw_hud(self):
        w, p, f = self.world, self.world.player, self.fonts
        render.text(self.screen, f["big"], f"{w.score:,}", (40, 30), S.WHITE)
        mult = w.combo.multiplier
        if w.combo.chain:
            color = S.GOLD if mult >= 4 else S.CYAN
            render.text(self.screen, f["medium"], f"x{mult}", (42, 84), color, glow_color=color)
            render.text(self.screen, f["tiny"], f"chain {w.combo.chain}", (100, 92), (170, 170, 200))
            bar = min(1.0, w.combo.timer / w.combo.window)
            pygame.draw.rect(self.screen, (40, 40, 70), (42, 118, 160, 5))
            pygame.draw.rect(self.screen, color, (42, 118, 160 * bar, 5))
        render.text(self.screen, f["medium"], f"WAVE {max(1, w.wave)}", (S.WIDTH - 40, 36),
                    S.WHITE, anchor="topright")
        if not w.blitz:
            render.text(self.screen, f["tiny"], f"SECTOR {w.sector_index + 1}  {w.sector.name}",
                        (S.WIDTH - 40, 66), w.sector.accent, anchor="topright")
        tags = []
        if w.mode != "classic":
            tags.append(("DAILY RUN" if w.mode == "daily" else "BLITZ", S.GOLD))
        if w.rules.level != difficulty.DEFAULT:
            _, lname, lcolor, _ = difficulty.level(w.rules.level)
            tags.append((lname, lcolor))
        for i, (tag, tag_color) in enumerate(tags):
            render.text(self.screen, f["tiny"], tag, (S.WIDTH - 40, (66 if w.blitz else 88) + i * 22), tag_color, anchor="topright")
        if w.blitz:
            secs = max(0.0, w.time_left)
            urgent = secs < 20
            color = S.RED if urgent else S.WHITE
            clock = f"{int(secs) // 60}:{int(secs) % 60:02d}"
            pos = (S.WIDTH / 2, 92 if w.boss else 40)
            if urgent and int(self.t * 4) % 2:
                render.glow(self.screen, pos, 70, S.RED, 0.4)
            render.text(self.screen, f["big"], clock, pos, color, anchor="center")
        else:
            for i in range(p.lives):              # lives (Blitz has none: hits cost time)
                pts = render.ship_points((52 + i * 34, S.HEIGHT - 44), 10, -math.pi / 2)
                render.neon_polygon(self.screen, pts, p.ship.color, width=2, glow_radius=22)
        for i in range(p.novas):
            pos = (60 + i * 32, S.HEIGHT - 84)
            render.neon_circle(self.screen, pos, 9, S.PURPLE, width=2, glow_scale=2)
        if p.novas:
            self.hint("NOVA {nova1}" if self.pads.device != "keyboard" else "NOVA [E]",
                      (50 + p.novas * 32, S.HEIGHT - 92), "tiny", S.PURPLE, anchor="topleft")

        # dash meter
        width = 220
        x, y = S.WIDTH / 2 - width / 2, S.HEIGHT - 40
        ready = p.dash_ready
        color = S.GOLD if p.overdrive > 0 else (p.ship.color if ready else (90, 110, 150))
        slots, gap = p.max_charges, 8
        slot_w = (width - gap * (slots - 1)) / slots
        for i in range(slots):                    # one bar per dash charge
            if i < p.charges:
                fill = 1.0
            elif i == p.charges and p.dash_cd > 0:
                fill = 1 - p.dash_cd / p.cooldown_total
            else:
                fill = 0.0
            sx = x + i * (slot_w + gap)
            pygame.draw.rect(self.screen, (30, 30, 55), (sx, y, slot_w, 8), border_radius=4)
            pygame.draw.rect(self.screen, color if i < p.charges else (90, 110, 150),
                             (sx, y, slot_w * max(0.0, fill), 8), border_radius=4)
        if ready:
            render.glow(self.screen, (S.WIDTH / 2, y + 4), 60, color, 0.35)
        label = f"OVERDRIVE {p.overdrive:.1f}s" if p.overdrive > 0 else "DASH"
        render.text(self.screen, f["tiny"], label, (S.WIDTH / 2, y - 12), color, anchor="center")

        if p.barrier:
            render.text(self.screen, f["tiny"], "BARRIER", (52, S.HEIGHT - 22), S.WHITE)
        self.draw_perk_icons()

        boss = w.boss
        if boss:
            bw = 500
            bx = S.WIDTH / 2 - bw / 2
            bar_color = S.PINK if boss.enraged else boss.color
            render.text(self.screen, f["small"], boss.title, (S.WIDTH / 2, 26), bar_color, anchor="center")
            pygame.draw.rect(self.screen, (40, 25, 50), (bx, 44, bw, 10), border_radius=5)
            pygame.draw.rect(self.screen, bar_color, (bx, 44, bw * max(0, boss.hp) / boss.max_hp, 10),
                             border_radius=5)

        if w.banner and not w.draft:
            text, sub, left, color = w.banner
            alpha = min(1.0, left * 2.5)
            c = tuple(int(v * alpha) for v in color)
            render.text(self.screen, f["big"], text, (S.WIDTH / 2, S.HEIGHT / 2 - 150), c,
                        anchor="center", glow_color=c)
            if sub:
                render.text(self.screen, f["small"], sub, (S.WIDTH / 2, S.HEIGHT / 2 - 100),
                            tuple(int(v * alpha) for v in S.WHITE), anchor="center")

    def draw_danger(self):
        """Red flash when hit, and a pulsing red edge when on your last life."""
        w = self.world
        if w.flash > 0:
            veil = hires.surface((S.WIDTH, S.HEIGHT), pygame.SRCALPHA)
            veil.fill((255, 40, 60, int(45 * w.flash / 0.35)))
            self.screen.blit(veil, (0, 0))
        if w.player.lives == 1 and not w.over:
            k = 0.5 + 0.5 * math.sin(self.t * 5)
            edge = hires.surface((S.WIDTH, S.HEIGHT), pygame.SRCALPHA)
            for i in range(14):
                alpha = int((14 - i) * 7 * k)
                pygame.draw.rect(edge, (255, 30, 60, alpha), (i * 3, i * 3, S.WIDTH - i * 6, S.HEIGHT - i * 6), 3)
            self.screen.blit(edge, (0, 0))

    def draw_perk_icons(self):
        owned = self.world.player.perks
        x = S.WIDTH - 40
        for pid, level in reversed(list(owned.items())):
            perk = perks.PERKS[pid]
            label = perk.name.split()[0] + (f" {level}" if perk.max_level > 1 else "")
            img = self.fonts["tiny"].render(label, True, perk.color)
            rect = img.get_rect(bottomright=(x, S.HEIGHT - 36))
            pygame.draw.rect(self.screen, (20, 18, 40), rect.inflate(14, 8), border_radius=6)
            pygame.draw.rect(self.screen, perk.color, rect.inflate(14, 8), 1, border_radius=6)
            self.screen.blit(img, rect)
            x = rect.left - 22

    def draw_draft(self):
        self.dim(175)
        w = self.world
        render.text(self.screen, self.fonts["big"], "CHOOSE AN UPGRADE", (S.WIDTH / 2, 170), S.WHITE,
                    anchor="center", glow_color=S.GOLD)
        self.hint("{pick}  or click" if self.pads.device == "keyboard" else "{pick}  pick",
                  (S.WIDTH / 2, 215), "small", (170, 170, 205))
        for i, (pid, rect) in enumerate(zip(w.draft, self.draft_rects())):
            perk = perks.PERKS[pid]
            level = w.player.perk(pid) + 1
            selected = i == self.draft_index
            card = rect.move(0, -8 if selected else 0)
            if selected:
                render.glow(self.screen, card.center, card.width * 0.7, perk.color, 0.35)
            pygame.draw.rect(self.screen, (16, 14, 34), card, border_radius=14)
            pygame.draw.rect(self.screen, perk.color if selected else tuple(c // 2 for c in perk.color),
                             card, 3 if selected else 2, border_radius=14)
            render.text(self.screen, self.fonts["tiny"], f"[{i + 1}]", (card.left + 16, card.top + 14), (150, 150, 190))
            render.text(self.screen, self.fonts["medium"], perk.name, (card.centerx, card.top + 58),
                        perk.color, anchor="center")
            if perk.max_level > 1:          # level pips: filled up to the level you'd reach
                for n in range(perk.max_level):
                    cx = card.centerx + (n - (perk.max_level - 1) / 2) * 22
                    pygame.draw.aacircle(self.screen, perk.color, (cx, card.top + 92), 6, 0 if n < level else 2)
            else:
                render.text(self.screen, self.fonts["tiny"], "UNIQUE", (card.centerx, card.top + 92),
                            perk.color, anchor="center")
            self._wrapped(perks.describe(pid, level), card.centerx, card.top + 125, card.width - 40)

    def _wrapped(self, message, cx, top, width, font="small", color=S.WHITE):
        words, line, y = message.split(), "", top
        for word in words:
            trial = f"{line} {word}".strip()
            if self.fonts[font].size(trial)[0] > width and line:
                render.text(self.screen, self.fonts[font], line, (cx, y), color, anchor="midtop")
                line, y = word, y + self.fonts[font].get_linesize()
            else:
                line = trial
        if line:
            render.text(self.screen, self.fonts[font], line, (cx, y), color, anchor="midtop")

    def draw_toasts(self):
        for i, (aid, age) in enumerate(self.toasts[:3]):
            name, desc = ACHIEVEMENTS[aid]
            slide = max(0.0, min(1.0, age * 5, (3.6 - age) * 4))
            x = S.WIDTH + 10 - 390 * slide
            rect = pygame.Rect(x, S.HEIGHT - 160 - i * 84, 360, 70)
            pygame.draw.rect(self.screen, (22, 18, 42), rect, border_radius=12)
            pygame.draw.rect(self.screen, S.GOLD, rect, 2, border_radius=12)
            render.glow(self.screen, (rect.left + 36, rect.centery), 34, S.GOLD, 0.5)
            pygame.draw.polygon(self.screen, S.GOLD, render.regular_polygon((rect.left + 36, rect.centery), 14, 5, -math.pi / 2))
            render.text(self.screen, self.fonts["tiny"], "ACHIEVEMENT UNLOCKED", (rect.left + 66, rect.top + 10), S.GOLD)
            render.text(self.screen, self.fonts["small"], name, (rect.left + 66, rect.top + 28), S.WHITE)
            render.text(self.screen, self.fonts["tiny"], desc, (rect.left + 66, rect.top + 50), (170, 170, 205))

    def draw_trophies(self):
        render.text(self.screen, self.fonts["big"], "ACHIEVEMENTS", (S.WIDTH / 2, 60), S.WHITE,
                    anchor="center", glow_color=S.GOLD)
        render.text(self.screen, self.fonts["small"], f"{len(self.unlocked)} / {len(ACHIEVEMENTS)} unlocked",
                    (S.WIDTH / 2, 105), S.GOLD, anchor="center")
        for i, (aid, (name, desc)) in enumerate(ACHIEVEMENTS.items()):
            col, row = i % 3, i // 3
            x, y = 90 + col * 380, 140 + row * 92
            got = aid in self.unlocked
            color = S.GOLD if got else (80, 80, 110)
            rect = pygame.Rect(x, y, 360, 78)
            pygame.draw.rect(self.screen, (20, 17, 38) if got else (12, 11, 24), rect, border_radius=12)
            pygame.draw.rect(self.screen, color, rect, 2, border_radius=12)
            star = render.regular_polygon((x + 34, y + 39), 14, 5, -math.pi / 2)
            if got:
                render.glow(self.screen, (x + 34, y + 39), 32, S.GOLD, 0.45)
            render.aa_outline(self.screen, color, star, 0 if got else 2)
            render.text(self.screen, self.fonts["small"], name, (x + 62, y + 14), S.WHITE if got else (130, 130, 160))
            render.text(self.screen, self.fonts["tiny"], desc, (x + 62, y + 42), (170, 170, 205) if got else (100, 100, 130))
            if got:
                render.text(self.screen, self.fonts["tiny"], self.unlocked[aid], (x + 62, y + 58), (120, 120, 160))
        life = storage.load_lifetime()
        hours, rest = divmod(life["seconds"], 3600)
        summary = (f"games {life['games']}     kills {life['kills']:,}     cores {life['bosses']}     "
                   f"dashes {life['dashes']:,}     time played {hours}h {rest // 60:02d}m")
        render.text(self.screen, self.fonts["small"], summary, (S.WIDTH / 2, 640), (180, 180, 210), anchor="center")
        render.text(self.screen, self.fonts["tiny"], "press any key", (S.WIDTH / 2, 690), (150, 150, 185), anchor="center")

    def draw_launch(self):
        f = self.fonts
        rects = self.launch_rects()
        mode_id = self.settings.get("mode", "classic")
        mode = modes.BY_ID.get(mode_id, modes.MODES[0])
        daily = mode_id == "daily"
        ship = modes.daily_ship() if daily else ships.get(self.settings.get("ship"))
        unlocked = daily or ships.is_unlocked(ship, self.unlocked)

        render.text(self.screen, f["big"], "LAUNCH", (S.WIDTH / 2, 62), S.WHITE, anchor="center", glow_color=S.CYAN)

        def panel(rect, row, title):
            selected = self.launch_row == row
            pygame.draw.rect(self.screen, (14, 12, 30), rect, border_radius=16)
            pygame.draw.rect(self.screen, S.CYAN if selected else (60, 60, 95), rect, 2, border_radius=16)
            render.text(self.screen, f["tiny"], title, (rect.left + 20, rect.top + 14),
                        S.CYAN if selected else (130, 130, 170))
            for side, x in ((-1, rect.left + 36), (1, rect.right - 36)):
                pts = render.ship_points((x, rect.centery), 12, 0 if side > 0 else math.pi)
                pygame.draw.polygon(self.screen, S.CYAN if selected else (70, 70, 110), pts)

        # ---- mode ----
        r = rects["mode"]
        panel(r, 0, "MODE   (left / right)")
        render.text(self.screen, f["big"], mode.name, (r.centerx, r.top + 44), S.GOLD, anchor="center")
        render.text(self.screen, f["small"], mode.description, (r.centerx, r.top + 82), S.WHITE, anchor="center")
        lid, lname, lcolor, _ = difficulty.level("medium" if daily else self.settings.get("difficulty"))
        best = storage.load_scores(modes.score_key(mode_id) + difficulty.board_suffix(lid))
        best_text = f"best: {best[0]['score']:,}" if best else "no score yet"
        if daily:
            best_text = f"today ({modes.score_key('daily')[6:]})  -  " + best_text
        render.text(self.screen, f["tiny"], best_text, (r.centerx, r.top + 106), (170, 170, 205), anchor="center")

        # ---- difficulty ----
        r = rects["difficulty"]
        panel(r, 1, "DIFFICULTY (fixed for the Daily Run)" if daily else "DIFFICULTY   (left / right)")
        render.text(self.screen, f["big"], lname, (r.centerx, r.top + 46), lcolor, anchor="center", glow_color=lcolor)
        chosen = difficulty.ticked(self.settings, lid) if not daily else []
        names = [difficulty.OPTIONS[o][0] for o in chosen] or ["the classic game: nothing changed"]
        lines, line = [], ""
        for name in names:                      # wrap to two lines, clear of the OPTIONS button
            test = f"{line}  -  {name}" if line else name
            if line and f["tiny"].size(test)[0] > 620:
                lines.append(line)
                line = name
            else:
                line = test
        lines.append(line)
        for i, text in enumerate(lines[:2]):
            render.text(self.screen, f["tiny"], text, (r.left + 460, r.top + 82 + i * 20 - (len(lines[:2]) - 1) * 6),
                        (190, 190, 220), anchor="center")
        if not daily:
            o = rects["options"]
            hover = o.collidepoint(Vector2(self.mouse_pos()) - Vector2(self.offset)) if self.pads.device == "keyboard" else False
            pygame.draw.rect(self.screen, (24, 22, 50) if hover else (16, 14, 34), o, border_radius=10)
            pygame.draw.rect(self.screen, lcolor, o, 2, border_radius=10)
            self.hint("{options}  OPTIONS", o.center, "tiny", S.WHITE)

        # ---- ship ----
        r = rects["ship"]
        panel(r, 2, "TODAY'S SHIP (fixed for the Daily Run)" if daily else "SHIP   (up / down to switch row)")
        center = (r.left + 250, r.centery + 6)
        color = ship.color if unlocked else (70, 70, 100)
        render.glow(self.screen, center, 120, color, 0.5 if unlocked else 0.15)
        pts = render.ship_points(center, 46, self.t * 0.8)
        render.neon_polygon(self.screen, pts, color, width=4)
        if ship.charges > 1 and unlocked:
            render.text(self.screen, f["tiny"], f"x{ship.charges} DASH", (center[0], center[1] + 80), color, anchor="center")
        tx = r.left + 450
        render.text(self.screen, f["big"], ship.name, (tx, r.top + 34), color)
        if unlocked:
            render.text(self.screen, f["small"], ship.trait, (tx, r.top + 86), S.WHITE)
        else:
            from prism_dash.achievements import ACHIEVEMENTS as ACH
            name, desc = ACH[ship.unlock]
            render.text(self.screen, f["small"], f"LOCKED - earn '{name}': {desc}", (tx, r.top + 86), S.RED)
        for i, (label, value) in enumerate(ships.stat_bars(ship).items()):
            y = r.top + 122 + i * 25
            render.text(self.screen, f["tiny"], label, (tx, y), (170, 170, 205))
            pygame.draw.rect(self.screen, (35, 35, 60), (tx + 140, y + 4, 300, 10), border_radius=5)
            pygame.draw.rect(self.screen, color, (tx + 140, y + 4, 300 * value, 10), border_radius=5)
        if not daily:
            owned = sum(ships.is_unlocked(sh, self.unlocked) for sh in ships.SHIPS)
            render.text(self.screen, f["tiny"], f"{owned} / {len(ships.SHIPS)} ships unlocked",
                        (r.right - 24, r.bottom - 26), (150, 150, 185), anchor="topright")

        # ---- start ----
        r = rects["start"]
        ok = self.launch_ready()
        pygame.draw.rect(self.screen, (20, 40, 50) if ok else (40, 25, 35), r, border_radius=14)
        pygame.draw.rect(self.screen, S.CYAN if ok else S.RED, r, 3, border_radius=14)
        if ok:
            render.glow(self.screen, r.center, 140, S.CYAN, 0.25 + 0.1 * math.sin(self.t * 4))
        if ok:
            self.hint("START  [{confirm}]" if self.pads.device == "keyboard" else "START  {confirm}", r.center, "medium", S.WHITE)
        else:
            render.text(self.screen, f["medium"], "SHIP LOCKED", r.center, S.RED, anchor="center")
        self.hint("{back}: back", (S.WIDTH / 2, 700), "tiny", (130, 130, 165))

    def hint(self, markup, pos, font="small", color=(180, 180, 210), anchor="center"):
        """A line of text whose {action} markers show the keys, or the pad's button icons."""
        return render.rich_text(self.screen, self.fonts[font], hint_parts(markup, self.pads.device), pos, color,
                                anchor, playstation=self.pads.device == "playstation")

    def big_center(self, title, subtitle):
        render.text(self.screen, self.fonts["big"], title, (S.WIDTH / 2, S.HEIGHT / 2 - 30),
                    S.WHITE, anchor="center", glow_color=S.CYAN)
        self.hint(subtitle, (S.WIDTH / 2, S.HEIGHT / 2 + 30))

    CREDITS_SPEED = 46            # pixels per second

    def credits_length(self):
        return (S.HEIGHT + len(credits.roll()) * 44 + 200) / self.CREDITS_SPEED

    def draw_credits(self):
        y = S.HEIGHT + 30 - self.credits_t * self.CREDITS_SPEED
        styles = {"title": ("big", S.GOLD), "heading": ("tiny", S.CYAN), "line": ("medium", S.WHITE),
                  "small": ("tiny", (150, 150, 190)), "gap": (None, None)}
        for kind, text in credits.roll():
            font, colour = styles[kind]
            if font and -60 < y < S.HEIGHT + 60:
                render.text(self.screen, self.fonts[font], text, (S.WIDTH / 2, y), colour,
                            anchor="center", glow_color=colour if kind == "title" else None)
            y += 64 if kind == "title" else 44
        if self.credits_t > 1.0:
            self.hint("{confirm}: skip", (S.WIDTH - 90, S.HEIGHT - 24), "tiny", (120, 120, 160))

    def draw_gameover(self):
        r, f = self.result, self.fonts
        if r.get("won"):
            headline, colour = "VICTORY", S.GOLD
        else:
            headline, colour = ("TIME UP" if r["mode"] == "blitz" else "GAME OVER"), S.PINK
        render.text(self.screen, f["huge"], headline, (S.WIDTH / 2, 140), colour,
                    anchor="center", glow_color=colour)
        mode_name = "DAILY RUN " + modes.score_key("daily")[6:] if r["mode"] == "daily" \
            else modes.BY_ID[r["mode"]].name
        render.text(self.screen, f["small"], f"{mode_name}   -   {r['ship'].name}", (S.WIDTH / 2, 215),
                    r["ship"].color, anchor="center")
        render.text(self.screen, f["big"], f"{r['score']:,}", (S.WIDTH / 2, 270), S.WHITE, anchor="center")
        if r["rank"] == 1:
            msg, color = "NEW HIGH SCORE!", S.GOLD
        elif r["rank"]:
            msg, color = f"#{r['rank']} on the high score table", S.CYAN
        else:
            msg, color = "", S.WHITE
        if msg and int(self.t * 3) % 2 == 0:
            render.text(self.screen, f["medium"], msg, (S.WIDTH / 2, 330), color, anchor="center", glow_color=color)
        sector = sectors.SECTORS[r.get("sector", 0)]
        stats = [("SECTOR", f"{r.get('sector', 0) + 1} {sector.name}" if r["mode"] != "blitz" else r["wave"]),
                 ("KILLS", r["kills"]), ("BEST CHAIN", r["chain"]),
                 ("MOST IN ONE DASH", r["best_dash"])]
        for i, (label, value) in enumerate(stats):
            x = S.WIDTH / 2 + (i - 1.5) * 230
            render.text(self.screen, f["tiny"], label, (x, 400), (160, 160, 200), anchor="center")
            render.text(self.screen, f["big"], str(value), (x, 445), S.WHITE, anchor="center")
        if r["perks"]:
            build = "   ".join(perks.PERKS[pid].name + (f" {lv}" if lv > 1 else "") for pid, lv in r["perks"].items())
            render.text(self.screen, f["tiny"], "BUILD:  " + build, (S.WIDTH / 2, 515), (170, 170, 205), anchor="center")
        if r.get("ngplus_new"):
            render.text(self.screen, f["medium"], "NEW GAME+ UNLOCKED: start again with this build",
                        (S.WIDTH / 2, 580), S.GOLD, anchor="center", glow_color=S.GOLD)
        if r["unlocks"]:
            names = ", ".join(ACHIEVEMENTS[a][0] for a in r["unlocks"])
            render.text(self.screen, f["small"], f"Unlocked: {names}", (S.WIDTH / 2, 550), S.GOLD, anchor="center")
        if r.get("won"):
            self.hint("{confirm}: credits      {back}: menu", (S.WIDTH / 2, 610), "small", (190, 190, 220))
        else:
            self.hint("{confirm}: play again      {back}: menu", (S.WIDTH / 2, 610), "small", (190, 190, 220))


def main():
    App().run()


async def main_async():
    await App().run_async()
