"""Native-resolution drawing for ULTRA (Windows).

The game thinks in logical pixels: a 1280x720 arena inside a picture with the monitor's
shape (1720x720 on a 21:9 screen). Without this module that picture is drawn at its
logical size and the graphics card stretches it to the screen, so lines and text are
soft. With it, every surface the game draws on is a Canvas: a logical-size view over a
real surface `k` times bigger (k = screen height / logical height, 2.0 on 3440x1440).
Every pygame.draw call, fill, blit and font render on a Canvas is scaled to real pixels,
so the same drawing code comes out crisp at the screen's native resolution.

Only active once enable() is called (ULTRA on desktop); otherwise nothing changes and
the browser / STANDARD versions draw exactly as before.
"""

import pygame

K = 1.0                 # real pixels per logical pixel; 1.0 = off
_ORIGINAL = {}          # the untouched pygame.draw functions
_FONT = pygame.font.Font


def active():
    return K != 1.0


# ---------------------------------------------------------------- scaling helpers
def _pt(p, k):
    return (p[0] * k, p[1] * k)


def _len(v, k):
    return v * k


def _w(v, k):
    """A line width: 0 stays 0 (filled), anything else at least one real pixel."""
    return 0 if v <= 0 else max(1, round(v * k))


def _r(v, k):
    """A corner radius (whole pixels; -1/0 mean 'none')."""
    return v if v <= 0 else round(v * k)


def _rect(r, k):
    """Scale a rect-like by k, rounding its edges (so neighbouring rects still meet)."""
    if len(r) == 2:
        (x, y), (w, h) = r
    else:
        x, y, w, h = r
    left, top = round(x * k), round(y * k)
    return pygame.Rect(left, top, round((x + w) * k) - left, round((y + h) * k) - top)


def _pts(ps, k):
    return [(p[0] * k, p[1] * k) for p in ps]


def _raw(v, k):
    return v


def _unscale(rect, k):
    if not isinstance(rect, pygame.Rect):
        return rect
    return pygame.Rect(int(rect.x / k), int(rect.y / k), round(rect.w / k), round(rect.h / k))


# argument kinds after (surface, color), positional then by keyword
_SPECS = {
    "circle": ((_pt, _len, _w), {"center": _pt, "radius": _len, "width": _w}),
    "aacircle": ((_pt, _len, _w), {"center": _pt, "radius": _len, "width": _w}),
    "rect": ((_rect, _w, _r, _r, _r, _r, _r),
             {"rect": _rect, "width": _w, "border_radius": _r, "border_top_left_radius": _r,
              "border_top_right_radius": _r, "border_bottom_left_radius": _r, "border_bottom_right_radius": _r}),
    "line": ((_pt, _pt, _w), {"start_pos": _pt, "end_pos": _pt, "width": _w}),
    "aaline": ((_pt, _pt, _w), {"start_pos": _pt, "end_pos": _pt, "width": _w}),
    "polygon": ((_pts, _w), {"points": _pts, "width": _w}),
    "aapolygon": ((_pts, _raw), {"points": _pts}),
    "lines": ((_raw, _pts, _w), {"closed": _raw, "points": _pts, "width": _w}),
    "ellipse": ((_rect, _w), {"rect": _rect, "width": _w}),
    "aaellipse": ((_rect, _w), {"rect": _rect, "width": _w}),
    "arc": ((_rect, _raw, _raw, _w), {"rect": _rect, "width": _w}),
}


def _wrap(name, original, spec):
    positional, named = spec

    def draw(surface, color, *args, **kwargs):
        if not isinstance(surface, Canvas):
            return original(surface, color, *args, **kwargs)
        k = surface.k
        args = [fn(a, k) for fn, a in zip(positional, args)]
        kwargs = {key: named.get(key, _raw)(v, k) for key, v in kwargs.items()}
        if name in ("line", "aaline"):
            if len(args) < 3 and "width" not in kwargs:
                args.append(_w(1, k))               # default 1-px lines keep their weight
            if len(args) == 3 and not kwargs:
                (x1, y1), (x2, y2), width = args
                if x1 == x2 or y1 == y2:            # straight across or down: a plain fill is exact
                    half = width / 2
                    left, top = round(min(x1, x2) - (half if x1 == x2 else 0)), round(min(y1, y2) - (half if y1 == y2 else 0))
                    right = round(max(x1, x2) + (half if x1 == x2 else 0)) + (0 if x1 == x2 else 1)
                    bottom = round(max(y1, y2) + (half if y1 == y2 else 0)) + (0 if y1 == y2 else 1)
                    surface.real.fill(color, (left, top, right - left, bottom - top))
                    return
        original(surface.real, color, *args, **kwargs)     # (nothing uses the returned rect)

    draw.__name__ = name
    draw.__wrapped__ = original
    return draw


def _aalines(surface, color, closed, points, *args, **kwargs):
    """Smooth polylines have no width in pygame. At k >= 1.5 a hairline is drawn twice,
    one real pixel apart across its main direction, so it keeps the weight it had at the
    logical size (two fast C calls instead of one thick segment per point)."""
    if not isinstance(surface, Canvas):
        return _ORIGINAL["aalines"](surface, color, closed, points, *args, **kwargs)
    k = surface.k
    pts = _pts(points, k)
    draw = _ORIGINAL["aalines"]
    if round(k) >= 2 and len(pts) >= 2:
        pygame.draw.lines.__wrapped__(surface.real, color, closed, pts, round(k))
    else:
        draw(surface.real, color, closed, pts)
    return None


def _install_draw():
    if _ORIGINAL:
        return
    for name, spec in _SPECS.items():
        fn = getattr(pygame.draw, name, None)
        if fn is not None:
            _ORIGINAL[name] = fn
            setattr(pygame.draw, name, _wrap(name, fn, spec))
    _ORIGINAL["aalines"] = pygame.draw.aalines
    pygame.draw.aalines = _aalines


def enable(k):
    """Turn native-resolution drawing on with k real pixels per logical one."""
    global K
    K = float(k)
    if active():
        _install_draw()


def disable():
    global K
    K = 1.0


def scale_for(logical, screen):
    """Real pixels per logical pixel for a picture of `logical` size on `screen`:
    the factor that fills the screen's height or width, whichever is limiting."""
    return min(screen[0] / logical[0], screen[1] / logical[1])


# ---------------------------------------------------------------- images
_scaled = {}            # id(surface) -> (surface, its k-scaled copy)
_SCALED_MAX = 256


def _upscaled(image, k):
    """A plain logical-size surface scaled to real pixels (cached for reused surfaces)."""
    hit = _scaled.get(id(image))
    if hit is not None and hit[0] is image and hit[2] == k:
        return hit[1]
    w, h = image.get_size()
    size = (max(1, round(w * k)), max(1, round(h * k)))
    big = pygame.transform.smoothscale(image, size) if image.get_bitsize() >= 24 else pygame.transform.scale(image, size)
    alpha = image.get_alpha()
    if alpha is not None:
        big.set_alpha(alpha)
    if len(_scaled) >= _SCALED_MAX:
        _scaled.pop(next(iter(_scaled)))
    _scaled[id(image)] = (image, big, k)
    return big


class Image:
    """A picture made at real resolution (rendered text) that reports its logical size."""

    def __init__(self, real, k):
        self.real = real
        self.k = k

    def get_size(self):
        w, h = self.real.get_size()
        return (round(w / self.k), round(h / self.k))

    def get_width(self):
        return self.get_size()[0]

    def get_height(self):
        return self.get_size()[1]

    def get_rect(self, **kwargs):
        rect = pygame.Rect((0, 0), self.get_size())
        for key, value in kwargs.items():
            setattr(rect, key, value)
        return rect

    def set_alpha(self, *args):
        self.real.set_alpha(*args)

    def get_alpha(self):
        return self.real.get_alpha()

    def __getattr__(self, name):            # anything else: the real surface
        return getattr(self.real, name)


def _real_source(source, k):
    if isinstance(source, Canvas):
        return source.real
    if isinstance(source, Image):
        return source.real
    return _upscaled(source, k)


# ---------------------------------------------------------------- canvas
class Canvas:
    """A logical-size drawing surface backed by a k-times-bigger real one."""

    def __init__(self, real, k, size):
        self.real = real
        self.k = k
        self.size = (int(size[0]), int(size[1]))

    @classmethod
    def new(cls, size, flags=0, depth=0):
        k = K
        real_size = (max(1, round(size[0] * k)), max(1, round(size[1] * k)))
        real = pygame.Surface(real_size, flags, depth) if depth else pygame.Surface(real_size, flags)
        return cls(real, k, size)

    # size ---------------------------------------------------------
    def get_size(self):
        return self.size

    def get_width(self):
        return self.size[0]

    def get_height(self):
        return self.size[1]

    def get_rect(self, **kwargs):
        rect = pygame.Rect((0, 0), self.size)
        for key, value in kwargs.items():
            setattr(rect, key, value)
        return rect

    def subsurface(self, rect):
        rect = pygame.Rect(rect)
        return Canvas(self.real.subsurface(_rect(rect, self.k)), self.k, rect.size)

    # drawing --------------------------------------------------------
    def fill(self, color, rect=None, special_flags=0):
        if rect is not None:
            rect = _rect(rect, self.k)
        return _unscale(self.real.fill(color, rect, special_flags), self.k)

    def blit(self, source, dest, area=None, special_flags=0):
        k = self.k
        real = _real_source(source, k)
        if len(dest) == 4 or isinstance(dest, pygame.Rect):
            dest = (dest[0], dest[1])
        pos = (round(dest[0] * k), round(dest[1] * k))
        if area is not None:
            area = _rect(area, k)
        return _unscale(self.real.blit(real, pos, area, special_flags), k)

    def blit_real(self, real, center, special_flags=0):
        """Blit an already real-resolution picture centred on a logical point."""
        w, h = real.get_size()
        pos = (round(center[0] * self.k - w / 2), round(center[1] * self.k - h / 2))
        return self.real.blit(real, pos, None, special_flags)

    def set_alpha(self, *args):
        self.real.set_alpha(*args)

    def get_alpha(self):
        return self.real.get_alpha()

    def set_clip(self, rect=None):
        self.real.set_clip(None if rect is None else _rect(rect, self.k))

    def __getattr__(self, name):
        return getattr(self.real, name)


def surface(size, flags=0, depth=0):
    """A new drawing surface: a Canvas when native resolution is on, else a plain Surface."""
    if active():
        return Canvas.new(size, flags, depth)
    return pygame.Surface(size, flags, depth) if depth else pygame.Surface(size, flags)


def real(surface_):
    """The real pixels behind a surface (itself when it isn't a Canvas)."""
    return surface_.real if isinstance(surface_, Canvas) else surface_


# ---------------------------------------------------------------- fonts
class Font(_FONT):
    """A font rendered k times bigger whose measurements come back in logical pixels."""

    def __init__(self, file, size):
        self.k = K
        self.logical_size = size
        super().__init__(file, max(1, round(size * self.k)))

    def render(self, *args, **kwargs):
        return Image(super().render(*args, **kwargs), self.k)

    def size(self, text):
        w, h = super().size(text)
        return (round(w / self.k), round(h / self.k))

    def get_height(self):
        return round(super().get_height() / self.k)

    def get_linesize(self):
        return round(super().get_linesize() / self.k)

    def get_ascent(self):
        return round(super().get_ascent() / self.k)

    def get_descent(self):
        return round(super().get_descent() / self.k)


def font(file, size):
    """A font for drawing: hi-res when native resolution is on."""
    return Font(file, size) if active() else _FONT(file, size)
